import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { extractFile } from "@electron/asar";
const root = process.cwd(),
  dir = path.join(root, "release/win-unpacked"),
  exe = await fs.readFile(path.join(dir, "AQUA REALM 3D.exe")),
  pe = exe.readUInt32LE(0x3c);
if (
  exe.toString("ascii", 0, 2) !== "MZ" ||
  exe.toString("ascii", pe, pe + 4) !== "PE\0\0" ||
  exe.readUInt16LE(pe + 4) !== 0x8664
)
  throw Error("Invalid Windows x64 executable");
const asar = path.join(dir, "resources/app.asar"),
  hash = (b) => crypto.createHash("sha256").update(b).digest("hex");
for (const asset of [
  "BarramundiFish.glb",
  "BarramundiFish-low.glb",
  "fish/neon.glb",
  "fish/neon-low.glb",
  "fish/zebra.glb",
  "fish/zebra-low.glb",
  "fish/guppy.glb",
  "fish/guppy-low.glb",
  "fish/angel.glb",
  "fish/angel-low.glb",
]) {
  const packed = extractFile(asar, "dist/assets/" + asset),
    source = await fs.readFile(path.join(root, "public/assets", asset));
  if (hash(packed) !== hash(source))
    throw Error("Packaged asset mismatch: " + asset);
}
const pkg = JSON.parse(extractFile(asar, "package.json").toString());
if (
  pkg.version !==
  JSON.parse(await fs.readFile(path.join(root, "package.json"), "utf8")).version
)
  throw Error("Incorrect packaged version");
const entry = extractFile(asar, "electron/main.cjs").toString();
if (
  !entry.includes("contextIsolation: true") ||
  !entry.includes("nodeIntegration: false") ||
  !entry.includes("sandbox: true")
)
  throw Error("Missing desktop protections");
console.log(
  "Windows AMD64 PE, packaged version, ten asset hashes and Electron settings: PASS",
);

for (const file of [
  "main.cjs",
  "preload.cjs",
  "storage.cjs",
  "window-size.cjs",
]) {
  if (
    hash(extractFile(asar, "electron/" + file)) !==
    hash(await fs.readFile(path.join(root, "electron", file)))
  )
    throw Error("Packaged desktop code differs: " + file);
}
if (
  hash(extractFile(asar, "dist/index.html")) !==
  hash(await fs.readFile(path.join(root, "dist/index.html")))
)
  throw Error("Outdated packaged renderer index");
console.log(
  "All desktop entry modules and renderer index match final build: PASS",
);
