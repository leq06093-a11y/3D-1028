"""Prepare an offline, size-limited delivery folder. No uploading or public publishing.
Every piece stays below GitHub's per-file limit; START-AQUA.cmd joins verified bytes.
"""
from pathlib import Path
import json,hashlib,shutil
root=Path(__file__).resolve().parents[1]
version=json.loads((root/'package.json').read_text())['version']
exe=root/'release'/f'AQUA-REALM-3D-{version}-Windows.exe'
source=root/'release'/f'AQUA-REALM-3D-{version}-source.zip'
out=root/'release/direct-use';out.mkdir(parents=True,exist_ok=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
parts=[]
with exe.open('rb')as f:
 i=1
 while block:=f.read(60*1024*1024):
  p=out/f'AQUA.part{i:02}.bin';p.write_bytes(block);parts.append({'name':p.name,'bytes':len(block),'sha256':digest(p)});i+=1
manifest={'version':version,'appFile':exe.name,'bytes':exe.stat().st_size,'sha256':digest(exe),'parts':parts}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
ps=r'''$ErrorActionPreference='Stop';$root=$env:AQUA_PACKAGE_DIR;$m=Get-Content -LiteralPath (Join-Path $root 'manifest.json') -Raw|ConvertFrom-Json;if([IO.Path]::GetFileName($m.appFile) -ne $m.appFile){throw 'Invalid application name'};$target=Join-Path $root $m.appFile;$valid=(Test-Path -LiteralPath $target) -and ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -eq $m.sha256);if(-not $valid){$temp=$target+'.'+[Guid]::NewGuid().ToString()+'.tmp';try{$stream=[IO.File]::Open($temp,[IO.FileMode]::CreateNew);try{foreach($part in $m.parts){if([IO.Path]::GetFileName($part.name) -ne $part.name){throw 'Invalid part name'};$file=Join-Path $root $part.name;if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $part.sha256){throw ('File check failed: '+$part.name)};$partStream=[IO.File]::OpenRead($file);try{$partStream.CopyTo($stream)}finally{$partStream.Dispose()}}}finally{$stream.Dispose()};if((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash -ne $m.sha256){throw 'Application check failed'};if(Test-Path -LiteralPath $target){Move-Item -LiteralPath $target -Destination ($target+'.previous-'+[DateTime]::Now.Ticks)};Move-Item -LiteralPath $temp -Destination $target}catch{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp};throw}};Start-Process -FilePath $target -WorkingDirectory $root'''
cmd='''@echo off
setlocal
chcp 65001 >nul
title AQUA REALM 3D
set "AQUA_PACKAGE_DIR=%~dp0"
echo 正在校验并打开水境，首次需要一点时间。请保留全部文件。
powershell.exe -NoProfile -Command "'''+ps+'''"
if errorlevel 1 (
 echo.
 echo 未能启动。请右键压缩包选择“全部解压缩”，不要在压缩包内运行。
 echo 如仍失败，请保留上方错误信息并发给开发者。不要关闭系统防护。
 pause
 exit /b 1
)
exit /b 0
'''
(out/'START-AQUA.cmd').write_bytes(cmd.replace('\n','\r\n').encode('utf-8'))
(out/'先读我.txt').write_text('AQUA REALM 3D '+version+'\n\n1. 右键 ZIP 压缩包，全部解压缩。\n2. 打开解压文件夹，双击 START-AQUA.cmd。\n3. 等待首次校验和解包，点击“开始养鱼”。\n\n无需 Node.js、Blender 或管理员权限。启动脚本不联网，不修改执行策略，不关闭系统防护。所有分卷必须保留；每次运行会校验文件。以后也可以直接双击生成的 AQUA-REALM-3D-'+version+'-Windows.exe。\n\n若 Windows 显示安全提示，请先确认来源；不确定时向开发者提供提示文字。自动存档在当前用户应用数据目录，可在软件设置中打开。源码另附 ZIP。\n',encoding='utf-8-sig')
if source.exists():shutil.copy2(source,out/source.name)
# Re-read and verify assembled bytes, never claim a folder of unchecked parts is a usable package.
h=hashlib.sha256();total=0
for p in parts:
 file=out/p['name'];assert file.stat().st_size==p['bytes'];assert digest(file)==p['sha256']
 with file.open('rb')as f:
  while b:=f.read(1024*1024):h.update(b);total+=len(b)
assert h.hexdigest()==manifest['sha256'] and total==manifest['bytes']
print('Offline delivery verified:',len(parts),'parts;',total,'bytes; SHA-256',manifest['sha256'])
