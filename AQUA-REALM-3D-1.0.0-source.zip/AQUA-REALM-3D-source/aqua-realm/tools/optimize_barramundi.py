"""Verified CC0 derivative: preserve geometry/materials; downsample only embedded PNGs.
Rebuild aligned GLB buffer views without changing accessor offsets or disabling checks.
"""
import json,struct,io,pathlib
from PIL import Image
root=pathlib.Path(__file__).resolve().parents[1];source=root/'public/assets/BarramundiFish.glb';b=source.read_bytes();assert b[:4]==b'glTF';n=struct.unpack_from('<I',b,12)[0];j=json.loads(b[20:20+n]);offset=20+n;binlength=struct.unpack_from('<I',b,offset)[0];data=b[offset+8:offset+8+binlength]
images={v['bufferView'] for v in j['images']};out=bytearray()
for i,view in enumerate(j['bufferViews']):
 payload=data[view.get('byteOffset',0):view.get('byteOffset',0)+view['byteLength']]
 if i in images:
  im=Image.open(io.BytesIO(payload));im.thumbnail((1024,1024),Image.Resampling.LANCZOS);f=io.BytesIO();im.save(f,format='PNG',optimize=True);payload=f.getvalue()
 while len(out)%4:out.append(0)
 view['byteOffset']=len(out);view['byteLength']=len(payload);out.extend(payload)
j['buffers'][0]['byteLength']=len(out);j.setdefault('asset',{}).setdefault('extras',{})['derivative']='CC0 model; 1024px texture LOD by AQUA REALM. Geometry retained.'
encoded=json.dumps(j,separators=(',',':')).encode();encoded+=b' '*((-len(encoded))%4);out.extend(b'\0'*((-len(out))%4));size=12+8+len(encoded)+8+len(out)
result=struct.pack('<4sII',b'glTF',2,size)+struct.pack('<I4s',len(encoded),b'JSON')+encoded+struct.pack('<I4s',len(out),b'BIN\0')+out;assert len(result)==size
p=root/'public/assets/BarramundiFish-low.glb';p.write_bytes(result);print('Original:',len(b),'Texture LOD:',len(result))
