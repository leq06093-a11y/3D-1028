// CPU simulation throughput only; this is not a GPU/FPS benchmark.
import { performance } from "node:perf_hooks";
import { build } from "vite";
await build({
  configFile: false,
  build: {
    lib: {
      entry: "src/simulation/model.ts",
      formats: ["es"],
      fileName: () => "simulation-benchmark.mjs",
    },
    outDir: "artifacts/benchmark-module",
    emptyOutDir: true,
    minify: false,
  },
  logLevel: "error",
});
const { makeFish, initialDocument, stepFish } = await import(
  "../artifacts/benchmark-module/simulation-benchmark.mjs"
);
const doc = initialDocument();
const counts = [12, 30, 80],
  results = [];
for (const count of counts) {
  const fish = Array.from({ length: count }, (_, i) =>
    makeFish(i, ["neon", "zebra", "guppy", "angel"][i % 4]),
  );
  const begin = performance.now();
  for (let i = 0; i < 1800; i++)
    stepFish(
      fish,
      [],
      doc.decorations,
      doc.tank,
      doc.environment,
      doc.ecology,
      1 / 30,
      i / 30,
    );
  const ms = performance.now() - begin;
  const finite = fish.every((f) => f.position.every(Number.isFinite));
  if (!finite) throw Error("Non-finite state");
  results.push({
    fish: count,
    steps: 1800,
    simulatedSeconds: 60,
    totalCpuMs: Math.round(ms),
    meanStepMs: +(ms / 1800).toFixed(3),
    finite,
  });
}
const fs = await import("node:fs/promises");
await fs.writeFile(
  "artifacts/simulation-benchmark.json",
  JSON.stringify(
    { kind: "Linux CPU simulation only; not rendering FPS", results },
    null,
    2,
  ),
);
console.log(results);
