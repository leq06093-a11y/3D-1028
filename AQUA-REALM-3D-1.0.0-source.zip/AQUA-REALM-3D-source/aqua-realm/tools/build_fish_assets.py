"""Original anatomical fish mesh authoring, Blender 4.3. No external textures.
Body: longitudinal cross-sections, separate fin membranes/rays, eyes/gill cover.
Outputs real GLB meshes with PBR textures, body morph animation and distinct fins.
Not photogrammetry or biologically validated reconstructions.
"""
import bpy, math, random, pathlib, json, hashlib, sys
LOW="--low" in sys.argv
from mathutils import Vector
OUT=pathlib.Path(__file__).resolve().parents[1]/'public/assets/fish'
bpy.context.preferences.filepaths.save_version=0
OUT.mkdir(parents=True,exist_ok=True)
SOURCE=OUT.parents[2]/'source-assets/fish'
SOURCE.mkdir(parents=True,exist_ok=True)
SPECS={
 'neon':dict(name='NeonTetra',w=.065,h=.095,tail=.13,body=(.36,.43,.40),metal=.48),
 'zebra':dict(name='Zebrafish',w=.065,h=.075,tail=.12,body=(.67,.66,.42),metal=.4),
 'guppy':dict(name='Guppy',w=.075,h=.105,tail=.29,body=(.55,.64,.55),metal=.35),
 'angel':dict(name='Angelfish',w=.055,h=.26,tail=.18,body=(.74,.75,.66),metal=.48),
}
def P(x,y,z):return(x,-z,y)
def material(name,color,metal=.15,rough=.36):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;n=m.node_tree.nodes.get('Principled BSDF');n.inputs['Base Color'].default_value=(*color,1);n.inputs['Metallic'].default_value=metal;n.inputs['Roughness'].default_value=rough;return m

def texture(kind,spec):
 size=512;image=bpy.data.images.new(kind+'_scales',size,size);pixels=[0.]*(size*size*4)
 normal=bpy.data.images.new(kind+'_scale_normal',size,size);normals=[0.]*(size*size*4)
 rng=random.Random(52)
 for y in range(size):
  angle=y/(size-1)*math.tau;vertical=math.cos(angle);top=max(0,vertical)
  for x in range(size):
   t=x/(size-1);scalex=(x/11+(y//9%2)*.5)%1;scaley=(y/9)%1
   edge=max(0,1-((scalex-.5)**2+(scaley-.5)**2)**.5*2)
   shade=.65+.28*(1-top)+edge*.1+(rng.random()-.5)*.035
   col=[c*shade for c in spec['body']]
   if kind=='neon':
    if -.12<vertical<.25 and .08<t<.8:col=[.015,.7+edge*.2,.91]
    if vertical<-.1 and .46<t<.96:col=[.73,.035,.055]
    if top>.35:col=[.12*shade,.24*shade,.22*shade]
   elif kind=='zebra':
    stripe=math.sin(vertical*21+t*2.2)
    if stripe>.15:col=[.045,.10,.16]
    else:col=[.72*shade,.69*shade,.47*shade]
   elif kind=='guppy':
    spot=math.sin(t*32+angle*5)*math.cos(angle*8-t*11)
    if .42<t<.86 and spot>.5:col=[.05,.16,.16]
    elif .3<t<.87:col=[.13*shade,.56*shade,.59*shade]
    if .65<t<.9 and vertical<.1:col=[.8*shade,.30*shade,.12*shade]
   else:
    if any(abs(t-center)<(.026+.015*(1-top)) for center in [.08,.34,.61,.88]):col=[.055,.085,.075]
    else:col=[.8*shade,.8*shade,.68*shade]
   idx=(y*size+x)*4;pixels[idx:idx+4]=[*col,1]
   nx=math.sin(scalex*math.tau)*.14;ny=math.sin(scaley*math.tau)*.12
   normals[idx:idx+4]=[.5+nx,.5+ny,.98,1]
 image.pixels=pixels;image.filepath_raw=str(SOURCE/(kind+'-color.png'));image.file_format='PNG';image.save();image.pack()
 normal.pixels=normals;normal.colorspace_settings.name='Non-Color';normal.filepath_raw=str(SOURCE/(kind+'-normal.png'));normal.file_format='PNG';normal.save();normal.pack()
 m=material(kind+'_skin',spec['body'],spec['metal']);nodes=m.node_tree.nodes;links=m.node_tree.links;bsdf=nodes.get('Principled BSDF');tex=nodes.new('ShaderNodeTexImage');tex.image=image;links.new(tex.outputs['Color'],bsdf.inputs['Base Color']);nt=nodes.new('ShaderNodeTexImage');nt.image=normal;nm=nodes.new('ShaderNodeNormalMap');nm.inputs['Strength'].default_value=.5;links.new(nt.outputs['Color'],nm.inputs['Color']);links.new(nm.outputs['Normal'],bsdf.inputs['Normal'])
 return m

def mesh(name,verts,faces,mat,uvs=None):
 g=bpy.data.meshes.new(name);g.from_pydata([P(*p) for p in verts],[],faces);g.update();o=bpy.data.objects.new(name,g);bpy.context.collection.objects.link(o);o.data.materials.append(mat)
 for poly in g.polygons:poly.use_smooth=True
 if uvs:
  layer=g.uv_layers.new(name='UVMap')
  for poly in g.polygons:
   for i in poly.loop_indices:layer.data[i].uv=uvs[g.loops[i].vertex_index]
 return o

def curve(name,pts,radius,mat):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=3;c.bevel_depth=radius;c.bevel_resolution=1;s=c.splines.new('POLY');s.points.add(len(pts)-1)
 for p,co in zip(s.points,pts):p.co=(*P(*co),1)
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);o.data.materials.append(mat);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o.select_set(False);return o

def fin(name,root,edge,mat,raymat):
 # Fan mesh with radial subdivisions and finely tapering edge, not flat triangles.
 verts=[];uv=[];faces=[];n=len(edge)
 for j,e in enumerate(edge):
  for k in range(7):
   t=k/6;v=tuple(root[a]*(1-t)+e[a]*t for a in range(3));verts.append((v[0]+math.sin(j*.7)*.003*t,v[1],v[2]));uv.append((j/(n-1),t))
 for j in range(n-1):
  for k in range(6):a=j*7+k;faces.append((a,a+1,a+8,a+7))
 o=mesh(name,verts,faces,mat,uv)
 rays=[]
 for j in range(0,n,3):rays.append(curve(name+'_ray', [root,tuple(root[a]*.5+edge[j][a]*.5 for a in range(3)),edge[j]],.0015,raymat))
 origin=Vector(P(*root));o.location=origin
 for v in o.data.vertices:v.co-=origin
 for rayobj in rays:
  for v in rayobj.data.vertices:v.co-=origin
  rayobj.parent=o
 if len(rays)>1:
  bpy.ops.object.select_all(action='DESELECT')
  for rayobj in rays:rayobj.select_set(True)
  bpy.context.view_layer.objects.active=rays[0];bpy.ops.object.join();bpy.context.object.select_set(False)
 return o

def build(kind,spec):
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 skin=texture(kind,spec);eye=material('gold_iris',(.55,.48,.26),.55,.2);black=material('black_cornea',(.004,.009,.012),.15,.08);gill=material('gill_seam',(.14,.20,.16),.2,.4)
 fcolor={'neon':(.35,.56,.50),'zebra':(.68,.62,.34),'guppy':(.85,.27,.09),'angel':(.65,.65,.49)}[kind]
 fins=material('fin_membrane',fcolor,.25,.38);fins.diffuse_color=(*fcolor,.72);fins.node_tree.nodes.get('Principled BSDF').inputs['Alpha'].default_value=.72;fins.surface_render_method='DITHERED';ray=material('fin_rays',tuple(c*.65 for c in fcolor),.2,.4)
 n=24 if LOW else 48;m=24 if LOW else 48;verts=[];uv=[];faces=[]
 for i in range(n+1):
  t=i/n;profile=max(.025,math.sin(math.pi*(t*.94+.025)))**.8*(1-.65*t)
  if kind=='angel':profile=max(.025,math.sin(math.pi*t))**1.05*(1-.45*t)
  center=.012*math.sin(t*math.pi)
  for j in range(m+1):
   a=j/m*math.tau;verts.append((spec['w']*profile*math.sin(a),center+spec['h']*profile*math.cos(a),-.43+.82*t));uv.append((t,j/m))
 for i in range(n):
  for j in range(m):a=i*(m+1)+j;faces.append((a,a+1,a+m+2,a+m+1))
 faces.extend([tuple(range(m,-1,-1)),tuple(n*(m+1)+j for j in range(m+1))]);body=mesh('Body_'+spec['name'],verts,faces,skin,uv)
 body.shape_key_add(name='Basis');keys=[]
 for phase in [0,math.pi/2,math.pi,math.pi*1.5]:
  key=body.shape_key_add(name='Swim_'+str(len(keys)));keys.append(key)
  for idx,v in enumerate(verts):
   t=(v[2]+.43)/.82;offset=math.sin(phase-t*math.pi*1.7)*max(0,(t-.2)/.8)**2*.07;key.data[idx].co=P(v[0]+offset,v[1],v[2])
 for frame,keyidx in [(1,0),(9,1),(17,2),(25,3),(33,0)]:
  for idx,key in enumerate(keys):key.value=1. if idx==keyidx else 0.;key.keyframe_insert('value',frame=frame)
 # Anatomical eyes on either side of the head, irises with separate glossy pupils.
 for side in [-1,1]:
  loc=(side*spec['w']*.54,.025,-.335)
  for name,rad,mat,dx in [('Iris',.024 if kind=='angel' else .017,eye,0),('Pupil',.014 if kind=='angel' else .010,black,side*.012)]:
   bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=rad,location=P(loc[0]+dx,loc[1],loc[2]));o=bpy.context.object;o.name=name;o.scale=(.45,1,1);o.data.materials.append(mat)
   for p in o.data.polygons:p.use_smooth=True
  pts=[(side*spec['w']*.75*math.sin(t*math.pi),spec['h']*.65*math.cos(t*math.pi),-.22+.025*math.sin(t*math.pi))for t in [i/20 for i in range(21)]];curve('Operculum',pts,.0025,gill)
 # Mouth crease follows the snout, distinct from eyes and body texture.
 curve('Mouth',[(-spec['w']*.13,-.008,-.432),(0,-.012,-.441),(spec['w']*.13,-.008,-.432)],.002,gill)
 tail=spec['tail'];edge=[]
 for i in range(49):
  a=-math.pi/2+i/48*math.pi;yy=math.sin(a)*tail;zz=.39+(.19 if kind=='guppy' else .14)*(1-.25*abs(math.sin(a)))
  if kind in ['neon','zebra']:zz-=.065*(1-abs(math.sin(a)))
  edge.append((0,yy,zz))
 caudal=fin('Caudal',(0,0,.365),edge,fins,ray)
 if kind=='angel':
  dorsal=[(0,.14+.34*math.sin(i/24*math.pi)**1.6,-.20+i/24*.56)for i in range(25)]
  anal=[(0,-.11-.29*math.sin(i/24*math.pi)**1.4,-.12+i/24*.47)for i in range(25)]
 else:
  dorsal=[(0,spec['h']*.53+(.12 if kind=='guppy' else .065)*math.sin(i/24*math.pi),-.13+i/24*.38)for i in range(25)]
  anal=[(0,-spec['h']*.4-.045*math.sin(i/18*math.pi),.1+i/18*.2)for i in range(19)]
 fin('Dorsal',(0,spec['h']*.4,.04),dorsal,fins,ray);fin('Anal',(0,-spec['h']*.35,.12),anal,fins,ray)
 for side in [-1,1]:
  root=(side*spec['w']*.65,-.02,-.16);edge=[(side*(spec['w']*.7+.085*math.sin(i/20*math.pi)),-.035-.055*math.sin(i/20*math.pi),-.16+i/20*.17)for i in range(21)];o=fin('Pectoral_'+str(side),root,edge,fins,ray)
  # Separate fin transform animation is visible even when the body is facing the viewer.
  for fr,ang in [(1,-.12),(9,.18),(17,-.12),(25,.18),(33,-.12)]:o.rotation_euler[1]=ang*side;o.keyframe_insert('rotation_euler',frame=fr)
  if kind=='angel':curve('Pelvic_filament',[(side*.025,-.12,-.12),(side*.035,-.36,-.06),(side*.04,-.55,.05)],.0035,ray)
 for fr,ang in [(1,-.15),(9,.15),(17,-.15),(25,.15),(33,-.15)]:caudal.rotation_euler[2]=ang;caudal.keyframe_insert('rotation_euler',frame=fr)
 bpy.context.scene.frame_start=1;bpy.context.scene.frame_end=33;bpy.context.scene.render.fps=24;bpy.context.scene.frame_set(1)
 bpy.ops.object.select_all(action='SELECT')
 bpy.ops.export_scene.gltf(filepath=str(OUT/(kind+('-low' if LOW else '')+'.glb')),export_format='GLB',export_animations=True,export_morph=True,export_normals=True,export_texcoords=True,export_materials='EXPORT',export_yup=True,export_animation_mode='SCENE')
 if not LOW:bpy.ops.wm.save_as_mainfile(filepath=str(SOURCE/(kind+'.blend')))
 return dict(id=kind,path=kind+'.glb',source='Original AQUA REALM anatomical mesh authoring',author='AQUA REALM project',license='Project original; redistribution requires project owner permission',features=['species-specific body silhouette','separate fin membranes and rays','PBR scale color and normal maps','body morph and fin transform animations'])
manifest=[build(k,v)for k,v in SPECS.items()]
if LOW:
 print('Generated low-detail meshes');sys.exit(0)
for m in manifest:m['sha256']=hashlib.sha256((OUT/m['path']).read_bytes()).hexdigest()
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Generated',len(manifest),'distinct original fish assets')
