import bpy, pathlib, math
from mathutils import Vector
root=pathlib.Path(__file__).resolve().parents[1]
for kind in ['neon','zebra','guppy','angel']:
 bpy.ops.wm.open_mainfile(filepath=str(root/'source-assets/fish'/f'{kind}.blend'))
 scene=bpy.context.scene;scene.frame_set(1);scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.resolution_x=256;scene.render.resolution_y=176;scene.render.resolution_percentage=100;scene.render.film_transparent=True
 scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.6,.7,.7,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.6
 bpy.ops.object.camera_add(location=(2,-.15,.25));camera=bpy.context.object;camera.rotation_euler=(Vector((0,0,0))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=1.65 if kind=="angel" else 1.25;scene.camera=camera
 for loc,power,size in [((1,-1,2),110,2),((0,1,1),70,1.5)]:
  bpy.ops.object.light_add(type='AREA',location=loc);light=bpy.context.object;light.data.energy=power;light.data.shape='DISK';light.data.size=size;light.rotation_euler=(-light.location).to_track_quat('-Z','Y').to_euler()
 scene.render.image_settings.file_format='PNG';scene.render.filepath=str(root/'public/assets/fish'/f'{kind}-preview.png');bpy.ops.render.render(write_still=True)
 print('Preview rendered',kind)
