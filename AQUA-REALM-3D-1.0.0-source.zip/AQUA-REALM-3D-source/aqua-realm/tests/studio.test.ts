import { resolveSphere, nearestPoint } from "../src/simulation/collision";
import { uniformScale } from "../src/utils/editorMath";
import { describe, it, expect, beforeEach } from "vitest";
import { readFileSync } from "node:fs";
import { speciesList } from "../src/assets/catalog";
import {
  makeFish,
  initialDocument,
  stepFish,
  validateDocument,
  defaultEcology,
  stepEcology,
  type Decoration,
} from "../src/simulation/model";
import {
  equipment,
  effectiveEnvironment,
  resizePositions,
} from "../src/simulation/devices";
import { recordTrend } from "../src/simulation/trends";
import { boxesOverlap, collider } from "../src/simulation/collision";
import { useAquarium } from "../src/stores/aquarium";
function glb(name: string) {
  const b = readFileSync(name),
    length = b.readUInt32LE(12);
  return JSON.parse(b.toString("utf8", 20, 20 + length));
}
describe("authored species and LOD assets", () => {
  it("has five genuinely separate models, four with native morph and fin animation", () => {
    expect(speciesList).toHaveLength(5);
    const layouts = new Set<string>();
    for (const spec of speciesList) {
      const model = glb("public/" + spec.asset.slice(2));
      layouts.add(
        JSON.stringify(
          model.accessors.map((a: Record<string, unknown>) => [
            a.count,
            a.min,
            a.max,
          ]),
        ),
      );
      if (spec.id !== "barramundi") {
        expect(model.animations.length).toBeGreaterThan(0);
        expect(
          model.meshes.some((m: any) =>
            m.primitives.some((p: any) => p.targets?.length > 0),
          ),
        ).toBe(true);
        expect(model.materials.some((m: any) => m.normalTexture)).toBe(true);
        const low = glb(
          "public/" + spec.asset.slice(2).replace(".glb", "-low.glb"),
        );
        const triangles = (m: any) =>
          m.meshes
            .flatMap((v: any) => v.primitives)
            .reduce(
              (n: number, v: any) =>
                n +
                (v.indices !== undefined ? m.accessors[v.indices].count : 0) /
                  3,
              0,
            );
        expect(triangles(low)).toBeLessThan(triangles(model));
      }
    }
    expect(layouts.size).toBe(5);
  });
});
describe("species behavior", () => {
  it("applies alignment/cohesion only to schooling fish", () => {
    const d = initialDocument(),
      a = makeFish(1, "neon"),
      b = makeFish(2, "neon");
    a.position = [0, 1, 0];
    b.position = [0.7, 1, 0];
    a.hunger = b.hunger = 0.1;
    stepFish([a, b], [], [], d.tank, d.environment, d.ecology, 1 / 30, 0);
    expect(a.state).toBe("群游");
    const c = makeFish(1, "angel"),
      e = makeFish(2, "angel");
    c.position = [0, 1, 0];
    e.position = [0.7, 1, 0];
    c.hunger = e.hunger = 0.1;
    stepFish([c, e], [], [], d.tank, d.environment, d.ecology, 1 / 30, 0);
    expect(c.state).toBe("巡游");
  });
  it("uses species temperature tolerances rather than one universal range", () => {
    const d = initialDocument(),
      a = makeFish(0, "zebra"),
      b = makeFish(0, "angel");
    a.health = b.health = 0.8;
    stepFish(
      [a, b],
      [],
      [],
      d.tank,
      d.environment,
      { ...d.ecology, waterTemperature: 29 },
      60,
      0,
    );
    expect(a.health).toBeLessThan(b.health);
  });
  it("disturbance recovers instead of remaining in a permanent panic state", () => {
    const d = initialDocument(),
      a = makeFish(0, "guppy");
    a.alert = 0.02;
    stepFish([a], [], [], d.tank, d.environment, d.ecology, 0.01, 0);
    expect(a.state).toBe("受扰");
    stepFish([a], [], [], d.tank, d.environment, d.ecology, 0.1, 0.1);
    expect(a.state).not.toBe("受扰");
  });
  it("floating food stays at the surface before eventually sinking", () => {
    const d = initialDocument(),
      food = [
        {
          id: 1,
          position: [0, 3, 0] as [number, number, number],
          age: 0,
          mode: "floating" as const,
        },
      ];
    stepFish([], food, [], d.tank, d.environment, d.ecology, 1, 0);
    expect(food[0].position[1]).toBe(3);
    stepFish([], food, [], d.tank, d.environment, d.ecology, 51, 1);
    expect(food[0].position[1]).toBeLessThan(3);
  });
});
describe("equipment is not decorative", () => {
  it("removing all devices disables filtering, illumination and heating", () => {
    const d = initialDocument(),
      power = equipment([], d.environment);
    expect(power.filter).toBe(0);
    expect(power.brightness).toBe(0);
    expect(power.heater).toBe(0);
    expect(power.bubbles).toBe(0);
  });
  it("power and switches scale actual outputs", () => {
    const d = initialDocument(),
      items: Decoration[] = [
        {
          id: "filter",
          name: "filter",
          kind: "filter",
          position: [0, 0, 0],
          rotation: 0,
          scale: 1,
          variant: 0,
          power: 0.5,
          enabled: true,
        },
      ];
    expect(equipment(items, d.environment).filter).toBeCloseTo(0.4);
    items[0].enabled = false;
    expect(effectiveEnvironment(items, d.environment).flow).toBe(0);
  });
  it("an unheated tank drifts toward ambient rather than target temperature", () => {
    const d = initialDocument(),
      withHeater = stepEcology(
        defaultEcology,
        { ...d.environment, temperature: 30 },
        5,
        0,
        20,
        1,
      ),
      without = stepEcology(
        defaultEcology,
        { ...d.environment, temperature: 30 },
        5,
        0,
        20,
        0,
      );
    expect(withHeater.waterTemperature).toBeGreaterThan(26);
    expect(without.waterTemperature).toBeLessThan(26);
  });
});
describe("recorded trends and saves", () => {
  it("samples actual elapsed time and values, pauses without inventing samples", () => {
    const eco = { ...defaultEcology, elapsed: 1, oxygen: 6.5 };
    const first = recordTrend([], eco, 26);
    expect(first[0].oxygen).toBe(6.5);
    expect(recordTrend(first, eco, 26)).toBe(first);
    const next = recordTrend(first, { ...eco, elapsed: 6, oxygen: 7.1 }, 25);
    expect(next[1].oxygen).toBe(7.1);
    expect(next[1].temperature).toBe(25);
  });
  it("migrates stage A saves, and rejects malformed history", () => {
    const raw: any = initialDocument();
    delete raw.substrate;
    delete raw.background;
    delete raw.trend;
    delete raw.food;
    delete raw.ecology.waterTemperature;
    delete raw.fish[0].species;
    const doc = validateDocument(raw);
    expect(doc.fish[0].species).toBe("barramundi");
    expect(doc.trend).toEqual([]);
    expect(raw.fish[0].species).toBeUndefined();
    expect(() =>
      validateDocument({ ...doc, trend: [{ time: 1, oxygen: "bad" }] }),
    ).toThrow();
  });
  it("preserves relative positions while changing tank dimensions", () => {
    const objects = [{ position: [1, 1, -1] as [number, number, number] }],
      old = { width: 6, height: 3, depth: 3 },
      next = { width: 9, height: 4.5, depth: 4.5 };
    expect(resizePositions(objects, old, next)[0].position).toEqual([
      1.5, 1.5, -1.5,
    ]);
    expect(objects[0].position).toEqual([1, 1, -1]);
  });
  it("does not drop food state during save document validation", () => {
    const doc = initialDocument();
    doc.food = [{ id: 1, position: [0, 1, 0], age: 3, mode: "floating" }];
    expect(validateDocument(JSON.parse(JSON.stringify(doc))).food[0].age).toBe(
      3,
    );
  });
});
describe("oriented placement collisions", () => {
  it("rejects actual overlapping rotated wood, permits vertically separated objects", () => {
    const a: Decoration = {
      id: "a",
      name: "wood",
      kind: "wood",
      position: [0, 0.2, 0],
      rotation: Math.PI / 4,
      scale: 1,
      variant: 0,
    };
    expect(
      boxesOverlap(
        collider(a),
        collider({ ...a, id: "b", position: [0.2, 0.2, 0.2] }),
      ),
    ).toBe(true);
    expect(
      boxesOverlap(
        collider(a),
        collider({ ...a, id: "b", position: [0, 2, 0] }),
      ),
    ).toBe(false);
  });
});
describe("studio operations", () => {
  beforeEach(() =>
    useAquarium.setState({
      doc: initialDocument(),
      history: [],
      future: [],
      food: [],
      selected: null,
    }),
  );
  it("adds requested fish species and allows material undo", () => {
    const s = useAquarium.getState();
    s.add("fish", "guppy");
    expect(useAquarium.getState().doc.fish.at(-1)?.species).toBe("guppy");
    s.setSurface("substrate", "black");
    expect(useAquarium.getState().doc.substrate).toBe("black");
    s.undo();
    expect(useAquarium.getState().doc.substrate).toBe("natural");
  });
  it("device disable can be undone", () => {
    const s = useAquarium.getState(),
      filter = s.doc.decorations.find((d) => d.kind === "filter")!;
    s.checkpoint();
    s.updateItem(filter.id, { enabled: false });
    expect(
      equipment(useAquarium.getState().doc.decorations, s.doc.environment)
        .filter,
    ).toBe(0);
    s.undo();
    expect(
      equipment(useAquarium.getState().doc.decorations, s.doc.environment)
        .filter,
    ).toBeGreaterThan(0);
  });
});

describe("complete scene restoration", () => {
  it("restores default state with an undo path for the previous layout", () => {
    const doc = initialDocument();
    useAquarium.setState({ doc, history: [], future: [], food: [] });
    useAquarium.getState().setSurface("substrate", "black");
    useAquarium.getState().resetScene();
    expect(useAquarium.getState().doc.substrate).toBe("natural");
    useAquarium.getState().undo();
    expect(useAquarium.getState().doc.substrate).toBe("black");
  });
  it("retains distinct positions when resized instead of stacking all fish at the center", () => {
    const doc = initialDocument();
    useAquarium.setState({ doc, history: [], future: [], food: [] });
    const old = doc.fish[0].position[0];
    useAquarium.getState().resize({ width: 8, height: 4, depth: 3 });
    const next = useAquarium.getState().doc;
    expect(next.fish[0].position[0]).toBeCloseTo((old * 8) / 6);
    expect(new Set(next.fish.map((f) => f.position.join(","))).size).toBe(
      next.fish.length,
    );
  });
  it("keeps trend storage bounded during long simulations", () => {
    let samples: ReturnType<typeof recordTrend> = [];
    for (let i = 0; i < 600; i++)
      samples = recordTrend(samples, { ...defaultEcology, elapsed: i * 5 }, 26);
    expect(samples).toHaveLength(360);
    expect(samples[0].time).toBe(1200);
  });
});

it("assigns unique food ids even for immediate repeated feed actions", () => {
  useAquarium.setState({ doc: initialDocument(), food: [] });
  useAquarium.getState().feed();
  useAquarium.getState().feed();
  const ids = useAquarium.getState().food.map((f) => f.id);
  expect(new Set(ids).size).toBe(ids.length);
});
it("low texture derivative preserves mesh layout and uses at most 1024px images", () => {
  const source = glb("public/assets/BarramundiFish.glb"),
    low = glb("public/assets/BarramundiFish-low.glb");
  const bytes = readFileSync("public/assets/BarramundiFish-low.glb"),
    jsonSize = bytes.readUInt32LE(12),
    binaryOffset = 20 + jsonSize + 8;
  for (const image of low.images) {
    const view = low.bufferViews[image.bufferView],
      offset = binaryOffset + view.byteOffset;
    expect(bytes.readUInt32BE(offset + 16)).toBeLessThanOrEqual(1024);
    expect(bytes.readUInt32BE(offset + 20)).toBeLessThanOrEqual(1024);
  }
  expect(low.accessors).toEqual(source.accessors);
  expect(low.materials).toEqual(source.materials);
  expect(
    readFileSync("public/assets/BarramundiFish-low.glb").length,
  ).toBeLessThan(readFileSync("public/assets/BarramundiFish.glb").length / 2);
});

it("scaling a single handle shrinks as well as enlarges uniformly", () => {
  expect(uniformScale([0.3, 0.6, 0.6], 0.6)).toBe(0.3);
  expect(uniformScale([0.6, 0.9, 0.6], 0.6)).toBe(0.9);
  expect(uniformScale([0.3, 0.3, 0.3], 0.6)).toBe(0.3);
});

it("loads saved playback, camera and quality preferences", () => {
  const doc = initialDocument();
  doc.view = {
    camera: "follow",
    quality: "low",
    speed: 2,
    playing: false,
    sensitivity: 1.4,
    cameraSpeed: 1.5,
    editing: false,
    selected: doc.fish[0].id,
  };
  useAquarium.getState().importText(JSON.stringify(doc));
  const s = useAquarium.getState();
  expect(s.mode).toBe("follow");
  expect(s.speed).toBe(2);
  expect(s.playing).toBe(false);
  expect(s.selected).toBe(doc.fish[0].id);
  expect(() =>
    validateDocument({ ...doc, view: { ...doc.view, speed: 999 } }),
  ).toThrow();
});

it("restores legacy implicit lighting and heating as visible editable devices", () => {
  const raw: any = initialDocument();
  delete raw.substrate;
  raw.decorations = raw.decorations.filter(
    (o: any) => !["light", "heater"].includes(o.kind),
  );
  const doc = validateDocument(raw);
  expect(
    equipment(doc.decorations, doc.environment).brightness,
  ).toBeGreaterThan(0);
  expect(equipment(doc.decorations, doc.environment).heater).toBe(1);
});

it("resolves a fish enclosed by newly placed scenery without putting it through the tank", () => {
  const box = {
      center: [0, 1, 0] as [number, number, number],
      half: [0.5, 0.5, 0.5] as [number, number, number],
      angle: Math.PI / 4,
    },
    p: [number, number, number] = [0, 1, 0],
    r = 0.12;
  const result = resolveSphere(p, r, box, {
    min: [-3, 0.2, -1.3],
    max: [3, 3, 1.3],
  })!;
  expect(result).toBeTruthy();
  const near = nearestPoint(result, box);
  expect(
    Math.hypot(...result.map((v, i) => v - near[i])),
  ).toBeGreaterThanOrEqual(r);
  expect(result.every(Number.isFinite)).toBe(true);
});
it("ordinary noncontact fish position is not moved by the collision safeguard", () => {
  expect(
    resolveSphere([2, 1, 0], 0.1, {
      center: [0, 1, 0],
      half: [0.4, 0.4, 0.4],
      angle: 0,
    }),
  ).toBeNull();
});

it("persists an individual swim clock through save/load instead of resetting LOD animation", () => {
  const d = initialDocument(),
    f = d.fish[0];
  stepFish(d.fish, [], [], d.tank, d.environment, d.ecology, 0.1, 0);
  expect(f.swimTime).toBeGreaterThan(0);
  const loaded = validateDocument(JSON.parse(JSON.stringify(d)));
  expect(loaded.fish[0].swimTime).toBe(f.swimTime);
  (loaded.fish[0] as any).swimTime = NaN;
  expect(() => validateDocument(loaded)).toThrow();
});
