import { beforeEach, afterEach, it, expect } from "vitest";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import { initialDocument } from "../src/simulation/model";
const require = createRequire(import.meta.url),
  {
    SessionRepository,
    atomicWrite,
    parseScene,
  } = require("../electron/storage.cjs");
let dir: string;
beforeEach(async () => {
  dir = await fs.mkdtemp(path.join(os.tmpdir(), "aqua-storage-test-"));
});
afterEach(async () => {
  await fs.rm(dir, { recursive: true, force: true });
});
it("returns empty on a new Windows/user profile", async () => {
  const repo = new SessionRepository(dir);
  expect((await repo.load()).source).toBe("empty");
});
it("saves atomically and recovers the last good backup after damaged primary", async () => {
  const repo = new SessionRepository(dir),
    one = initialDocument();
  one.fish[0].name = "第一份";
  await repo.save(JSON.stringify(one));
  const two = structuredClone(one);
  two.fish[0].name = "第二份";
  await repo.save(JSON.stringify(two));
  expect(JSON.parse((await repo.load()).text).fish[0].name).toBe("第二份");
  await fs.writeFile(repo.primary, "broken JSON");
  const loaded = await repo.load();
  expect(loaded.source).toBe("backup");
  expect(JSON.parse(loaded.text).fish[0].name).toBe("第一份");
});
it("serializes concurrent autosaves instead of racing the temporary file", async () => {
  const repo = new SessionRepository(dir);
  await Promise.all(
    Array.from({ length: 8 }, (_, i) => {
      const d = initialDocument();
      d.fish[0].name = "鱼 " + i;
      return repo.save(JSON.stringify(d));
    }),
  );
  expect(JSON.parse((await repo.load()).text).fish[0].name).toBe("鱼 7");
  expect(await fs.readdir(dir)).not.toContain("last-session.json.tmp");
});
it("does not overwrite healthy backup with a corrupted primary", async () => {
  const repo = new SessionRepository(dir),
    text = JSON.stringify(initialDocument());
  await repo.save(text);
  await repo.save(text);
  await fs.writeFile(repo.primary, "bad");
  await repo.save(text);
  expect(await fs.readFile(repo.backup, "utf8")).toBe(text);
});
it("rejects malformed and excessive input before touching existing data", async () => {
  const repo = new SessionRepository(dir),
    text = JSON.stringify(initialDocument());
  await repo.save(text);
  expect(() => repo.save("bad")).toThrow();
  expect(() => parseScene("x".repeat(2_000_001))).toThrow();
  expect((await repo.load()).text).toBe(text);
});
it("keeps prior contents if atomic replacement fails", async () => {
  const target = path.join(dir, "existing-directory");
  await fs.mkdir(target);
  await fs.writeFile(path.join(target, "keep.txt"), "keep");
  await expect(atomicWrite(target, "new")).rejects.toThrow();
  expect(await fs.readFile(path.join(target, "keep.txt"), "utf8")).toBe("keep");
});
it("reports damage safely when neither primary nor backup is parseable", async () => {
  const repo = new SessionRepository(dir);
  await fs.writeFile(repo.primary, "bad");
  await fs.writeFile(repo.backup, "bad");
  expect(await repo.load()).toMatchObject({ text: null, source: "damaged" });
});
it("does not overwrite a healthy backup when renderer rejects semantic corruption", async () => {
  const repo = new SessionRepository(dir),
    good = JSON.stringify(initialDocument());
  await repo.save(good);
  await repo.save(good);
  const bad = initialDocument();
  (bad.fish[0] as any).position = ["bad", 0, 0];
  await fs.writeFile(repo.primary, JSON.stringify(bad));
  expect((await repo.load(true)).source).toBe("backup");
  await repo.save(good);
  expect(await fs.readFile(repo.backup, "utf8")).toBe(good);
});

it("fits the desktop window inside a small/high-DPI work area", () => {
  const { windowSize } = require("../electron/window-size.cjs");
  const bounds = windowSize({ width: 1280, height: 680 });
  expect(bounds.width).toBeLessThanOrEqual(1280);
  expect(bounds.height).toBeLessThanOrEqual(680);
  expect(bounds.minHeight).toBeLessThanOrEqual(bounds.height);
});
it("retains the intended large layout on a full desktop display", () => {
  const { windowSize } = require("../electron/window-size.cjs");
  expect(windowSize({ width: 1920, height: 1040 })).toMatchObject({
    width: 1540,
    height: 1000,
    minWidth: 1024,
  });
});
