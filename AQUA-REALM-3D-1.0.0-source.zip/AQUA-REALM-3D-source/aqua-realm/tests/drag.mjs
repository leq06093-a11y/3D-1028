import { enterAquarium } from "./helpers/ui.mjs";
import { chromium } from "playwright";
import { PNG } from "pngjs";
import fs from "node:fs/promises";
const browser = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_PATH ||
    (process.platform === "win32"
      ? chromium.executablePath()
      : "/usr/bin/chromium"),
  headless: true,
  args: [
    "--no-sandbox",
    "--enable-unsafe-swiftshader",
    "--use-gl=angle",
    "--use-angle=swiftshader",
  ],
});
try {
  const page = await browser.newPage({
      viewport: { width: 1536, height: 1000 },
    }),
    errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(process.env.AQUA_TEST_URL || "http://127.0.0.1:5180/");
  await enterAquarium(page);
  await page.getByRole("combobox", { name: "画质" }).selectOption("low");
  await page.getByRole("button", { name: "暂停", exact: true }).click();
  const doc = JSON.parse(await fs.readFile("artifacts/scene.json", "utf8"));
  delete doc.view;
  doc.fish = [];
  doc.decorations = [
    {
      id: "drag-rock",
      kind: "rock",
      name: "拖拽测试石",
      position: [0, 0.2, 0],
      rotation: 0,
      scale: 0.6,
      variant: 0,
    },
  ];
  const chooser = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "加载场景" }).click();
  await (
    await chooser
  ).setFiles({
    name: "drag.json",
    mimeType: "application/json",
    buffer: Buffer.from(JSON.stringify(doc)),
  });
  await page.getByRole("button", { name: "自由造景", exact: true }).click();
  await page.waitForTimeout(800);
  // Select the actual rock through the view. Its projected position is near the lower center.
  const box = await page.locator("canvas").boundingBox();
  let selected = false;
  for (const dy of [80, 40, 120, 0]) {
    for (const dx of [0, 25, -25]) {
      await page.mouse.click(
        box.x + box.width / 2 + dx,
        box.y + box.height / 2 + dy,
      );
      if (
        await page
          .getByRole("spinbutton", { name: "位置 X", exact: true })
          .count()
      ) {
        selected = true;
        break;
      }
    }
    if (selected) break;
  }
  if (!selected) throw Error("Rock raycast failed");
  await page.waitForTimeout(500);
  const png = PNG.sync.read(
    await page.screenshot({ path: "artifacts/drag-before.png" }),
  );
  const red = [];
  for (let y = Math.ceil(box.y + 60); y < box.y + box.height - 100; y++)
    for (let x = Math.ceil(box.x + 50); x < box.x + box.width - 50; x++) {
      const i = (y * png.width + x) * 4,
        r = png.data[i],
        g = png.data[i + 1],
        b = png.data[i + 2];
      if (r > 160 && r > g * 2 && r > b * 2) red.push([x, y]);
    }
  if (red.length < 4) throw Error("No visible red X-axis handle");
  const x = red.reduce((s, p) => s + p[0], 0) / red.length,
    y = red.reduce((s, p) => s + p[1], 0) / red.length;
  const field = page.getByRole("spinbutton", { name: "位置 X", exact: true }),
    before = +(await field.inputValue());
  await page.mouse.move(x, y);
  await page.mouse.down();
  await page.mouse.move(x + 60, y, { steps: 12 });
  await page.mouse.up();
  await page.waitForTimeout(500);
  const after = +(await field.inputValue());
  if (Math.abs(after - before) < 0.01)
    throw Error(
      `Drag did not update persisted coordinates: ${before}, ${after}`,
    );
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "保存场景" }).click();
  const d = await download;
  await d.saveAs("artifacts/drag-save.json");
  const saved = JSON.parse(
    await fs.readFile("artifacts/drag-save.json", "utf8"),
  );
  if (Math.abs(saved.decorations[0].position[0] - after) > 0.02)
    throw Error("Saved coordinate mismatch");
  await page.screenshot({ path: "artifacts/drag-after.png" });
  console.log(
    "Actual X-handle drag and saved coordinates: PASS",
    before,
    "->",
    after,
  );
  console.log("errors:", errors);
  await fs.writeFile(
    "artifacts/drag-report.json",
    JSON.stringify(
      { before, after, savedX: saved.decorations[0].position[0], errors },
      null,
      2,
    ),
  );
  if (errors.length) throw Error("Renderer error");
} finally {
  await browser.close();
}
