import { _electron as electron } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";
import { enterAquarium } from "./helpers/ui.mjs";
const windows = process.platform === "win32",
  profile = await fs.mkdtemp(path.resolve("artifacts/packaged-profile-"));
const executablePath = windows
  ? path.resolve("release/win-unpacked/AQUA REALM 3D.exe")
  : path.resolve("node_modules/electron/dist/electron");
const args = [
  ...(windows ? [] : [path.resolve("release/win-unpacked/resources/app.asar")]),
  "--aqua-acceptance-test",
  "--no-sandbox",
  "--use-gl=angle",
  "--use-angle=swiftshader",
  "--enable-unsafe-swiftshader",
];
const app = await electron.launch({
  executablePath,
  args,
  cwd: process.cwd(),
  env: {
    ...process.env,
    AQUA_TEST_PROFILE: profile,
    DISPLAY: process.env.DISPLAY || ":89",
  },
  timeout: 60000,
});
const errors = [];
try {
  const p = await app.firstWindow();
  p.setDefaultTimeout(60000);
  p.on("pageerror", (e) => errors.push(e.message));
  p.on("console", (m) => {
    if (m.type() === "error") errors.push(m.text());
  });
  await enterAquarium(p);
  await p.getByRole("combobox", { name: "画质" }).selectOption("low");
  const appPath = await app.evaluate(({ app }) => app.getAppPath());
  if (!appPath.endsWith("app.asar")) throw Error("Not running packaged app");
  await p.addInitScript(() => {
    window.__aquaVolumeCompiled = false;
    const original = WebGL2RenderingContext.prototype.shaderSource;
    WebGL2RenderingContext.prototype.shaderSource = function (shader, source) {
      if (
        source.includes("uDensity") &&
        source.includes("uLamp") &&
        source.includes("uMin")
      )
        window.__aquaVolumeCompiled = true;
      return original.call(this, shader, source);
    };
  });
  await p.context().setOffline(true);
  await p.reload();
  await p.locator("canvas").waitFor({ timeout: 60000 });
  const model = await p.evaluate(async () => {
    const r = await fetch("./assets/fish/guppy-low.glb");
    const b = await r.arrayBuffer();
    return {
      status: r.status,
      magic: new TextDecoder().decode(b.slice(0, 4)),
      bytes: b.byteLength,
    };
  });
  if (model.status !== 200 || model.magic !== "glTF")
    throw Error("Packaged offline GLB failed");
  console.log("Actual packaged app.asar runs offline with local GLB: PASS");
  await p.getByRole("combobox", { name: "画质" }).selectOption("high");
  await p.waitForFunction(() => window.__aquaVolumeCompiled === true, {
    timeout: 90000,
  });
  if ((await p.getByRole("combobox", { name: "画质" }).inputValue()) !== "high")
    throw Error("High quality was not active");
  await p.waitForTimeout(500);
  const closeHint = p.getByRole("button", { name: "关闭提示", exact: true });
  if (await closeHint.count()) {
    await closeHint.click();
    await p.waitForTimeout(2200);
    if (await closeHint.count())
      throw Error("Dismissed performance hint reopened");
  }
  await p.screenshot({ path: "artifacts/ready-high-quality.png" });
  if (await p.locator(".canvas-error:visible").count())
    throw Error("Visible high-quality failure");
  console.log("High quality + volume shader rendered: PASS");
  await p.getByRole("combobox", { name: "画质" }).selectOption("low");
  await fs.writeFile(
    "artifacts/packaged-report.json",
    JSON.stringify(
      {
        appPath: appPath.endsWith("app.asar") ? "app.asar" : appPath,
        windowsExecutableTested: windows,
        offline: true,
        model,
        highQualityShader: true,
        errors,
      },
      null,
      2,
    ),
  );
  console.log("Packaged renderer errors:", errors);
  if (errors.length) throw Error("Packaged rendering error");
} finally {
  await app.close();
}
