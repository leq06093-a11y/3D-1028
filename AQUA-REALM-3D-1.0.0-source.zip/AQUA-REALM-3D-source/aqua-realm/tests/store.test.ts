import { beforeEach, it, expect } from "vitest";
import { useAquarium } from "../src/stores/aquarium";
import { initialDocument } from "../src/simulation/model";
beforeEach(() =>
  useAquarium.setState({
    doc: initialDocument(),
    history: [],
    future: [],
    food: [],
    selected: null,
    dirty: false,
  }),
);
it("undo restores the edited document and redo restores the new value", () => {
  useAquarium.getState().setEnvironment("temperature", 30);
  expect(useAquarium.getState().doc.environment.temperature).toBe(30);
  useAquarium.getState().undo();
  expect(useAquarium.getState().doc.environment.temperature).toBe(26);
  useAquarium.getState().redo();
  expect(useAquarium.getState().doc.environment.temperature).toBe(30);
});
it("deleting selected fish is reversible", () => {
  const s = useAquarium.getState(),
    id = s.doc.fish[0].id;
  const count = s.doc.fish.length;
  s.set({ selected: id });
  s.remove();
  expect(useAquarium.getState().doc.fish).toHaveLength(count - 1);
  s.undo();
  expect(useAquarium.getState().doc.fish).toHaveLength(count);
});
it("invalid loads leave the existing scene intact", () => {
  const old = JSON.stringify(useAquarium.getState().doc);
  useAquarium.getState().importText('{"invalid":true}');
  expect(JSON.stringify(useAquarium.getState().doc)).toBe(old);
  expect(useAquarium.getState().notice).toContain("加载失败");
});
it("water change lowers nitrogen and preserves fish", () => {
  const s = useAquarium.getState(),
    old = s.doc.ecology.nitrate;
  const ids = s.doc.fish.map((f) => f.id);
  s.care("water");
  expect(useAquarium.getState().doc.ecology.nitrate).toBeCloseTo(old * 0.7);
  expect(useAquarium.getState().doc.fish.map((f) => f.id)).toEqual(ids);
});
it("feeding creates actual edible particles", () => {
  useAquarium.getState().feed();
  expect(useAquarium.getState().food).toHaveLength(16);
});
