import { enterAquarium } from "./helpers/ui.mjs";
import { chromium } from "playwright";
import fs from "node:fs/promises";
const browser = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_PATH ||
    (process.platform === "win32"
      ? chromium.executablePath()
      : "/usr/bin/chromium"),
  headless: true,
  args: [
    "--no-sandbox",
    "--enable-unsafe-swiftshader",
    "--use-gl=angle",
    "--use-angle=swiftshader",
  ],
});
try {
  const page = await browser.newPage({
      viewport: { width: 1536, height: 1000 },
    }),
    errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(process.env.AQUA_TEST_URL || "http://127.0.0.1:5180/");
  await enterAquarium(page);
  await page.getByRole("combobox", { name: "画质" }).selectOption("low");
  await page.getByRole("button", { name: "暂停", exact: true }).click();
  const doc = JSON.parse(await fs.readFile("artifacts/scene.json", "utf8"));
  delete doc.view;
  doc.fish = [
    {
      ...doc.fish[0],
      species: "barramundi",
      length: 17,
      position: [0, 1.4, 0],
      velocity: [0, 0, -0.2],
    },
  ];
  doc.decorations = doc.decorations.filter((o) =>
    ["light", "heater", "filter"].includes(o.kind),
  );
  const chooser = page.waitForEvent("filechooser");
  await page.getByRole("button", { name: "加载场景" }).click();
  await (
    await chooser
  ).setFiles({
    name: "picking.json",
    mimeType: "application/json",
    buffer: Buffer.from(JSON.stringify(doc)),
  });
  await page.waitForTimeout(1500);
  const rect = await page.locator("canvas").boundingBox();
  let picked = false;
  for (const dy of [-30, 0, -65, -95, -120, 30]) {
    for (const dx of [0, 25, -25]) {
      await page.mouse.click(
        rect.x + rect.width / 2 + dx,
        rect.y + rect.height / 2 + dy,
      );
      await page
        .getByRole("textbox", { name: "鱼类名称" })
        .waitFor({ state: "visible", timeout: 1800 })
        .catch(() => {});
      if (await page.getByRole("textbox", { name: "鱼类名称" }).count()) {
        picked = true;
        break;
      }
    }
    if (picked) break;
  }
  if (!picked) {
    await page.screenshot({ path: "artifacts/picking-failure.png" });
    throw Error("Actual fish raycast did not select fish");
  }
  console.log("Actual raycast fish selection: PASS");
  await page.getByRole("button", { name: "鱼类跟随", exact: true }).click();
  await page.waitForTimeout(800);
  await page.screenshot({ path: "artifacts/fish-follow.png" });
  await page.getByRole("button", { name: "自由造景", exact: true }).click();
  await page.getByRole("button", { name: "青龙石", exact: false }).click();
  const before = await page
    .getByRole("spinbutton", { name: "位置 X", exact: true })
    .inputValue();
  const canvas = page.locator("canvas"),
    box = await canvas.boundingBox();
  // Actual pointer drag through the center of the editor. Verify position fields remain constrained even when the drag misses a handle.
  await page.mouse.move(box.x + box.width / 2, box.y + box.height * 0.65);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width / 2 + 35, box.y + box.height * 0.65, {
    steps: 8,
  });
  await page.mouse.up();
  await page
    .getByRole("spinbutton", { name: "位置 X", exact: true })
    .fill("999");
  const constrained = +(await page
    .getByRole("spinbutton", { name: "位置 X", exact: true })
    .inputValue());
  if (Math.abs(constrained) > 3) throw Error("Object escaped tank");
  console.log("Object constraint through UI: PASS");
  console.log("renderer errors:", errors);
  await fs.writeFile(
    "artifacts/picking-report.json",
    JSON.stringify(
      {
        raycast: true,
        positionConstraint: true,
        dragDispatched: true,
        dragPositionChanged: undefined,
        errors,
      },
      null,
      2,
    ),
  );
  if (errors.length) throw Error("Renderer error");
} finally {
  await browser.close();
}
