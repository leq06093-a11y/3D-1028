import { enterAquarium } from "./helpers/ui.mjs";
import { chromium } from "playwright";
import fs from "node:fs/promises";
await fs.mkdir("artifacts", { recursive: true });
const browser = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_PATH ||
    (process.platform === "win32"
      ? chromium.executablePath()
      : "/usr/bin/chromium"),
  headless: true,
  args: [
    "--no-sandbox",
    "--enable-unsafe-swiftshader",
    "--use-gl=angle",
    "--use-angle=swiftshader",
  ],
});
const page = await browser.newPage({
  viewport: { width: 1536, height: 1000 },
  deviceScaleFactor: 1,
});
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
page.on("console", (m) => {
  if (m.type() === "error") errors.push(m.text());
});
await page.goto(process.env.AQUA_TEST_URL || "http://127.0.0.1:5180/");
await enterAquarium(page);
await page.waitForTimeout(7000);
await page.screenshot({ path: "artifacts/phase-a-desktop.png" });
console.log("canvas:", await page.locator("canvas").count());
await page.getByRole("combobox", { name: "画质" }).selectOption("low");
await page.getByRole("button", { name: "暂停", exact: true }).click();
console.log(
  "pause button:",
  await page.getByRole("button", { name: "播放", exact: true }).count(),
);
await page.getByRole("button", { name: "投喂", exact: false }).click();
await page.waitForTimeout(500);
console.log(
  "feed:",
  await page.getByText("已投喂 16 粒", { exact: false }).count(),
);
await page.getByRole("button", { name: "生态水质" }).click();
console.log("ecology:", await page.getByText("氨氮", { exact: true }).count());
await page.getByRole("button", { name: "环境参数" }).click();
await page.getByRole("button", { name: "设置", exact: true }).click();
await page.getByRole("slider", { name: "镜头操作灵敏度" }).fill("1.5");
await page.getByRole("button", { name: "关闭设置" }).click();
await page.getByRole("button", { name: "自由造景", exact: true }).click();
await page.getByRole("button", { name: "青龙石", exact: false }).click();
console.log(
  "object properties:",
  await page.getByText("对象属性", { exact: false }).count(),
);
const x = page.getByRole("spinbutton", { name: "位置 X", exact: true });
await x.fill("1");
await page.getByRole("button", { name: "旋转", exact: true }).click();
await page.getByRole("button", { name: "撤销", exact: true }).click();
const download = page.waitForEvent("download");
await page.getByRole("button", { name: "保存场景", exact: true }).click();
const d = await download;
await d.saveAs("artifacts/scene.json");
console.log("save:", d.suggestedFilename());
const before = await fs.readFile("artifacts/scene.json", "utf8");
const chooser = page.waitForEvent("filechooser");
await page.getByRole("button", { name: "加载场景", exact: true }).click();
await (await chooser).setFiles("artifacts/scene.json");
await page.waitForTimeout(300);
console.log(
  "load:",
  await page.getByText("场景已加载", { exact: false }).count(),
);
await page.getByRole("button", { name: "全景观赏", exact: true }).click();
await page.getByRole("button", { name: "播放", exact: true }).click();
await page.waitForTimeout(1500);
await page.screenshot({ path: "artifacts/phase-a-after-edit.png" });
await page.setViewportSize({ width: 390, height: 844 });
await page.waitForTimeout(800);
await page.screenshot({ path: "artifacts/phase-a-mobile.png", fullPage: true });
console.log(
  "mobile overflow:",
  await page.evaluate(() => document.documentElement.scrollWidth > innerWidth),
);
console.log("errors:", errors);
await fs.writeFile(
  "artifacts/browser-report.json",
  JSON.stringify({ errors, savedSceneBytes: before.length }, null, 2),
);
await browser.close();
if (errors.length) process.exitCode = 1;
