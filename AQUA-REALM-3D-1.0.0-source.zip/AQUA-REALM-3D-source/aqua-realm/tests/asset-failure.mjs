import { enterAquarium } from "./helpers/ui.mjs";
import { chromium } from "playwright";
const b = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_PATH ||
    (process.platform === "win32"
      ? chromium.executablePath()
      : "/usr/bin/chromium"),
  headless: true,
  args: [
    "--no-sandbox",
    "--enable-unsafe-swiftshader",
    "--use-gl=angle",
    "--use-angle=swiftshader",
  ],
});
try {
  const p = await b.newPage();
  let fail = true;
  await p.route("**/fish/neon*.glb", (route) =>
    fail
      ? route.fulfill({ status: 404, body: "Missing test asset" })
      : route.continue(),
  );
  await p.goto(process.env.AQUA_TEST_URL || "http://127.0.0.1:5180/");
  await enterAquarium(p);
  await p
    .locator(".canvas-error")
    .filter({ hasText: "模型加载失败" })
    .waitFor({ state: "visible", timeout: 60000 });
  console.log(
    "Deliberately missing GLB gives a visible recovery message: PASS",
  );
  fail = false;
  await p
    .getByRole("button", { name: "重新加载三维场景", exact: true })
    .click();
  await p
    .locator(".model-progress")
    .waitFor({ state: "hidden", timeout: 60000 });
  if (await p.locator(".canvas-error:visible").count())
    throw Error("Resource retry failed");
  console.log("Actual resource retry after restoring asset: PASS");
} finally {
  await b.close();
}
