export async function enterAquarium(page) {
  await page.locator("canvas").waitFor({ timeout: 60000 });
  const start = page.getByRole("button", { name: "开始养鱼", exact: true });
  if (await start.count()) await start.click();
}
