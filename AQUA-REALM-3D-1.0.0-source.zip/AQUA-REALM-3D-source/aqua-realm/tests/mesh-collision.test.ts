import { afterEach, it, expect } from "vitest";
import * as THREE from "three";
import {
  registerMeshCollider,
  meshIntersects,
  meshSurface,
  clearMeshColliders,
} from "../src/simulation/meshCollisions";
import type { Decoration } from "../src/simulation/model";
afterEach(clearMeshColliders);
const item = (id: string, x = 0): Decoration => ({
  id,
  kind: "rock",
  name: id,
  position: [x, 0, 0],
  rotation: 0,
  scale: 1,
  variant: 0,
});
it("allows a mesh in the gap of a concave arrangement despite overlapping bounds", () => {
  const a = item("a"),
    root = new THREE.Group();
  for (const x of [-0.7, 0.7]) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1, 0.5));
    m.position.x = x;
    root.add(m);
  }
  registerMeshCollider(a, root);
  const b = item("b"),
    other = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.2));
  registerMeshCollider(b, other);
  expect(meshIntersects(a, b)).toBe(false);
  expect(meshIntersects(a, { ...b, position: [0.7, 0, 0] })).toBe(true);
});
it("detects full containment without relying on surface triangle intersections", () => {
  const a = item("a"),
    b = item("b");
  registerMeshCollider(a, new THREE.Mesh(new THREE.BoxGeometry(2, 2, 2)));
  registerMeshCollider(b, new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.2, 0.2)));
  expect(meshIntersects(a, b)).toBe(true);
});
it("samples actual surface normals and catches deep enclosure", () => {
  const a = item("a");
  registerMeshCollider(a, new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1)));
  const outside = meshSurface(a, [0.6, 0, 0], 0.2)!;
  expect(outside?.inside).toBe(false);
  expect(outside?.distance).toBeCloseTo(0.1);
  expect(outside?.normal[0]).toBeGreaterThan(0.9);
  const enclosed = meshSurface(a, [0, 0, 0], 0.1)!;
  expect(enclosed?.inside).toBe(true);
  expect(enclosed?.distance).toBeCloseTo(0.5);
});
it("uses updated rotation and scale without corrupting source geometry", () => {
  const a = item("a"),
    mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1));
  registerMeshCollider(a, mesh);
  const changed = {
    ...a,
    position: [2, 0, 0] as [number, number, number],
    scale: 2,
    rotation: Math.PI / 4,
  };
  expect(meshSurface(changed, [2, 0, 0], 0.1)?.inside).toBe(true);
  expect(mesh.geometry.attributes.position.count).toBe(24);
});
it("cleans up removed entries and uses fallback until a model is registered", () => {
  const a = item("a"),
    dispose = registerMeshCollider(
      a,
      new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1)),
    );
  dispose();
  expect(meshSurface(a, [0, 0, 0], 0.3)).toBeUndefined();
  expect(meshIntersects(a, item("b"))).toBeNull();
});
