import { describe, it, expect } from "vitest";
import {
  initialDocument,
  validateDocument,
  makeFish,
  stepFish,
  stepEcology,
  defaultEnvironment,
  defaultEcology,
  lightLevel,
  constrain,
  canPlace,
  type Food,
} from "../src/simulation/model";
function sim() {
  const doc = initialDocument();
  doc.decorations = [];
  return doc;
}
describe("fish simulation", () => {
  it("keeps every fish finite and inside tank after 10 simulated minutes", () => {
    const d = initialDocument(),
      food: Food[] = [];
    for (let i = 0; i < 18000; i++)
      stepFish(
        d.fish,
        food,
        d.decorations,
        d.tank,
        d.environment,
        d.ecology,
        1 / 30,
        i / 30,
      );
    for (const f of d.fish) {
      expect(f.position.every(Number.isFinite)).toBe(true);
      expect(Math.abs(f.position[0])).toBeLessThanOrEqual(
        d.tank.width / 2 - 0.5,
      );
      expect(f.position[1]).toBeGreaterThanOrEqual(0.4);
      expect(f.position[1]).toBeLessThanOrEqual(d.tank.height - 0.4);
      expect(Math.hypot(...f.velocity)).toBeLessThan(0.5);
    }
  });
  it("consumes nearby food and reduces hunger", () => {
    const d = sim(),
      f = makeFish(0);
    f.hunger = 0.8;
    f.position = [0, 1, 0];
    const food: Food[] = [{ id: 1, position: [0, 1, 0.01], age: 0 }];
    stepFish([f], food, [], d.tank, d.environment, d.ecology, 1 / 30, 0);
    expect(food).toHaveLength(0);
    expect(f.hunger).toBeLessThan(0.6);
  });
  it("does not allow two fish to consume the same particle", () => {
    const d = sim(),
      a = makeFish(1),
      b = makeFish(2);
    a.position = [0, 1, 0];
    b.position = [0, 1, 0];
    a.hunger = b.hunger = 0.8;
    const food: Food[] = [{ id: 1, position: [0, 1, 0], age: 0 }];
    stepFish([a, b], food, [], d.tank, d.environment, d.ecology, 1 / 30, 0);
    expect([a, b].filter((f) => f.hunger < 0.7)).toHaveLength(1);
  });
  it("slows activity at night", () => {
    const d = sim(),
      f = makeFish(0);
    stepFish(
      [f],
      [],
      [],
      d.tank,
      { ...d.environment, hour: 1 },
      d.ecology,
      1,
      0,
    );
    expect(f.state).toBe("休息");
  });
  it("expires uneaten food", () => {
    const d = sim(),
      food: Food[] = [{ id: 1, position: [0, 0.17, 0], age: 180 }];
    stepFish([], food, [], d.tank, d.environment, d.ecology, 1, 0);
    expect(food).toHaveLength(0);
  });
});
describe("ecology and lighting", () => {
  it("residual food worsens water more than an empty tank", () => {
    const a = stepEcology(defaultEcology, defaultEnvironment, 0, 0, 60),
      b = stepEcology(defaultEcology, defaultEnvironment, 20, 60, 60);
    expect(b.waste).toBeGreaterThan(a.waste);
    expect(b.ammonia).toBeGreaterThan(a.ammonia);
    expect(b.oxygen).toBeLessThan(a.oxygen);
  });
  it("filtering lowers ammonia", () => {
    const eco = { ...defaultEcology, ammonia: 1 };
    expect(
      stepEcology(eco, { ...defaultEnvironment, filter: 1 }, 5, 0, 60).ammonia,
    ).toBeLessThan(
      stepEcology(eco, { ...defaultEnvironment, filter: 0 }, 5, 0, 60).ammonia,
    );
  });
  it("daylight and night produce distinct actual light levels", () => {
    expect(lightLevel({ ...defaultEnvironment, hour: 12 })).toBeGreaterThan(
      lightLevel({ ...defaultEnvironment, hour: 1 }) * 5,
    );
    expect(
      lightLevel({ ...defaultEnvironment, hour: 1, dayCycle: false }),
    ).toBe(defaultEnvironment.brightness);
  });
});
describe("scene IO and editing", () => {
  it("round trips a complete document without aliasing", () => {
    const d = initialDocument(),
      v = validateDocument(JSON.parse(JSON.stringify(d)));
    expect(v).toEqual(d);
    v.fish[0].hunger = 1;
    expect(d.fish[0].hunger).not.toBe(1);
  });
  it.each([
    null,
    {},
    { version: 9 },
    { ...initialDocument(), fish: Array(81).fill({}) },
  ])("rejects malformed documents", (raw) => {
    expect(() => validateDocument(raw)).toThrow();
  });
  it("rejects invalid vectors and out of range settings", () => {
    const d = initialDocument();
    d.fish[0].position = [NaN, 1, 0];
    expect(() => validateDocument(d)).toThrow();
    const e = initialDocument();
    e.environment.clarity = 8;
    expect(() => validateDocument(e)).toThrow();
  });
  it("constrains object placement to the tank", () => {
    const d = initialDocument(),
      o = {
        ...d.decorations[0],
        position: [900, -3, -900] as [number, number, number],
      };
    const c = constrain(o, d.tank);
    expect(Math.abs(c.position[0])).toBeLessThan(3);
    expect(c.position[1]).toBe(0.12);
    expect(Math.abs(c.position[2])).toBeLessThan(1.3);
  });
  it("detects overlapping hard scenery", () => {
    const d = initialDocument(),
      o = d.decorations.find((x) => x.kind === "rock")!;
    expect(canPlace({ ...o, id: "new" }, [o])).toBe(false);
    expect(
      canPlace({ ...o, id: "new", position: [2, 0.15, 1] }, [
        ...d.decorations.filter((x) => x.kind === "plant"),
      ]),
    ).toBe(true);
  });
});
