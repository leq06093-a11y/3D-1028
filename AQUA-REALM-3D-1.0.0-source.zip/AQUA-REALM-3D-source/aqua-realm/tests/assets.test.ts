import { it, expect } from "vitest";
import { readFileSync, existsSync } from "node:fs";
it("bundles a valid real textured GLB, not geometry placeholders", () => {
  const b = readFileSync("public/assets/BarramundiFish.glb");
  expect(b.toString("ascii", 0, 4)).toBe("glTF");
  expect(b.readUInt32LE(4)).toBe(2);
  expect(b.readUInt32LE(8)).toBe(b.length);
  const n = b.readUInt32LE(12),
    json = JSON.parse(b.toString("utf8", 20, 20 + n));
  expect(json.meshes.length).toBeGreaterThan(0);
  expect(json.images.length).toBe(3);
  expect(json.materials[0].normalTexture).toBeTruthy();
  expect(json.materials[0].pbrMetallicRoughness.baseColorTexture).toBeTruthy();
  expect(existsSync("public/assets/BarramundiFish-source.md")).toBe(true);
});
it("records an explicit CC0 license from the upstream source", () => {
  const source = readFileSync("public/assets/BarramundiFish-source.md", "utf8");
  expect(source).toContain("Creative Commons Zero");
  expect(source).toContain("Microsoft");
});
