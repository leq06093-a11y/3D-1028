import { enterAquarium } from "./helpers/ui.mjs";
import { chromium } from "playwright";
import fs from "node:fs/promises";
const b = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_PATH ||
    (process.platform === "win32"
      ? chromium.executablePath()
      : "/usr/bin/chromium"),
  headless: true,
  args: [
    "--no-sandbox",
    "--enable-unsafe-swiftshader",
    "--use-gl=angle",
    "--use-angle=swiftshader",
  ],
});
try {
  const p = await b.newPage({ viewport: { width: 1536, height: 1000 } }),
    errors = [];
  p.setDefaultTimeout(60000);
  p.on("pageerror", (e) => errors.push(e.message));
  p.on("console", (m) => {
    if (m.type() === "error") errors.push(m.text());
  });
  await p.goto(process.env.AQUA_TEST_URL || "http://127.0.0.1:5181/");
  await enterAquarium(p);
  await p.getByRole("combobox", { name: "画质" }).selectOption("low");
  await p.getByRole("button", { name: "暂停", exact: true }).click();
  await p.getByRole("button", { name: "鱼类", exact: true }).click();
  if ((await p.locator(".asset-card").count()) !== 5)
    throw Error("Expected five fish species");
  for (const name of ["红绿灯", "斑马鱼", "孔雀鱼", "神仙鱼"]) {
    await p
      .locator(".asset-card")
      .filter({ has: p.getByText(name, { exact: true }) })
      .click();
    if (!(await p.getByRole("textbox", { name: "鱼类名称" }).count()))
      throw Error("Missing species properties");
  }
  console.log("Five species catalog and four native model selections: PASS");
  await p.getByRole("button", { name: "鱼类跟随", exact: true }).click();
  await p.waitForTimeout(1800);
  await p.screenshot({ path: "artifacts/studio-fish-follow.png" });
  await p.getByRole("button", { name: "底砂与背景", exact: true }).click();
  await p.getByRole("button", { name: "黑曜石砂", exact: false }).click();
  await p.getByRole("button", { name: "纯黑观赏背景", exact: true }).click();
  console.log("Substrate and background material switch: PASS");
  await p.getByRole("button", { name: "过滤与加热", exact: true }).click();
  await p
    .locator(".asset-card")
    .filter({ has: p.getByText("循环过滤器", { exact: true }) })
    .click();
  const toggle = p.getByRole("button", { name: "设备电源", exact: true });
  await toggle.click();
  if ((await toggle.getAttribute("aria-pressed")) !== "false")
    throw Error("Power toggle failed");
  console.log("Selected equipment power switch: PASS");
  await p.getByRole("button", { name: "旋转手柄", exact: true }).click();
  await p.getByRole("button", { name: "缩放手柄", exact: true }).click();
  await p.getByRole("button", { name: "移动", exact: true }).click();
  console.log("All editor tool modes: PASS");
  const download = p.waitForEvent("download");
  await p.getByRole("button", { name: "保存场景" }).click();
  const saved = await download;
  await saved.saveAs("artifacts/studio-save.json");
  const doc = JSON.parse(
    await fs.readFile("artifacts/studio-save.json", "utf8"),
  );
  if (
    doc.substrate !== "black" ||
    doc.background !== "black" ||
    doc.decorations.at(-1).enabled !== false
  )
    throw Error("State did not persist");
  if (!doc.fish.some((f) => f.species === "angel"))
    throw Error("Species did not save");
  const input = p.waitForEvent("filechooser");
  await p.getByRole("button", { name: "加载场景" }).click();
  await (await input).setFiles("artifacts/studio-save.json");
  await p.waitForTimeout(300);
  console.log("Species, surfaces and device state round trip: PASS");
  await p.getByRole("button", { name: "全景观赏", exact: true }).click();
  await p.getByRole("button", { name: "生态水质" }).click();
  await p.getByRole("button", { name: "5×", exact: true }).click();
  await p.getByRole("button", { name: "播放", exact: true }).click();
  await p
    .getByRole("img", { name: "溶解氧真实趋势图" })
    .waitFor({ state: "visible", timeout: 90000 });
  console.log("Real running history produced chart: PASS");
  await p.getByRole("button", { name: "暂停", exact: true }).click();
  await p.screenshot({ path: "artifacts/studio-ecology.png" });
  await p.getByRole("button", { name: "设置", exact: true }).click();
  if (!(await p.getByText("纹理数据估算", { exact: true }).count()))
    throw Error("Missing diagnostics");
  await p.getByRole("slider", { name: "镜头移动速度" }).fill("1.5");
  await p.getByRole("button", { name: "关闭设置" }).click();
  await p.setViewportSize({ width: 390, height: 844 });
  await p.waitForTimeout(500);
  const overflow = await p.evaluate(
    () => document.documentElement.scrollWidth > innerWidth,
  );
  console.log("Mobile overflow:", overflow);
  if (overflow) throw Error("Mobile overflow");
  console.log("Errors:", errors);
  await fs.writeFile(
    "artifacts/studio-ui-report.json",
    JSON.stringify(
      {
        speciesCatalog: 5,
        editorModes: true,
        devicePower: true,
        saveRoundTrip: true,
        liveHistory: true,
        mobileOverflow: overflow,
        errors,
      },
      null,
      2,
    ),
  );
  if (errors.length) throw Error("Renderer error");
} finally {
  await b.close();
}
