import { enterAquarium } from "./helpers/ui.mjs";
import { _electron as electron } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";
await fs.mkdir("artifacts", { recursive: true });
const filepath = path.resolve("artifacts/desktop-save.json");
const app = await electron.launch({
  executablePath: path.resolve(
    "node_modules/electron/dist/" +
      (process.platform === "win32" ? "electron.exe" : "electron"),
  ),
  args: [
    ".",
    "--no-sandbox",
    "--use-gl=angle",
    "--use-angle=swiftshader",
    "--enable-unsafe-swiftshader",
  ],
  cwd: process.cwd(),
  env: {
    ...process.env,
    DISPLAY: process.env.DISPLAY || ":88",
    AQUA_TEST_PROFILE: await fs.mkdtemp(path.resolve("artifacts/native-test-")),
  },
  timeout: 60000,
});
const errors = [];
try {
  const page = await app.firstWindow();
  page.on("pageerror", (e) => errors.push(e.message));
  await page.waitForSelector("canvas", { timeout: 60000 });
  await enterAquarium(page);
  await page.getByRole("combobox", { name: "画质" }).selectOption("low");
  console.log("desktop URL:", page.url());
  if (page.url() !== "aqua://app/index.html")
    throw Error("Incorrect desktop URL");
  console.log(
    "IPC bridge:",
    await page.evaluate(() => typeof window.aquaDesktop?.save),
  );
  const model = await page.evaluate(async () => {
    const r = await fetch("./assets/BarramundiFish.glb");
    return { status: r.status, bytes: (await r.arrayBuffer()).byteLength };
  });
  if (model.status !== 200 || model.bytes < 1e6) throw Error("Model failed");
  console.log("Model through desktop protocol:", model);
  await app.evaluate(({ dialog }, file) => {
    dialog.showSaveDialog = async () => ({ canceled: false, filePath: file });
    dialog.showOpenDialog = async () => ({
      canceled: false,
      filePaths: [file],
    });
  }, filepath);
  await page.getByRole("button", { name: "保存场景", exact: true }).click();
  await page.waitForFunction(
    () =>
      document.querySelector(".status-bar")?.textContent.includes("场景已保存"),
    { timeout: 30000 },
  );
  const scene = JSON.parse(await fs.readFile(filepath, "utf8"));
  if (
    scene.version !== 1 ||
    !scene.fish.length ||
    scene.view?.quality !== "low" ||
    !scene.fish.every((f) => typeof f.species === "string")
  )
    throw Error("Invalid saved scene");
  console.log("Desktop IPC saved JSON:", scene.fish.length, "fish");
  await page.getByRole("button", { name: "加载场景", exact: true }).click();
  await page.waitForFunction(() =>
    document.querySelector(".status-bar")?.textContent.includes("场景已加载"),
  );
  console.log("Desktop IPC load: PASS");
  await page.waitForTimeout(3000);
  await page.screenshot({ path: "artifacts/electron-desktop-final.png" });
  const visibleErrors = await page.locator(".canvas-error:visible").count();
  if (visibleErrors) throw Error("Visible WebGL error");
  console.log("renderer errors:", errors);
  await fs.writeFile(
    "artifacts/electron-report.json",
    JSON.stringify(
      {
        url: page.url(),
        model,
        errors,
        ipcSave: true,
        ipcLoad: true,
        visibleErrors,
      },
      null,
      2,
    ),
  );
  if (errors.length) throw Error("Renderer errors");
} finally {
  await app.close();
}
