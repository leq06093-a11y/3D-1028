import { _electron as electron } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";
import { enterAquarium } from "./helpers/ui.mjs";
await fs.mkdir("artifacts", { recursive: true });
const profile = await fs.mkdtemp(path.resolve("artifacts/resume-profile-"));
async function launch() {
  return electron.launch({
    executablePath: path.resolve(
      "node_modules/electron/dist/" +
        (process.platform === "win32" ? "electron.exe" : "electron"),
    ),
    args: [
      ".",
      "--no-sandbox",
      "--use-gl=angle",
      "--use-angle=swiftshader",
      "--enable-unsafe-swiftshader",
    ],
    cwd: process.cwd(),
    env: {
      ...process.env,
      DISPLAY: process.env.DISPLAY || ":88",
      AQUA_TEST_PROFILE: profile,
    },
    timeout: 60000,
  });
}
let app;
const errors = [];
try {
  app = await launch();
  let p = await app.firstWindow();
  p.on("pageerror", (e) => errors.push(e.message));
  await enterAquarium(p);
  await p.getByRole("combobox", { name: "画质" }).selectOption("low");
  await p.getByRole("button", { name: "暂停", exact: true }).click();
  // Export through actual main-process code; only the native path selection is supplied by this test.
  const diagnosticFile = path.resolve("artifacts/native-diagnostics.json");
  await app.evaluate(({ dialog }, file) => {
    dialog.showSaveDialog = async () => ({ canceled: false, filePath: file });
  }, diagnosticFile);
  await p.getByRole("button", { name: "设置", exact: true }).click();
  await p.getByRole("button", { name: "导出运行诊断", exact: true }).click();
  await p.waitForFunction(() =>
    document
      .querySelector(".status-bar")
      ?.textContent.includes("诊断报告已导出"),
  );
  await p.getByRole("button", { name: "关闭设置" }).click();
  const diag = JSON.parse(await fs.readFile(diagnosticFile, "utf8"));
  if (!diag.gpuFeatures || !diag.renderer?.render)
    throw Error("Diagnostic report lacks real renderer/GPU data");
  await p.getByRole("button", { name: "底砂与背景", exact: true }).click();
  await p.getByRole("button", { name: "黑曜石砂", exact: false }).click();
  await app.close();
  app = null;
  const scenePath = path.join(profile, "scenes/last-session.json");
  const first = JSON.parse(await fs.readFile(scenePath, "utf8"));
  if (
    first.substrate !== "black" ||
    first.view.playing !== false ||
    first.view.quality !== "low"
  )
    throw Error("Close flush did not persist latest state");
  console.log("Graceful exit flush: PASS");
  app = await launch();
  p = await app.firstWindow();
  p.on("pageerror", (e) => errors.push(e.message));
  await p.locator("canvas").waitFor({ timeout: 60000 });
  await p.getByText("已恢复上次鱼缸", { exact: false }).waitFor();
  if (await p.getByRole("button", { name: "开始养鱼", exact: true }).count())
    throw Error("Returning user was treated as first launch");
  if ((await p.getByRole("combobox", { name: "画质" }).inputValue()) !== "low")
    throw Error("Quality not restored");
  console.log("Relaunch restores actual disk state: PASS");
  await app.close();
  app = null;
  await fs.writeFile(scenePath, "deliberately damaged JSON");
  app = await launch();
  p = await app.firstWindow();
  p.on("pageerror", (e) => errors.push(e.message));
  await p.locator("canvas").waitFor({ timeout: 60000 });
  await p.getByText("自动存档有损坏，已从备份恢复", { exact: false }).waitFor();
  console.log("Corrupt primary -> backup recovery: PASS");
  await p.screenshot({ path: "artifacts/session-recovery.png" });
  await app.close();
  app = null;
  if (errors.length) throw Error(errors.join("\n"));
  await fs.writeFile(
    "artifacts/session-report.json",
    JSON.stringify(
      {
        closeFlush: true,
        relaunch: true,
        backupRecovery: true,
        diagnostics: true,
        rendererErrors: errors,
      },
      null,
      2,
    ),
  );
} finally {
  if (app) await app.close();
}
