export type SpeciesId = "barramundi" | "neon" | "zebra" | "guppy" | "angel";
export interface Species {
  id: SpeciesId;
  name: string;
  latin: string;
  asset: string;
  source: "CC0" | "原创建模";
  temperature: [number, number];
  length: [number, number];
  speed: number;
  schooling: number;
  territory: number;
  depth: [number, number];
  radius: number;
  modelLength: number;
  lifespanDays: number;
}
export const SPECIES: Record<SpeciesId, Species> = {
  barramundi: {
    id: "barramundi",
    name: "亚洲海鲈",
    latin: "Lates calcarifer",
    asset: "./assets/BarramundiFish.glb",
    source: "CC0",
    temperature: [22, 30],
    length: [17, 32],
    speed: 0.32,
    schooling: 0,
    territory: 0.3,
    depth: [0.28, 0.7],
    radius: 0.28,
    modelLength: 0.64,
    lifespanDays: 4000,
  },
  neon: {
    id: "neon",
    name: "红绿灯",
    latin: "Paracheirodon innesi",
    asset: "./assets/fish/neon.glb",
    source: "原创建模",
    temperature: [22, 27],
    length: [3.2, 4],
    speed: 0.26,
    schooling: 1,
    territory: 0,
    depth: [0.3, 0.65],
    radius: 0.09,
    modelLength: 0.96,
    lifespanDays: 1800,
  },
  zebra: {
    id: "zebra",
    name: "斑马鱼",
    latin: "Danio rerio",
    asset: "./assets/fish/zebra.glb",
    source: "原创建模",
    temperature: [20, 26],
    length: [4, 5],
    speed: 0.42,
    schooling: 0.8,
    territory: 0,
    depth: [0.55, 0.86],
    radius: 0.1,
    modelLength: 0.96,
    lifespanDays: 1200,
  },
  guppy: {
    id: "guppy",
    name: "孔雀鱼",
    latin: "Poecilia reticulata",
    asset: "./assets/fish/guppy.glb",
    source: "原创建模",
    temperature: [22, 28],
    length: [4, 5.8],
    speed: 0.22,
    schooling: 0.35,
    territory: 0,
    depth: [0.55, 0.88],
    radius: 0.11,
    modelLength: 1.01,
    lifespanDays: 900,
  },
  angel: {
    id: "angel",
    name: "神仙鱼",
    latin: "Pterophyllum scalare",
    asset: "./assets/fish/angel.glb",
    source: "原创建模",
    temperature: [24, 30],
    length: [10, 15],
    speed: 0.19,
    schooling: 0,
    territory: 0.85,
    depth: [0.3, 0.75],
    radius: 0.24,
    modelLength: 0.96,
    lifespanDays: 3000,
  },
};
export const speciesList = Object.values(SPECIES);
export const speciesOf = (id: SpeciesId | undefined) =>
  SPECIES[id || "barramundi"] || SPECIES.barramundi;
export const PLANTS = [
  { id: 0, name: "苦草 · 长叶", description: "Vallisneria" },
  { id: 1, name: "水榕 · 阔叶", description: "Anubias" },
  { id: 2, name: "绿菊 · 茎草", description: "Stem foliage" },
  { id: 3, name: "莫丝 · 簇生", description: "Moss cluster" },
  { id: 4, name: "矮珍珠 · 地毯", description: "Carpet plants" },
];
