import {
  memo,
  Suspense,
  useEffect,
  useMemo,
  useRef,
  useState,
  Component,
  type ReactNode,
} from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import {
  OrbitControls,
  Environment,
  Lightformer,
  ContactShadows,
  useProgress,
} from "@react-three/drei";
import * as THREE from "three";
import { useAquarium } from "../stores/aquarium";
import { stepFish, stepEcology, lightLevel, seeded } from "../simulation/model";
import { Fish } from "./Fish";
import { WaterVolume } from "./WaterVolume";
import { recoverGraphics } from "../utils/recover";
import { speciesList } from "../assets/catalog";
import { useGLTF } from "@react-three/drei";
import { effectiveEnvironment, equipment } from "../simulation/devices";
import { recordTrend } from "../simulation/trends";
import { DecorationObject } from "./Decorations";
import { surfaceTexture } from "./materials";
import {
  waterVertex,
  waterFragment,
  causticVertex,
  causticFragment,
} from "../shaders/water";
function Simulation() {
  const accumulator = useRef(0),
    elapsed = useRef(0),
    ui = useRef(0),
    fpsTime = useRef(0),
    frames = useRef(0);
  useFrame(({ gl, scene }, delta) => {
    const s = useAquarium.getState();
    const actual = effectiveEnvironment(s.doc.decorations, s.doc.environment),
      device = equipment(s.doc.decorations, s.doc.environment);
    frames.current++;
    fpsTime.current += delta;
    if (fpsTime.current > 1) {
      let bytes = 0;
      const unique = new Set<THREE.Texture>();
      scene.traverse((o) => {
        if (o instanceof THREE.Mesh) {
          for (const mat of Array.isArray(o.material)
            ? o.material
            : [o.material]) {
            for (const value of Object.values(mat)) {
              if (value instanceof THREE.Texture && !unique.has(value)) {
                unique.add(value);
                const image = value.image as
                  | { width?: number; height?: number }
                  | undefined;
                bytes += (image?.width ?? 0) * (image?.height ?? 0) * 4 * 1.333;
              }
            }
          }
        }
      });
      s.set({
        fps: Math.round((frames.current / fpsTime.current) * 10) / 10,
        diagnostics: {
          calls: gl.info.render.calls,
          triangles: gl.info.render.triangles,
          geometries: gl.info.memory.geometries,
          textures: gl.info.memory.textures,
          textureBytes: bytes,
        },
      });
      frames.current = 0;
      fpsTime.current = 0;
    }
    if (!s.playing || s.editing) return;
    accumulator.current += Math.min(delta, 0.1) * s.speed;
    let steps = 0;
    while (accumulator.current >= 1 / 30 && steps++ < 20) {
      const dt = 1 / 30;
      elapsed.current += dt;
      stepFish(
        s.doc.fish,
        s.food,
        s.doc.decorations,
        s.doc.tank,
        actual,
        s.doc.ecology,
        dt,
        elapsed.current,
      );
      s.doc.ecology = stepEcology(
        s.doc.ecology,
        actual,
        s.doc.fish.length,
        s.food.length,
        dt,
        device.heater,
      );
      s.doc.trend = recordTrend(
        s.doc.trend,
        s.doc.ecology,
        s.doc.ecology.waterTemperature,
      );
      s.doc.food = s.food;
      if (s.doc.environment.dayCycle)
        s.doc.environment.hour = (s.doc.environment.hour + dt / 180) % 24;
      accumulator.current -= dt;
    }
    ui.current += delta;
    if (ui.current > 0.3) {
      ui.current = 0;
      s.set({ tick: s.tick + 1, dirty: true });
    }
  });
  return null;
}
function Water() {
  const { width: w, height: h, depth: d } = useAquarium((s) => s.doc.tank);
  const surface = useRef<THREE.ShaderMaterial>(null),
    floor = useRef<THREE.ShaderMaterial>(null);
  const u = useMemo(
      () => ({
        uTime: { value: 0 },
        uLight: { value: 1 },
        uRipple: { value: new THREE.Vector2() },
        uRippleAge: { value: 100 },
      }),
      [],
    ),
    c = useMemo(() => ({ uTime: { value: 0 }, uLight: { value: 1 } }), []);
  useFrame(({ clock }) => {
    const s = useAquarium.getState();
    if (surface.current) {
      surface.current.uniforms.uRipple.value.set(s.ripple.x, s.ripple.z);
      surface.current.uniforms.uRippleAge.value =
        performance.now() / 1000 - s.ripple.at;
      surface.current.uniforms.uTime.value =
        clock.elapsedTime *
        (0.2 + effectiveEnvironment(s.doc.decorations, s.doc.environment).flow);
      surface.current.uniforms.uLight.value = lightLevel(
        effectiveEnvironment(s.doc.decorations, s.doc.environment),
      );
    }
    if (floor.current) {
      floor.current.uniforms.uTime.value = clock.elapsedTime;
      floor.current.uniforms.uLight.value = lightLevel(
        effectiveEnvironment(s.doc.decorations, s.doc.environment),
      );
    }
  });
  return (
    <>
      <mesh
        position={[0, h - 0.12, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        renderOrder={4}
        onDoubleClick={(event) => {
          event.stopPropagation();
          useAquarium
            .getState()
            .feed("floating", [event.point.x, event.point.z]);
        }}
      >
        <planeGeometry args={[w - 0.05, d - 0.05, 56, 32]} />
        <shaderMaterial
          ref={surface}
          uniforms={u}
          vertexShader={waterVertex}
          fragmentShader={waterFragment}
          transparent
          depthWrite={false}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh position={[0, 0.13, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[w - 0.08, d - 0.08]} />
        <shaderMaterial
          ref={floor}
          uniforms={c}
          vertexShader={causticVertex}
          fragmentShader={causticFragment}
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </>
  );
}
function Tank() {
  const tank = useAquarium((s) => s.doc.tank),
    { width: w, height: h, depth: d } = tank;
  const substrate = useAquarium((s) => s.doc.substrate),
    background = useAquarium((s) => s.doc.background);
  const sand = useMemo(
    () =>
      surfaceTexture(
        substrate === "black"
          ? "blackSand"
          : substrate === "white"
            ? "whiteSand"
            : "sand",
      ),
    [substrate],
  );
  useEffect(() => () => sand.dispose(), [sand]);
  return (
    <group>
      <mesh position={[0, -0.04, 0]} receiveShadow castShadow>
        <boxGeometry args={[w + 0.16, 0.23, d + 0.16]} />
        <meshStandardMaterial
          color="#1a2429"
          metalness={0.65}
          roughness={0.27}
        />
      </mesh>
      <mesh position={[0, 0.045, 0]} receiveShadow>
        <boxGeometry args={[w - 0.04, 0.13, d - 0.04]} />
        <meshStandardMaterial
          map={sand}
          bumpMap={sand}
          bumpScale={0.04}
          roughness={1}
        />
      </mesh>
      <mesh position={[0, h / 2, -d / 2]} receiveShadow>
        <boxGeometry args={[w, 0.01 + h, 0.035]} />
        <meshStandardMaterial
          color={
            background === "black"
              ? "#071013"
              : background === "slate"
                ? "#26303a"
                : "#17312e"
          }
          roughness={0.65}
        />
      </mesh>
      {[-1, 1].map((side) => (
        <mesh key={side} position={[(side * w) / 2, h / 2, 0]} renderOrder={5}>
          <boxGeometry args={[0.025, h, d]} />
          <meshPhysicalMaterial
            color="#d1f0e4"
            transmission={0.92}
            thickness={0.025}
            roughness={0.08}
            ior={1.5}
            transparent
            opacity={0.09}
            depthWrite={false}
          />
        </mesh>
      ))}
      <mesh position={[0, h / 2, d / 2]} renderOrder={6}>
        <planeGeometry args={[w, h]} />
        <meshPhysicalMaterial
          color="#bceadd"
          metalness={0.1}
          roughness={0.03}
          transparent
          opacity={0.035}
          depthWrite={false}
          side={THREE.DoubleSide}
        />
      </mesh>
      {[-1, 1].map((side) => (
        <group key={side}>
          {[-1, 1].map((z) => (
            <mesh key={z} position={[(side * w) / 2, h / 2, (z * d) / 2]}>
              <boxGeometry args={[0.022, h, 0.022]} />
              <meshStandardMaterial
                color="#a8cfbe"
                metalness={0.65}
                roughness={0.15}
                transparent
                opacity={0.55}
              />
            </mesh>
          ))}
          <mesh position={[(side * w) / 2, h, 0]}>
            <boxGeometry args={[0.03, 0.025, d]} />
            <meshStandardMaterial
              color="#b8e5d4"
              metalness={0.7}
              roughness={0.15}
            />
          </mesh>
        </group>
      ))}
      {[-1, 1].map((z) => (
        <mesh key={z} position={[0, h, (z * d) / 2]}>
          <boxGeometry args={[w, 0.025, 0.025]} />
          <meshStandardMaterial
            color="#afd7ca"
            metalness={0.65}
            roughness={0.2}
          />
        </mesh>
      ))}
      <Water />
    </group>
  );
}
function Particles() {
  const bubbles = useRef<THREE.InstancedMesh>(null),
    foodMesh = useRef<THREE.InstancedMesh>(null);
  const dust = useMemo(() => {
      const a = new Float32Array(300 * 3),
        r = seeded(31);
      for (let i = 0; i < 300; i++) {
        a[i * 3] = (r() - 0.5) * 5.8;
        a[i * 3 + 1] = r() * 3.2;
        a[i * 3 + 2] = (r() - 0.5) * 2.4;
      }
      return a;
    }, []),
    dummy = useMemo(() => new THREE.Object3D(), []);
  useFrame(({ clock }) => {
    const s = useAquarium.getState(),
      t = clock.elapsedTime,
      h = s.doc.tank.height;
    const actual = effectiveEnvironment(s.doc.decorations, s.doc.environment);
    const n = Math.floor(actual.bubbles * 70);
    const emitter = s.doc.decorations.find(
        (o) => o.kind === "filter" && o.enabled !== false && (o.power ?? 1) > 0,
      ),
      origin = emitter?.position ?? [0, 0.1, 0];
    if (bubbles.current) {
      bubbles.current.count = n;
      for (let i = 0; i < n; i++) {
        const phase = i * 0.73,
          y = (t * 0.22 + phase) % (h - 0.2);
        dummy.position.set(
          origin[0] + Math.sin(t + phase) * 0.06,
          ((y + origin[1] + 0.55) % (h - 0.2)) + 0.12,
          origin[2] + 0.17 + Math.cos(phase) * 0.06,
        );
        dummy.scale.setScalar(0.5 + (i % 4) * 0.13);
        dummy.updateMatrix();
        bubbles.current.setMatrixAt(i, dummy.matrix);
      }
      bubbles.current.instanceMatrix.needsUpdate = true;
    }
    if (foodMesh.current) {
      foodMesh.current.count = s.food.length;
      for (let i = 0; i < s.food.length; i++) {
        dummy.position.set(...s.food[i].position);
        dummy.scale.setScalar(1);
        dummy.updateMatrix();
        foodMesh.current.setMatrixAt(i, dummy.matrix);
      }
      foodMesh.current.instanceMatrix.needsUpdate = true;
    }
  });
  return (
    <>
      <instancedMesh ref={bubbles} args={[undefined, undefined, 100]}>
        <sphereGeometry args={[0.022, 8, 6]} />
        <meshPhysicalMaterial
          color="#a5e5dc"
          transparent
          opacity={0.3}
          metalness={0.2}
          roughness={0.08}
          depthWrite={false}
        />
      </instancedMesh>
      <instancedMesh ref={foodMesh} args={[undefined, undefined, 110]}>
        <sphereGeometry args={[0.022, 8, 6]} />
        <meshStandardMaterial color="#b4884e" roughness={0.9} />
      </instancedMesh>
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[dust, 3]} />
        </bufferGeometry>
        <pointsMaterial
          color="#a4c9a2"
          size={0.012}
          transparent
          opacity={0.18}
          depthWrite={false}
        />
      </points>
    </>
  );
}
function CameraRig() {
  const tankHeight = useAquarium((s) => s.doc.tank.height);
  const controls = useRef<any>(null),
    mode = useAquarium((s) => s.mode),
    sensitivity = useAquarium((s) => s.sensitivity),
    cameraSpeed = useAquarium((s) => s.cameraSpeed);
  const { camera } = useThree(),
    last = useRef("");
  const targetPosition = useRef(new THREE.Vector3(8, 5.1, 9)),
    targetLook = useRef(new THREE.Vector3(0, 1.5, 0)),
    transition = useRef(0);
  useFrame((_, dt) => {
    const s = useAquarium.getState(),
      h = s.doc.tank.height;
    if (mode !== last.current) {
      last.current = mode;
      transition.current = 1;
      targetPosition.current.set(
        ...((mode === "underwater"
          ? [0, h * 0.52, s.doc.tank.depth / 2 - 0.2]
          : mode === "free"
            ? [6, 4.4, 7.6]
            : [7.7, 4.4, 9]) as [number, number, number]),
      );
      targetLook.current.set(0, h * 0.46, 0);
    }
    if (mode === "follow") {
      const fish = s.doc.fish.find((f) => f.id === s.selected) || s.doc.fish[0];
      if (fish) {
        targetLook.current.set(...fish.position);
        targetPosition.current
          .copy(targetLook.current)
          .add(
            new THREE.Vector3(
              Math.max(0.2, fish.length / 20),
              Math.max(0.1, fish.length / 40),
              Math.max(0.45, (fish.length / 20) * 2.5),
            ),
          );
        transition.current = 1;
      }
    }
    if (transition.current && controls.current) {
      camera.position.lerp(
        targetPosition.current,
        1 - Math.exp(-Math.min(dt, 0.1) * 3 * cameraSpeed),
      );
      controls.current.target.lerp(
        targetLook.current,
        1 - Math.exp(-Math.min(dt, 0.1) * 3 * cameraSpeed),
      );
      if (
        camera.position.distanceTo(targetPosition.current) < 0.01 &&
        controls.current.target.distanceTo(targetLook.current) < 0.01 &&
        mode !== "follow"
      )
        transition.current = 0;
      controls.current.update();
    }
  });
  return (
    <OrbitControls
      ref={controls}
      target={[0, tankHeight * 0.46, 0]}
      makeDefault
      enableDamping
      dampingFactor={0.07}
      rotateSpeed={0.55 * sensitivity}
      zoomSpeed={0.7 * sensitivity}
      panSpeed={0.6 * sensitivity * cameraSpeed}
      minDistance={mode === "underwater" ? 0.2 : mode === "follow" ? 0.3 : 2}
      maxDistance={22}
      maxPolarAngle={Math.PI * 0.52}
      enablePan={mode === "free" || mode === "underwater"}
      onStart={() => {
        transition.current = 0;
      }}
    />
  );
}
function Lighting() {
  const requested = useAquarium((s) => s.doc.environment),
    items = useAquarium((s) => s.doc.decorations);
  const e = effectiveEnvironment(items, requested);
  useAquarium((s) => s.tick);
  const lamp = items.find(
      (o) => o.kind === "light" && o.enabled !== false && (o.power ?? 1) > 0,
    ),
    lampPos = lamp?.position ?? [0, 5, 0];
  const level = lightLevel(e),
    color = new THREE.Color().setRGB(
      1,
      Math.min(1, e.kelvin / 6500),
      Math.min(1, e.kelvin / 7500),
    );
  const { scene, gl } = useThree();
  useEffect(() => {
    scene.fog = new THREE.FogExp2(
      new THREE.Color("#102323"),
      (1 - e.clarity) * 0.065 +
        useAquarium.getState().doc.ecology.waste * 0.003,
    );
    return () => {
      scene.fog = null;
    };
  }, [e.clarity, scene, useAquarium.getState().doc.ecology.waste]);
  useEffect(() => {
    gl.toneMapping = THREE.ACESFilmicToneMapping;
    gl.toneMappingExposure = 1.1;
  }, [gl]);
  return (
    <>
      <ambientLight intensity={0.35 + level * 0.3} color="#9dbdc0" />
      <directionalLight
        position={[lampPos[0] - 1, lampPos[1] + 2, lampPos[2] + 1]}
        intensity={level * 3.4}
        color={color}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-camera-left={-5}
        shadow-camera-right={5}
        shadow-camera-top={5}
        shadow-camera-bottom={-5}
        shadow-bias={-0.0003}
      />
      <spotLight
        position={lampPos}
        target-position={[lampPos[0], 0, lampPos[2]]}
        angle={1.1}
        penumbra={0.8}
        intensity={level * 55}
        color="#d7f7d0"
        distance={14}
      />
      <Environment resolution={128}>
        <Lightformer
          form="rect"
          position={[0, 5, 0]}
          rotation={[Math.PI / 2, 0, 0]}
          scale={[8, 3, 1]}
          intensity={2}
        />
        <Lightformer
          form="rect"
          position={[-5, 2, 0]}
          rotation={[0, Math.PI / 2, 0]}
          scale={[2, 5, 1]}
          color="#78bbaa"
          intensity={1}
        />
        <Lightformer
          form="rect"
          position={[0, 2, 5]}
          scale={[5, 2, 1]}
          color="#7ca4b1"
          intensity={0.5}
        />
      </Environment>
    </>
  );
}
class SceneError extends Component<
  { children: ReactNode; onError: () => void },
  { error: boolean }
> {
  state = { error: false };
  static getDerivedStateFromError() {
    return { error: true };
  }
  componentDidCatch() {
    this.props.onError();
  }
  render() {
    return this.state.error ? null : this.props.children;
  }
}
export default memo(function Aquarium() {
  const decorations = useAquarium((s) => s.doc.decorations),
    fish = useAquarium((s) => s.doc.fish),
    quality = useAquarium((s) => s.quality);
  const [assetRevision, setAssetRevision] = useState(0);
  const [lost, setLost] = useState(false),
    [assetError, setAssetError] = useState(false);
  const { active } = useProgress();
  return (
    <div className="aquarium-canvas">
      {active && <div className="model-progress">正在加载真实鱼类模型…</div>}
      {assetError && (
        <div className="canvas-error">
          <div>模型加载失败。请保留完整程序文件夹。</div>
          <button
            onClick={() => {
              for (const spec of speciesList) {
                useGLTF.clear(spec.asset);
                useGLTF.clear(spec.asset.replace(".glb", "-low.glb"));
              }
              setAssetError(false);
              setAssetRevision((v) => v + 1);
            }}
          >
            重新加载三维场景
          </button>
        </div>
      )}
      {lost && (
        <div className="canvas-error">
          <div>显卡上下文已丢失，最近的自动存档会保留。</div>
          <button onClick={() => void recoverGraphics()}>
            以流畅画质重新打开
          </button>
        </div>
      )}
      <Canvas
        shadows={quality !== "low"}
        dpr={
          quality === "high" ? [1, 1.75] : quality === "medium" ? [1, 1.25] : 1
        }
        camera={{ position: [7.7, 4.4, 9], fov: 35, near: 0.03, far: 80 }}
        gl={{
          antialias: quality !== "low",
          alpha: true,
          powerPreference: "high-performance",
        }}
        onCreated={({ gl }) => {
          gl.domElement.addEventListener("webglcontextlost", () =>
            setLost(true),
          );
          gl.domElement.addEventListener("webglcontextrestored", () =>
            setLost(false),
          );
        }}
        onPointerMissed={() => useAquarium.getState().set({ selected: null })}
        fallback={
          <div className="canvas-error">
            无法启动 WebGL，请更新显卡驱动并开启浏览器硬件加速。
          </div>
        }
      >
        <CameraRig />
        <Lighting />
        <Simulation />
        <Tank />
        <WaterVolume />
        {decorations.map((item) => (
          <DecorationObject key={item.id} item={item} />
        ))}
        <SceneError key={assetRevision} onError={() => setAssetError(true)}>
          <Suspense fallback={null}>
            {fish.map((f) => (
              <Fish key={f.id} id={f.id} />
            ))}
          </Suspense>
        </SceneError>
        <Particles />
        <mesh
          position={[0, -0.26, 0]}
          rotation={[-Math.PI / 2, 0, 0]}
          receiveShadow
        >
          <planeGeometry args={[200, 200]} />
          <meshStandardMaterial color="#09171b" roughness={0.92} />
        </mesh>
        {quality === "high" && (
          <ContactShadows
            position={[0, -0.155, 0]}
            opacity={0.4}
            scale={15}
            blur={2.5}
            far={5}
            resolution={256}
            frames={1}
          />
        )}
      </Canvas>
    </div>
  );
});
