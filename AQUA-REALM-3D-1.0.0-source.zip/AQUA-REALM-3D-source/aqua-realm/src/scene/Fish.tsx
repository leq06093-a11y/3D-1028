import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";
import { useAquarium } from "../stores/aquarium";
import { speciesOf } from "../assets/catalog";
export const FISH_URL = "./assets/BarramundiFish.glb";
export function Fish({ id }: { id: string }) {
  const species = useAquarium(
      (s) => s.doc.fish.find((f) => f.id === id)?.species,
    ),
    spec = speciesOf(species),
    group = useRef<THREE.Group>(null),
    selected = useAquarium((s) => s.selected === id),
    quality = useAquarium((s) => s.quality);
  const [distant, setDistant] = useState(true),
    lodTime = useRef(0);
  const low =
    quality === "low" || (!selected && (distant || quality === "medium"));
  const { scene, animations } = useGLTF(
    low ? spec.asset.replace(".glb", "-low.glb") : spec.asset,
  );
  const uniforms = useMemo(
    () => ({
      uSwimTime: { value: 0 },
      uSwimPower: { value: 1 },
      uTurn: { value: 0 },
    }),
    [],
  );
  const model = useMemo(() => {
    const clone = scene.clone(true);
    clone.traverse((node) => {
      if (node instanceof THREE.Mesh) {
        node.castShadow = quality !== "low";
        node.receiveShadow = quality === "high";
        node.material = Array.isArray(node.material)
          ? node.material.map((m) => m.clone())
          : node.material.clone();
        if (node.morphTargetInfluences)
          node.morphTargetInfluences = [...node.morphTargetInfluences];
        if (spec.id === "barramundi") {
          const mat = node.material as THREE.MeshStandardMaterial;
          mat.roughness = 0.4;
          mat.metalness = 0.15;
          mat.onBeforeCompile = (shader) => {
            Object.assign(shader.uniforms, uniforms);
            shader.vertexShader =
              "uniform float uSwimTime;uniform float uSwimPower;uniform float uTurn;\n" +
              shader.vertexShader;
            shader.vertexShader = shader.vertexShader.replace(
              "#include <begin_vertex>",
              `#include <begin_vertex>\n float tail=smoothstep(-.12,.31,position.z); transformed.x+=sin(uSwimTime-position.z*12.)*tail*tail*.045*uSwimPower+uTurn*tail*.018;`,
            );
          };
          mat.customProgramCacheKey = () => "aqua-fish-deformation-v2";
        }
      }
    });
    return clone;
  }, [scene, uniforms, spec.id, quality]);
  const mixer = useMemo(() => {
    if (!animations.length) return null;
    const m = new THREE.AnimationMixer(model);
    for (const clip of animations) m.clipAction(clip).play();
    return m;
  }, [model, animations]);
  useEffect(
    () => () => {
      mixer?.stopAllAction();
      mixer?.uncacheRoot(model);
      model.traverse((o) => {
        if (o instanceof THREE.Mesh)
          (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) =>
            m.dispose(),
          );
      });
    },
    [model, mixer],
  );
  const scratch = useMemo(
      () => ({
        current: new THREE.Quaternion(),
        target: new THREE.Quaternion(),
        direction: new THREE.Vector3(),
        up: new THREE.Vector3(0, 1, 0),
        origin: new THREE.Vector3(),
        matrix: new THREE.Matrix4(),
      }),
      [],
    ),
    lastDirection = useRef(new THREE.Vector3(0, 0, -1));
  useFrame(({ camera }, dt) => {
    const s = useAquarium.getState(),
      f = s.doc.fish.find((f) => f.id === id);
    if (!f || !group.current) return;
    group.current.position.set(...f.position);
    lodTime.current += dt;
    if (lodTime.current > 0.75) {
      lodTime.current = 0;
      const distance = camera.position.distanceTo(group.current.position);
      setDistant((old) => (old ? distance > 6 : distance > 8));
    }
    const { direction, matrix, origin, up, target, current } = scratch;
    direction.set(...f.velocity).normalize();
    if (direction.lengthSq() > 0.01) {
      matrix.lookAt(origin, direction, up);
      target.setFromRotationMatrix(matrix);
      current
        .copy(group.current.quaternion)
        .slerp(target, 1 - Math.exp(-Math.min(dt, 0.1) * 5));
      group.current.quaternion.copy(current);
      uniforms.uTurn.value = THREE.MathUtils.clamp(
        (lastDirection.current.z * direction.x -
          lastDirection.current.x * direction.z) *
          4,
        -1,
        1,
      );
      lastDirection.current.copy(direction);
    }
    const speed = Math.hypot(...f.velocity);
    const animationTime =
      (f.swimTime ?? 0) +
      (f.phase / (Math.PI * 2)) * (animations[0]?.duration ?? 1);
    uniforms.uSwimTime.value = f.phase + (f.swimTime ?? 0) * 8;
    mixer?.setTime(animationTime);
    uniforms.uSwimPower.value = 0.5 + speed * 1.5;
    const scale = f.length / 20 / spec.modelLength;
    model.scale.setScalar(scale);
  });
  return (
    <group
      ref={group}
      onClick={(e) => {
        e.stopPropagation();
        const s = useAquarium.getState();
        s.set({
          selected: id,
          notice: "已选择" + spec.name + " · 右侧查看实时状态",
        });
      }}
    >
      <primitive object={model} dispose={null} />
      {selected && (
        <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, -0.08, 0]}>
          <ringGeometry
            args={[spec.radius * 1.25, spec.radius * 1.25 + 0.009, 48]}
          />
          <meshBasicMaterial
            color="#7ff5d4"
            side={THREE.DoubleSide}
            transparent
            opacity={0.8}
          />
        </mesh>
      )}
    </group>
  );
}
