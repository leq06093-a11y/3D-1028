import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import { TransformControls } from "@react-three/drei";
import * as THREE from "three";
import { constrain, canPlace, type Decoration } from "../simulation/model";
import { registerMeshCollider } from "../simulation/meshCollisions";
import { useAquarium } from "../stores/aquarium";
import { effectiveEnvironment } from "../simulation/devices";
import { rockGeometry, surfaceTexture } from "./materials";
import { foliageGeometry, foliageMaterial } from "./vegetation";
import { woodGeometry } from "./wood";
import { uniformScale } from "../utils/editorMath";
function Shape({ item }: { item: Decoration }) {
  const geom = useMemo(
    () =>
      item.kind === "rock"
        ? rockGeometry(item.variant)
        : item.kind === "plant"
          ? foliageGeometry(item.variant)
          : item.kind === "wood"
            ? woodGeometry(item.variant)
            : null,
    [item.kind, item.variant],
  );
  const texture = useMemo(
      () =>
        item.kind === "wood"
          ? surfaceTexture("wood")
          : item.kind === "rock"
            ? surfaceTexture("stone")
            : null,
      [item.kind],
    ),
    leafMat = useMemo(
      () => (item.kind === "plant" ? foliageMaterial(item.variant) : null),
      [item.kind, item.variant],
    ),
    plant = useRef<THREE.Group>(null);
  const swayPhase = useMemo(
    () => item.id.split("").reduce((n, c) => n + c.charCodeAt(0) * 0.037, 0),
    [item.id],
  );
  useEffect(
    () => () => {
      geom?.dispose();
      texture?.dispose();
      leafMat?.dispose();
    },
    [geom, texture, leafMat],
  );
  useFrame(({ clock }) => {
    const s = useAquarium.getState(),
      actual = effectiveEnvironment(s.doc.decorations, s.doc.environment);
    if (plant.current)
      plant.current.rotation.z =
        Math.sin(clock.elapsedTime * 0.9 + swayPhase) *
        0.045 *
        s.doc.environment.sway *
        (0.2 + actual.flow);
  });
  if (item.kind === "plant")
    return (
      <group ref={plant}>
        <mesh
          geometry={geom!}
          material={leafMat!}
          castShadow
          receiveShadow
          dispose={null}
        />
      </group>
    );
  if (item.kind === "rock")
    return (
      <mesh
        geometry={geom!}
        scale={[0.8, 0.7, 0.7]}
        castShadow
        receiveShadow
        dispose={null}
      >
        <meshStandardMaterial
          map={texture}
          roughness={0.9}
          bumpMap={texture}
          bumpScale={0.035}
        />
      </mesh>
    );
  if (item.kind === "wood")
    return (
      <mesh geometry={geom!} castShadow receiveShadow dispose={null}>
        <meshStandardMaterial
          map={texture}
          roughness={0.91}
          bumpMap={texture}
          bumpScale={0.035}
        />
      </mesh>
    );
  const active = item.enabled !== false,
    power = item.power ?? 1;
  if (item.kind === "filter")
    return (
      <group>
        <mesh position={[0, 0.48, 0]} castShadow>
          <boxGeometry args={[0.35, 0.95, 0.3]} />
          <meshStandardMaterial color="#17282a" roughness={0.6} />
        </mesh>
        {Array.from({ length: 7 }, (_, i) => (
          <mesh key={i} position={[0, 0.2 + i * 0.1, 0.16]}>
            <boxGeometry args={[0.26, 0.025, 0.02]} />
            <meshStandardMaterial color="#050e12" />
          </mesh>
        ))}
        <mesh position={[0, 1, 0]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.06, 0.06, 0.5, 12]} />
          <meshStandardMaterial color="#1a292b" />
        </mesh>
        <mesh position={[0, 0.86, 0.16]}>
          <sphereGeometry args={[0.02, 8, 6]} />
          <meshBasicMaterial color={active ? "#8bdba7" : "#7c4d3a"} />
        </mesh>
      </group>
    );
  if (item.kind === "heater")
    return (
      <group>
        <mesh position={[0, 0.6, 0]}>
          <cylinderGeometry args={[0.06, 0.06, 1.2, 16]} />
          <meshPhysicalMaterial
            color="#abb7b5"
            metalness={0.2}
            roughness={0.13}
            transparent
            opacity={0.65}
          />
        </mesh>
        <mesh position={[0, 0.4, 0]}>
          <cylinderGeometry args={[0.035, 0.035, 0.72, 12]} />
          <meshStandardMaterial
            color="#a68a6a"
            emissive={active ? "#a44c1d" : "#000000"}
            emissiveIntensity={0.3 * power}
          />
        </mesh>
        <mesh position={[0, 1.25, 0]}>
          <cylinderGeometry args={[0.08, 0.07, 0.2, 12]} />
          <meshStandardMaterial color="#273331" />
        </mesh>
      </group>
    );
  return (
    <group>
      <mesh castShadow>
        <boxGeometry args={[3.8, 0.075, 0.23]} />
        <meshStandardMaterial color="#27383b" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[0, -0.044, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[3.7, 0.19]} />
        <meshBasicMaterial
          color={active ? "#d8edcc" : "#23332d"}
          toneMapped={false}
        />
      </mesh>
    </group>
  );
}
export function DecorationObject({ item }: { item: Decoration }) {
  const selected = useAquarium((s) => s.selected === item.id),
    editing = useAquarium((s) => s.editing),
    tool = useAquarium((s) => s.editTool),
    vertical = useAquarium((s) => s.verticalEditing);
  const [object, setObject] = useState<THREE.Group | null>(null),
    [blocked, setBlocked] = useState(false);
  const geometryRoot = useRef<THREE.Group>(null);
  useLayoutEffect(() => {
    if (!geometryRoot.current || item.kind === "plant") return;
    return registerMeshCollider(item, geometryRoot.current);
  }, [
    item.id,
    item.kind,
    item.variant,
    item.position,
    item.rotation,
    item.scale,
  ]);
  return (
    <>
      <group
        ref={setObject}
        position={item.position}
        rotation={[0, item.rotation, 0]}
        scale={item.scale}
        onClick={(e) => {
          e.stopPropagation();
          useAquarium.getState().set({ selected: item.id });
        }}
      >
        <group ref={geometryRoot}>
          <Shape item={item} />
        </group>
        {selected && (
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.015, 0]}>
            <ringGeometry args={[0.55, 0.57, 48]} />
            <meshBasicMaterial
              color={blocked ? "#ed987f" : "#7be2c0"}
              side={THREE.DoubleSide}
            />
          </mesh>
        )}
      </group>
      {selected && editing && object && (
        <TransformControls
          object={object}
          mode={tool}
          size={0.7}
          showX={tool !== "rotate"}
          showY={tool === "rotate" || tool === "scale" || vertical}
          showZ={tool !== "rotate"}
          onObjectChange={() => {
            if (tool === "translate") {
              const limited = constrain(
                { ...item, position: object.position.toArray() },
                useAquarium.getState().doc.tank,
              );
              object.position.set(...limited.position);
            }
            const candidate = {
              ...item,
              position: object.position.toArray(),
              rotation: object.rotation.y,
              scale: uniformScale(
                [object.scale.x, object.scale.y, object.scale.z],
                item.scale,
              ),
            };
            setBlocked(
              !canPlace(candidate, useAquarium.getState().doc.decorations),
            );
          }}
          onMouseDown={() => useAquarium.getState().checkpoint()}
          onMouseUp={() => {
            const s = useAquarium.getState();
            const patch =
              tool === "translate"
                ? { position: object.position.toArray() }
                : tool === "rotate"
                  ? { rotation: object.rotation.y }
                  : {
                      scale: uniformScale(
                        [object.scale.x, object.scale.y, object.scale.z],
                        item.scale,
                      ),
                    };
            s.updateItem(item.id, patch);
            setBlocked(false);
            const latest = useAquarium
              .getState()
              .doc.decorations.find((o) => o.id === item.id);
            if (latest) {
              object.position.set(...latest.position);
              object.rotation.set(0, latest.rotation, 0);
              object.scale.setScalar(latest.scale);
            }
          }}
        />
      )}
    </>
  );
}
