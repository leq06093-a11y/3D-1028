import * as THREE from "three";
import { seeded } from "../simulation/model";
/** Tapered, bent branch networks with irregular cross-sections and buried root flares. */
export function woodGeometry(seed: number) {
  const pos: number[] = [],
    uv: number[] = [],
    indices: number[] = [],
    r = seeded(seed + 220);
  const branch = (
    start: THREE.Vector3,
    end: THREE.Vector3,
    radius: number,
    bend: number,
  ) => {
    const base = pos.length / 3,
      steps = 22,
      sides = 12,
      delta = end.clone().sub(start),
      tangent = delta.clone().normalize(),
      a = tangent
        .clone()
        .cross(new THREE.Vector3(0, 1, 0))
        .normalize();
    if (a.lengthSq() < 0.1) a.set(1, 0, 0);
    const b = tangent.clone().cross(a).normalize();
    for (let i = 0; i <= steps; i++) {
      const t = i / steps,
        center = start
          .clone()
          .lerp(end, t)
          .addScaledVector(a, Math.sin(t * Math.PI) * bend);
      for (let j = 0; j <= sides; j++) {
        const theta = (j / sides) * Math.PI * 2,
          thickness =
            radius * (1 - t * 0.93) * (1 + Math.sin(theta * 5 + t * 8) * 0.12);
        const v = center
          .clone()
          .addScaledVector(a, Math.cos(theta) * thickness)
          .addScaledVector(b, Math.sin(theta) * thickness);
        pos.push(v.x, v.y, v.z);
        uv.push(j / sides, t * 3);
      }
    }
    for (let i = 0; i < steps; i++)
      for (let j = 0; j < sides; j++) {
        const k = base + i * (sides + 1) + j;
        indices.push(
          k,
          k + 1,
          k + sides + 1,
          k + 1,
          k + sides + 2,
          k + sides + 1,
        );
      }
  };
  branch(
    new THREE.Vector3(-0.65, 0.13, -0.08),
    new THREE.Vector3(0.7, 0.39, 0.15),
    0.15,
    0.15,
  );
  branch(
    new THREE.Vector3(-0.25, 0.15, 0),
    new THREE.Vector3(-0.5, 0.85, -0.18),
    0.11,
    0.2,
  );
  branch(
    new THREE.Vector3(0.16, 0.29, 0.06),
    new THREE.Vector3(0.8, 0.62, -0.22),
    0.07,
    0.12,
  );
  for (let i = 0; i < 5; i++) {
    const a = r() * 6.28;
    branch(
      new THREE.Vector3(-0.25, 0.2, 0),
      new THREE.Vector3(Math.cos(a) * 0.65, 0.03, Math.sin(a) * 0.4),
      0.065,
      0.08,
    );
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}
