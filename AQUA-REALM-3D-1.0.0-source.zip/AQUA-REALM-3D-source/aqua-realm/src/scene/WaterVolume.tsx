import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useAquarium } from "../stores/aquarium";
import { effectiveEnvironment } from "../simulation/devices";
import { lightLevel } from "../simulation/model";
import { volumeVertex, volumeFragment } from "../shaders/volume";
export function WaterVolume() {
  const quality = useAquarium((s) => s.quality),
    tank = useAquarium((s) => s.doc.tank),
    material = useRef<THREE.ShaderMaterial>(null);
  const uniforms = useMemo(
    () => ({
      uMin: { value: new THREE.Vector3() },
      uMax: { value: new THREE.Vector3() },
      uLamp: { value: new THREE.Vector3() },
      uDensity: { value: 0.04 },
      uLight: { value: 0 },
      uTime: { value: 0 },
    }),
    [],
  );
  useFrame(({ clock }) => {
    if (!material.current) return;
    const s = useAquarium.getState(),
      { width: w, height: h, depth: d } = s.doc.tank,
      e = effectiveEnvironment(s.doc.decorations, s.doc.environment),
      lamp = s.doc.decorations.find(
        (o) => o.kind === "light" && o.enabled !== false,
      );
    uniforms.uMin.value.set(-w / 2, 0.14, -d / 2);
    uniforms.uMax.value.set(w / 2, h - 0.14, d / 2);
    uniforms.uLamp.value.set(...(lamp?.position ?? [0, h, 0]));
    uniforms.uDensity.value = 0.025 + (1 - e.clarity) * 0.12;
    uniforms.uLight.value = lightLevel(e);
    uniforms.uTime.value = clock.elapsedTime;
  });
  if (quality !== "high") return null;
  return (
    <mesh position={[0, tank.height / 2, 0]} renderOrder={3} raycast={() => {}}>
      <boxGeometry
        args={[tank.width - 0.05, tank.height - 0.28, tank.depth - 0.05]}
      />
      <shaderMaterial
        ref={material}
        uniforms={uniforms}
        vertexShader={volumeVertex}
        fragmentShader={volumeFragment}
        side={THREE.BackSide}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}
