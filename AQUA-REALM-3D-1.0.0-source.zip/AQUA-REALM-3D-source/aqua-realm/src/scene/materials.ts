import * as THREE from "three";
import { seeded } from "../simulation/model";
export function surfaceTexture(
  kind: "sand" | "stone" | "wood" | "blackSand" | "whiteSand",
) {
  const size = 256,
    data = new Uint8Array(size * size * 4),
    r = seeded(kind === "sand" ? 4 : kind === "stone" ? 6 : 8);
  for (let y = 0; y < size; y++)
    for (let x = 0; x < size; x++) {
      const noise = r(),
        grain =
          kind === "wood"
            ? Math.sin(x * 0.24 + Math.sin(y * 0.05) * 3) * 0.1
            : Math.sin(x * 0.12) * Math.sin(y * 0.17) * 0.08;
      const base =
        kind === "blackSand"
          ? [0.07, 0.09, 0.08]
          : kind === "whiteSand"
            ? [0.7, 0.66, 0.54]
            : kind === "sand"
              ? [0.45, 0.4, 0.3]
              : kind === "stone"
                ? [0.23, 0.28, 0.25]
                : [0.2, 0.12, 0.065];
      for (let k = 0; k < 3; k++)
        data[(y * size + x) * 4 + k] = Math.max(
          0,
          Math.min(255, (base[k] + (noise - 0.5) * 0.18 + grain) * 255),
        );
      data[(y * size + x) * 4 + 3] = 255;
    }
  const t = new THREE.DataTexture(data, size, size);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(
    kind.endsWith("Sand") || kind === "sand" ? 8 : 2,
    kind.endsWith("Sand") || kind === "sand" ? 5 : 2,
  );
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}
export function rockGeometry(seed: number) {
  const g = new THREE.IcosahedronGeometry(1, 3),
    p = g.attributes.position,
    r = seeded(seed + 14);
  for (let i = 0; i < p.count; i++) {
    const v = new THREE.Vector3().fromBufferAttribute(p, i);
    const noise =
      1 +
      0.11 * Math.sin(v.x * 13 + seed) +
      0.08 * Math.cos(v.z * 11) +
      Math.sin(v.x * 19 + v.y * 17 + v.z * 7) * 0.025;
    v.multiplyScalar(noise);
    v.y *= 0.75;
    p.setXYZ(i, v.x, v.y, v.z);
  }
  g.computeVertexNormals();
  return g;
}
export function plantGeometry(seed: number) {
  const r = seeded(seed + 30),
    positions: number[] = [],
    normals: number[] = [],
    uv: number[] = [],
    indices: number[] = [];
  for (let leaf = 0; leaf < 11; leaf++) {
    const angle = r() * Math.PI * 2,
      height = 0.3 + r() * 0.9,
      lean = 0.1 + r() * 0.4,
      base = positions.length / 3;
    for (let s = 0; s <= 12; s++) {
      const t = s / 12,
        width = Math.sin(t * Math.PI) * (0.025 + r() * 0.018);
      for (const side of [-1, 1]) {
        positions.push(
          Math.cos(angle) * lean * t * t + Math.sin(angle) * width * side,
          height * t,
          Math.sin(angle) * lean * t * t - Math.cos(angle) * width * side,
        );
        normals.push(0, 0.4, 1);
        uv.push(side === -1 ? 0 : 1, t);
      }
    }
    for (let s = 0; s < 12; s++) {
      const a = base + s * 2;
      indices.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(normals, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(indices);
  g.computeVertexNormals();
  return g;
}
