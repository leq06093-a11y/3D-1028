import * as THREE from "three";
import { seeded } from "../simulation/model";
/** Five separate botanical growth patterns, finely segmented curved leaves with vein UVs. */
export function foliageGeometry(type: number) {
  const r = seeded(type * 73 + 19),
    pos: number[] = [],
    uv: number[] = [],
    idx: number[] = [];
  const leaf = (
    base: THREE.Vector3,
    tip: THREE.Vector3,
    width: number,
    curl: number,
  ) => {
    const first = pos.length / 3,
      delta = tip.clone().sub(base),
      side = new THREE.Vector3(delta.z, 0, -delta.x).normalize();
    if (side.lengthSq() < 0.1) side.set(1, 0, 0);
    for (let i = 0; i <= 12; i++) {
      const t = i / 12,
        center = base.clone().lerp(tip, t);
      center.y += Math.sin(t * Math.PI) * curl;
      for (let j = 0; j < 5; j++) {
        const v = (j / 4) * 2 - 1,
          w = Math.sin(t * Math.PI) ** 0.8 * width;
        const p = center.clone().addScaledVector(side, v * w);
        p.y += Math.abs(v) * w * 0.12;
        pos.push(p.x, p.y, p.z);
        uv.push(j / 4, t);
      }
    }
    for (let i = 0; i < 12; i++)
      for (let j = 0; j < 4; j++) {
        const a = first + i * 5 + j;
        idx.push(a, a + 1, a + 5, a + 1, a + 6, a + 5);
      }
  };
  if (type % 5 === 0) {
    for (let i = 0; i < 16; i++) {
      const a = r() * Math.PI * 2,
        h = 0.45 + r() * 0.85;
      leaf(
        new THREE.Vector3((r() - 0.5) * 0.08, 0, (r() - 0.5) * 0.08),
        new THREE.Vector3(Math.cos(a) * 0.28, h, Math.sin(a) * 0.28),
        0.018 + r() * 0.02,
        0.09,
      );
    }
  } else if (type % 5 === 1) {
    for (let i = 0; i < 12; i++) {
      const a = r() * Math.PI * 2,
        d = 0.15 + r() * 0.3;
      leaf(
        new THREE.Vector3(0, 0.04, 0),
        new THREE.Vector3(Math.cos(a) * d, 0.2 + r() * 0.2, Math.sin(a) * d),
        0.09,
        0.09,
      );
    }
  } else if (type % 5 === 2) {
    for (let stem = 0; stem < 5; stem++) {
      const x = (r() - 0.5) * 0.3,
        z = (r() - 0.5) * 0.3,
        h = 0.8 + r() * 0.3;
      for (let n = 0; n < 8; n++) {
        const y = (n / 8) * h;
        for (let side = 0; side < 3; side++) {
          const a = (side * Math.PI * 2) / 3 + n * 0.7;
          leaf(
            new THREE.Vector3(x, y, z),
            new THREE.Vector3(
              x + Math.cos(a) * 0.18,
              y + 0.17,
              z + Math.sin(a) * 0.18,
            ),
            0.027,
            0.045,
          );
        }
      }
    }
  } else if (type % 5 === 3) {
    for (let i = 0; i < 100; i++) {
      const a = r() * 6.28,
        d = Math.sqrt(r()) * 0.4,
        b = new THREE.Vector3(Math.cos(a) * d, 0.02, Math.sin(a) * d);
      leaf(
        b,
        b
          .clone()
          .add(
            new THREE.Vector3(
              (r() - 0.5) * 0.15,
              0.08 + r() * 0.13,
              (r() - 0.5) * 0.15,
            ),
          ),
        0.013,
        0.025,
      );
    }
  } else {
    for (let i = 0; i < 65; i++) {
      const b = new THREE.Vector3((r() - 0.5) * 0.8, 0, (r() - 0.5) * 0.8);
      leaf(
        b,
        b
          .clone()
          .add(
            new THREE.Vector3(
              (r() - 0.5) * 0.1,
              0.045 + r() * 0.055,
              (r() - 0.5) * 0.1,
            ),
          ),
        0.018,
        0.018,
      );
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}
export function foliageMaterial(type: number) {
  const m = new THREE.MeshStandardMaterial({
    color: new THREE.Color(
      ["#477b2a", "#3d6636", "#4c9142", "#2d5936", "#6f9d42"][type % 5],
    ),
    roughness: 0.58,
    side: THREE.DoubleSide,
  });
  m.onBeforeCompile = (shader) => {
    shader.vertexShader =
      "varying vec2 vLeafUv;\n" +
      shader.vertexShader.replace(
        "#include <begin_vertex>",
        "#include <begin_vertex>\nvLeafUv=uv;",
      );
    shader.fragmentShader =
      "varying vec2 vLeafUv;\n" +
      shader.fragmentShader.replace(
        "#include <color_fragment>",
        `#include <color_fragment>\n float vein=pow(1.-abs(vLeafUv.x-.5)*2.,18.);float rib=pow(max(0.,cos(vLeafUv.y*130.+abs(vLeafUv.x-.5)*24.)),16.);diffuseColor.rgb*=.72+.28*sin(vLeafUv.y*3.14159);diffuseColor.rgb+=vec3(.08,.14,.02)*(vein+rib*.22);`,
      );
  };
  m.customProgramCacheKey = () => "leaf-veins-v1";
  return m;
}
