import * as THREE from "three";
import { MeshBVH } from "three-mesh-bvh";
import type { Decoration, Vec3 } from "./model";
interface Shape {
  geometry: THREE.BufferGeometry;
  bvh: MeshBVH;
  box: THREE.Box3;
}
interface Entry {
  base: THREE.Matrix4;
  shapes: Shape[];
  kind: string;
  variant: number;
}
const entries = new Map<string, Entry>();
const identity = new THREE.Matrix4();
function pose(item: Decoration) {
  return new THREE.Matrix4().compose(
    new THREE.Vector3(...item.position),
    new THREE.Quaternion().setFromAxisAngle(
      new THREE.Vector3(0, 1, 0),
      item.rotation,
    ),
    new THREE.Vector3().setScalar(item.scale),
  );
}
function delta(entry: Entry, item: Decoration) {
  return pose(item).multiply(entry.base.clone().invert());
}
function inside(shape: Shape, p: THREE.Vector3) {
  if (!shape.box.containsPoint(p)) return false;
  let votes = 0;
  for (const v of [
    [1, 0.137, 0.213],
    [-0.213, 0.117, 1],
    [0.173, 1, 0.119],
  ]) {
    const hits = shape.bvh.raycast(
      new THREE.Ray(p, new THREE.Vector3(...v).normalize()),
      THREE.DoubleSide,
    );
    const distances = hits
      .map((h) => h.distance)
      .filter((d) => d > 1e-6)
      .sort((a, b) => a - b);
    let distinct = 0,
      last = -1;
    for (const d of distances)
      if (Math.abs(d - last) > 1e-5) {
        distinct++;
        last = d;
      }
    if (distinct % 2) votes++;
  }
  return votes >= 2;
}
export function registerMeshCollider(item: Decoration, root: THREE.Object3D) {
  root.updateWorldMatrix(true, true);
  const shapes: Shape[] = [];
  root.traverse((node) => {
    if (!(node instanceof THREE.Mesh) || !node.geometry.attributes.position)
      return;
    const geometry = node.geometry.clone().applyMatrix4(node.matrixWorld);
    geometry.computeBoundingBox();
    const box = geometry.boundingBox!.clone(),
      size = box.getSize(new THREE.Vector3());
    if (Math.min(size.x, size.y, size.z) < 1e-5) {
      geometry.dispose();
      return;
    }
    const bvh = new MeshBVH(geometry, { maxLeafTris: 12 });
    (geometry as THREE.BufferGeometry & { boundsTree: MeshBVH }).boundsTree =
      bvh;
    shapes.push({ geometry, bvh, box });
  });
  const entry: Entry = {
    base: pose(item),
    shapes,
    kind: item.kind,
    variant: item.variant,
  };
  const previous = entries.get(item.id);
  previous?.shapes.forEach((s) => s.geometry.dispose());
  entries.set(item.id, entry);
  return () => {
    if (entries.get(item.id) === entry) {
      entries.delete(item.id);
      entry.shapes.forEach((s) => s.geometry.dispose());
    }
  };
}
/** Null means a collider has not been rendered/registered yet: callers use a conservative proxy. */
export function meshIntersects(a: Decoration, b: Decoration): boolean | null {
  const ea = entries.get(a.id),
    eb = entries.get(b.id);
  if (
    !ea ||
    !eb ||
    ea.kind !== a.kind ||
    eb.kind !== b.kind ||
    ea.variant !== a.variant ||
    eb.variant !== b.variant
  )
    return null;
  const da = delta(ea, a),
    db = delta(eb, b),
    toA = da.clone().invert().multiply(db),
    toB = toA.clone().invert();
  for (const sa of ea.shapes)
    for (const sb of eb.shapes) {
      if (
        !sa.box
          .clone()
          .applyMatrix4(da)
          .intersectsBox(sb.box.clone().applyMatrix4(db))
      )
        continue;
      if (sa.bvh.intersectsGeometry(sb.geometry, toA)) return true;
      const pB = new THREE.Vector3()
        .fromBufferAttribute(sb.geometry.attributes.position, 0)
        .applyMatrix4(toA);
      if (inside(sa, pB)) return true;
      const pA = new THREE.Vector3()
        .fromBufferAttribute(sa.geometry.attributes.position, 0)
        .applyMatrix4(toB);
      if (inside(sb, pA)) return true;
    }
  return false;
}
export interface SurfaceSample {
  point: Vec3;
  normal: Vec3;
  distance: number;
  inside: boolean;
}
export function meshSurface(
  item: Decoration,
  position: Vec3,
  range: number,
): SurfaceSample | null | undefined {
  const entry = entries.get(item.id);
  if (!entry || entry.kind !== item.kind || entry.variant !== item.variant)
    return undefined;
  const transform = delta(entry, item),
    inverse = transform.clone().invert(),
    p = new THREE.Vector3(...position),
    local = p.clone().applyMatrix4(inverse),
    scale = transform.getMaxScaleOnAxis();
  let best: SurfaceSample | null = null;
  for (const shape of entry.shapes) {
    if (shape.box.distanceToPoint(local) > range / scale) continue;
    const hit = shape.bvh.closestPointToPoint(
      local,
      { point: new THREE.Vector3(), distance: Infinity, faceIndex: 0 },
      0,
      shape.box.containsPoint(local) ? Infinity : range / scale,
    );
    if (!hit) continue;
    const point = hit.point.clone().applyMatrix4(transform),
      distance = point.distanceTo(p);
    const isInside = inside(shape, local);
    if (distance > range && !isInside) continue;
    const normal = (
      isInside ? point.clone().sub(p) : p.clone().sub(point)
    ).normalize();
    if (normal.lengthSq() < 1e-8) normal.set(0, 1, 0);
    if (!best || distance < best.distance || (isInside && !best.inside))
      best = {
        point: point.toArray(),
        normal: normal.toArray(),
        distance,
        inside: isInside,
      };
  }
  return best;
}
export function clearMeshColliders() {
  for (const entry of entries.values())
    entry.shapes.forEach((s) => s.geometry.dispose());
  entries.clear();
}
