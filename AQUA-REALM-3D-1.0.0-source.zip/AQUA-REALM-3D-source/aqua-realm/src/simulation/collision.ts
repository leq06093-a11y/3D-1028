import type { Decoration, Vec3 } from "./model";
export interface Box {
  center: Vec3;
  half: Vec3;
  angle: number;
}
/** Consistent oriented bounding proxies used for both placement and fish steering. */
export function collider(o: Decoration): Box {
  const dims =
    o.kind === "wood"
      ? [0.87, 0.5, 0.27]
      : o.kind === "rock"
        ? [0.85, 0.56, 0.75]
        : o.kind === "filter"
          ? [0.18, 0.55, 0.18]
          : o.kind === "heater"
            ? [0.07, 0.65, 0.07]
            : o.kind === "light"
              ? [1.9, 0.04, 0.12]
              : [0.42, 0.65, 0.42];
  return {
    center: [o.position[0], o.position[1] + dims[1] * o.scale, o.position[2]],
    half: dims.map((d) => d * o.scale) as Vec3,
    angle: o.rotation,
  };
}
export function boxesOverlap(a: Box, b: Box) {
  if (Math.abs(a.center[1] - b.center[1]) >= a.half[1] + b.half[1])
    return false;
  const axes = [
    [Math.cos(a.angle), -Math.sin(a.angle)],
    [Math.sin(a.angle), Math.cos(a.angle)],
    [Math.cos(b.angle), -Math.sin(b.angle)],
    [Math.sin(b.angle), Math.cos(b.angle)],
  ];
  const aa = axes.slice(0, 2),
    bb = axes.slice(2);
  for (const axis of axes) {
    const distance = Math.abs(
      (a.center[0] - b.center[0]) * axis[0] +
        (a.center[2] - b.center[2]) * axis[1],
    );
    const ra =
      a.half[0] * Math.abs(axis[0] * aa[0][0] + axis[1] * aa[0][1]) +
      a.half[2] * Math.abs(axis[0] * aa[1][0] + axis[1] * aa[1][1]);
    const rb =
      b.half[0] * Math.abs(axis[0] * bb[0][0] + axis[1] * bb[0][1]) +
      b.half[2] * Math.abs(axis[0] * bb[1][0] + axis[1] * bb[1][1]);
    if (distance >= ra + rb) return false;
  }
  return true;
}
export function nearestPoint(p: Vec3, box: Box): Vec3 {
  const dx = p[0] - box.center[0],
    dz = p[2] - box.center[2],
    c = Math.cos(box.angle),
    s = Math.sin(box.angle),
    x = Math.max(-box.half[0], Math.min(box.half[0], dx * c - dz * s)),
    z = Math.max(-box.half[2], Math.min(box.half[2], dx * s + dz * c));
  return [
    box.center[0] + x * c + z * s,
    Math.max(
      box.center[1] - box.half[1],
      Math.min(box.center[1] + box.half[1], p[1]),
    ),
    box.center[2] - x * s + z * c,
  ];
}
export const solid = (o: Decoration) =>
  ["rock", "wood", "filter", "heater", "light"].includes(o.kind);

/** Residual contact safeguard, including a fish enclosed by scenery placed while paused. */
export function resolveSphere(
  p: Vec3,
  radius: number,
  box: Box,
  bounds?: { min: Vec3; max: Vec3 },
): Vec3 | null {
  const q = nearestPoint(p, box),
    delta = p.map((n, k) => n - q[k]) as Vec3,
    d = Math.hypot(...delta);
  if (d >= radius) return null;
  const valid = (v: Vec3) =>
    !bounds || v.every((n, k) => n >= bounds.min[k] && n <= bounds.max[k]);
  if (d > 1e-7) {
    const candidate = p.map(
      (n, k) => n + (delta[k] / d) * (radius - d + 0.0001),
    ) as Vec3;
    if (valid(candidate)) return candidate;
  }
  const c = Math.cos(box.angle),
    s = Math.sin(box.angle),
    dx = p[0] - box.center[0],
    dz = p[2] - box.center[2],
    local: Vec3 = [dx * c - dz * s, p[1] - box.center[1], dx * s + dz * c];
  const candidates: Vec3[] = [];
  for (let axis = 0; axis < 3; axis++)
    for (const sign of [-1, 1]) {
      const v = [...local] as Vec3;
      v[axis] = sign * (box.half[axis] + radius + 0.0001);
      const world: Vec3 = [
        box.center[0] + v[0] * c + v[2] * s,
        box.center[1] + v[1],
        box.center[2] - v[0] * s + v[2] * c,
      ];
      if (valid(world)) candidates.push(world);
    }
  candidates.sort(
    (a, b) =>
      Math.hypot(...a.map((n, k) => n - p[k])) -
      Math.hypot(...b.map((n, k) => n - p[k])),
  );
  return candidates[0] ?? null;
}
