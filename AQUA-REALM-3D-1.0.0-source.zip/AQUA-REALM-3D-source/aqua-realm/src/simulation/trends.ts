import type { Ecology } from "./model";
export interface TrendSample {
  time: number;
  oxygen: number;
  ammonia: number;
  nitrate: number;
  temperature: number;
}
export function recordTrend(
  samples: TrendSample[],
  eco: Ecology,
  temperature: number,
): TrendSample[] {
  const last = samples.at(-1);
  if (last && eco.elapsed - last.time < 5) return samples;
  return [
    ...samples.slice(-359),
    {
      time: eco.elapsed,
      oxygen: eco.oxygen,
      ammonia: eco.ammonia,
      nitrate: eco.nitrate,
      temperature,
    },
  ];
}
