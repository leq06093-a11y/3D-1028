import type { Decoration, Environment, Tank } from "./model";
export interface Equipment {
  filter: number;
  brightness: number;
  bubbles: number;
  heater: number;
  flow: number;
}
/** Device sliders are requested outputs; effective output also requires enabled, powered devices. */
export function equipment(items: Decoration[], env: Environment): Equipment {
  let filters = 0,
    lights = 0,
    heaters = 0;
  for (const d of items) {
    if (d.enabled === false) continue;
    const power = d.power ?? 1;
    if (d.kind === "filter") filters += power;
    if (d.kind === "light") lights += power;
    if (d.kind === "heater") heaters += power;
  }
  return {
    filter: Math.min(1, filters * env.filter),
    brightness: Math.min(1.5, lights * env.brightness),
    bubbles: Math.min(1, filters * env.bubbles),
    heater: Math.min(1, heaters),
    flow: Math.min(1, filters * env.flow),
  };
}
export function effectiveEnvironment(
  items: Decoration[],
  env: Environment,
): Environment {
  const e = equipment(items, env);
  return {
    ...env,
    filter: e.filter,
    brightness: e.brightness,
    bubbles: e.bubbles,
    flow: e.flow,
  };
}
export function resizePositions<
  T extends { position: [number, number, number] },
>(objects: T[], oldTank: Tank, newTank: Tank): T[] {
  return objects.map((o) => ({
    ...o,
    position: [
      (o.position[0] * newTank.width) / oldTank.width,
      (o.position[1] * newTank.height) / oldTank.height,
      (o.position[2] * newTank.depth) / oldTank.depth,
    ],
  }));
}
