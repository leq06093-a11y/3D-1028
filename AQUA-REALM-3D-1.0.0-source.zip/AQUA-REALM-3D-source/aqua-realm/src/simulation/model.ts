import { meshIntersects, meshSurface } from "./meshCollisions";
import { SPECIES, speciesOf, type SpeciesId } from "../assets/catalog";
import {
  boxesOverlap,
  collider,
  nearestPoint,
  solid,
  resolveSphere,
} from "./collision";
import type { TrendSample } from "./trends";
export type Vec3 = [number, number, number];
export type ItemKind =
  | "rock"
  | "wood"
  | "plant"
  | "filter"
  | "light"
  | "heater";
export interface Decoration {
  id: string;
  kind: ItemKind;
  name: string;
  position: Vec3;
  rotation: number;
  scale: number;
  variant: number;
  enabled?: boolean;
  power?: number;
}
export interface FishState {
  id: string;
  species: SpeciesId;
  name: string;
  position: Vec3;
  velocity: Vec3;
  hunger: number;
  health: number;
  age: number;
  length: number;
  state: "巡游" | "觅食" | "休息" | "受扰" | "群游";
  phase: number;
  swimTime?: number;
  alert?: number;
}
export interface Food {
  id: number;
  position: Vec3;
  age: number;
  mode?: "floating" | "sinking";
}
export interface Environment {
  temperature: number;
  brightness: number;
  kelvin: number;
  flow: number;
  bubbles: number;
  clarity: number;
  sway: number;
  filter: number;
  hour: number;
  dayCycle: boolean;
  sunrise: number;
  sunset: number;
  sound: boolean;
}
export interface Ecology {
  oxygen: number;
  ammonia: number;
  nitrite: number;
  nitrate: number;
  ph: number;
  waste: number;
  elapsed: number;
  waterTemperature: number;
}
export interface Tank {
  width: number;
  height: number;
  depth: number;
}
export interface Document {
  version: 1;
  view?: {
    camera: "overview" | "free" | "underwater" | "follow";
    quality: "low" | "medium" | "high";
    speed: number;
    playing: boolean;
    sensitivity: number;
    cameraSpeed: number;
    editing: boolean;
    selected: string | null;
  };
  tank: Tank;
  environment: Environment;
  ecology: Ecology;
  fish: FishState[];
  decorations: Decoration[];
  substrate: "natural" | "black" | "white";
  background: "forest" | "slate" | "black";
  trend: TrendSample[];
  food: Food[];
}
export const defaultEnvironment: Environment = {
  temperature: 26,
  brightness: 0.85,
  kelvin: 6500,
  flow: 0.45,
  bubbles: 0.55,
  clarity: 0.92,
  sway: 0.6,
  filter: 0.8,
  hour: 14,
  dayCycle: true,
  sunrise: 7,
  sunset: 20,
  sound: false,
};
export const defaultEcology: Ecology = {
  oxygen: 7.8,
  ammonia: 0.03,
  nitrite: 0.01,
  nitrate: 8,
  ph: 7.1,
  waste: 0,
  elapsed: 0,
  waterTemperature: 26,
};
export const itemNames: Record<ItemKind, string> = {
  rock: "青龙石",
  wood: "自然沉木",
  plant: "水草丛",
  filter: "循环过滤器",
  light: "全光谱照明",
  heater: "恒温加热棒",
};
export const clamp = (n: number, min: number, max: number) =>
  Math.max(min, Math.min(max, n));
export function seeded(n: number) {
  let a = n | 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function makeFish(
  index: number,
  species: SpeciesId = "barramundi",
): FishState {
  const r = seeded(index * 71 + 12),
    spec = speciesOf(species);
  return {
    id: crypto.randomUUID(),
    species,
    name: `${spec.name} ${String(index + 1).padStart(2, "0")}`,
    position: [(r() - 0.5) * 3, 0.6 + r() * 1.6, (r() - 0.5) * 1.3],
    velocity: [spec.speed * 0.65, 0, 0.03],
    hunger: 0.25 + r() * 0.3,
    health: 0.97,
    age: 70 + index * 3,
    length: spec.length[0],
    state: "巡游",
    phase: r() * Math.PI * 2,
    swimTime: 0,
    alert: 0,
  };
}
export function preset(name = "nature"): Decoration[] {
  const items: Decoration[] = [],
    r = seeded(name === "nature" ? 81 : name === "wood" ? 92 : 42);
  let i = 0;
  const add = (kind: ItemKind, position: Vec3, scale: number, variant = 0) => {
    const o: Decoration = {
      id: `${name}-${i++}`,
      kind,
      name: itemNames[kind],
      position,
      scale,
      rotation: ["filter", "light", "heater"].includes(kind) ? 0 : r() * 6,
      variant,
      enabled: true,
      power: 1,
    };
    const placed = constrain(o, { width: 6, height: 3.4, depth: 2.6 });
    if (!["rock", "wood"].includes(kind) || canPlace(placed, items))
      items.push(placed);
  };
  if (name !== "minimal") {
    add("wood", [-1, 0.14, -0.5], 0.9);
    if (name === "wood") add("wood", [1, 0.14, -0.55], 0.8);
    for (let j = 0; j < 8; j++)
      add(
        "rock",
        [(r() - 0.5) * 4.7, 0.13, (r() - 0.5) * 1.6],
        0.3 + r() * 0.35,
        j,
      );
    for (let j = 0; j < 25; j++)
      add(
        "plant",
        [(r() - 0.5) * 4.9, 0.12, (r() - 0.5) * 1.85],
        0.3 + r() * 0.55,
        j % 5,
      );
  } else {
    add("rock", [0, 0.13, 0], 0.6);
    add("plant", [-1, 0.12, -0.7], 0.8, 1);
    add("plant", [1.4, 0.12, -0.7], 0.8, 0);
  }
  add("filter", [2.65, 0.2, -1], 0.7);
  add("light", [0, 3.78, -0.15], 1);
  add("heater", [-2.75, 0.3, -1], 0.8);
  return items;
}
export function constrain(item: Decoration, tank: Tank): Decoration {
  const box = collider(item),
    c = Math.cos(item.rotation),
    s = Math.sin(item.rotation),
    rx = Math.abs(c) * box.half[0] + Math.abs(s) * box.half[2],
    rz = Math.abs(s) * box.half[0] + Math.abs(c) * box.half[2];
  return {
    ...item,
    position: [
      clamp(item.position[0], -tank.width / 2 + rx, tank.width / 2 - rx),
      clamp(
        item.position[1],
        0.12,
        item.kind === "light"
          ? tank.height + 0.5
          : Math.max(0.12, tank.height - box.half[1] * 2 - 0.15),
      ),
      clamp(item.position[2], -tank.depth / 2 + rz, tank.depth / 2 - rz),
    ],
  };
}
export function canPlace(item: Decoration, items: Decoration[]) {
  if (!solid(item)) return true;
  return !items.some(
    (o) =>
      o.id !== item.id &&
      solid(o) &&
      (meshIntersects(item, o) ?? boxesOverlap(collider(item), collider(o))),
  );
}
export function lightLevel(e: Environment) {
  if (!e.dayCycle) return e.brightness;
  return (
    e.brightness *
    (0.06 +
      0.94 *
        Math.min(
          clamp((e.hour - e.sunrise) / 1.2, 0, 1),
          clamp((e.sunset - e.hour) / 1.2, 0, 1),
        ))
  );
}
export function stepEcology(
  eco: Ecology,
  env: Environment,
  fishCount: number,
  foodCount: number,
  dt: number,
  heater = 1,
): Ecology {
  const waste = clamp(
      eco.waste +
        (fishCount * 0.0003 + foodCount * 0.002 - env.filter * 0.003) * dt,
      0,
      10,
    ),
    ammonia = clamp(
      eco.ammonia +
        (waste * 0.001 +
          fishCount * 0.00002 -
          env.filter * eco.ammonia * 0.004) *
          dt,
      0,
      5,
    ),
    nitrite = clamp(
      eco.nitrite + (ammonia * 0.003 - env.filter * eco.nitrite * 0.008) * dt,
      0,
      5,
    ),
    nitrate = clamp(eco.nitrate + (nitrite * 0.002 - 0.0001) * dt, 0, 100),
    target =
      8.2 -
      ((eco.waterTemperature ?? 26) - 24) * 0.12 +
      env.bubbles * 0.7 -
      fishCount * 0.08 -
      waste * 0.2,
    waterTemperature =
      (eco.waterTemperature ?? 26) +
      (23 + (env.temperature - 23) * heater - (eco.waterTemperature ?? 26)) *
        Math.min(1, dt * 0.008);
  return {
    ...eco,
    waste,
    ammonia,
    nitrite,
    nitrate,
    oxygen: clamp(eco.oxygen + (target - eco.oxygen) * dt * 0.01, 0, 12),
    ph: clamp(7.1 - waste * 0.04, 5, 9),
    elapsed: eco.elapsed + dt,
    waterTemperature,
  };
}
export function stepFish(
  fish: FishState[],
  food: Food[],
  items: Decoration[],
  tank: Tank,
  env: Environment,
  eco: Ecology,
  dt: number,
  time: number,
): void {
  const eaten = new Set<number>(),
    solidItems = items.filter(solid),
    obstacles = solidItems.map(collider);
  const night = lightLevel(env) < 0.15;
  // Immutable steering snapshot avoids update-order bias in flock alignment.
  const snapshot = fish.map((f) => ({
    id: f.id,
    species: f.species,
    position: [...f.position] as Vec3,
    velocity: [...f.velocity] as Vec3,
  }));
  const grid = new Map<string, typeof snapshot>();
  for (const f of snapshot) {
    const key = f.position.map((p) => Math.floor(p / 1.5)).join(",");
    const bin = grid.get(key);
    if (bin) bin.push(f);
    else grid.set(key, [f]);
  }
  for (const f of fish) {
    const spec = speciesOf(f.species),
      acc: Vec3 = [0, 0, 0],
      radius = spec.radius;
    let target: Food | undefined,
      nearest = Infinity;
    if (f.hunger > 0.12)
      for (const p of food) {
        if (eaten.has(p.id)) continue;
        const d = Math.hypot(
          p.position[0] - f.position[0],
          p.position[1] - f.position[1],
          p.position[2] - f.position[2],
        );
        if (d < nearest) {
          nearest = d;
          target = p;
        }
      }
    f.alert = Math.max(0, (f.alert ?? 0) - dt);
    f.state = f.alert > 0 ? "受扰" : target ? "觅食" : night ? "休息" : "巡游";
    const awake = night ? 0.35 : 1,
      speed =
        spec.speed *
        awake *
        (1 + env.flow * 0.3) *
        (f.health * 0.5 + 0.5) *
        (f.alert > 0 ? 1.4 : 1);
    for (let k = 0; k < 3; k++) {
      acc[k] = Math.sin(time * 0.23 + f.phase + k * 2) * spec.speed * 0.18;
      if (target && f.alert === 0)
        acc[k] += (target.position[k] - f.position[k]) * 0.7;
    }
    const centerY = tank.height * (spec.depth[0] + spec.depth[1]) * 0.5;
    if (!target) acc[1] += (centerY - f.position[1]) * 0.12;
    if (target && nearest < radius + 0.06) {
      eaten.add(target.id);
      f.hunger = clamp(f.hunger - 0.24, 0, 1);
    }
    const cell = f.position.map((v) => Math.floor(v / 1.5)),
      cohesion: Vec3 = [0, 0, 0],
      alignment: Vec3 = [0, 0, 0];
    let neighbours = 0;
    for (let x = -1; x <= 1; x++)
      for (let y = -1; y <= 1; y++)
        for (let z = -1; z <= 1; z++) {
          const bin = grid.get(
            [cell[0] + x, cell[1] + y, cell[2] + z].join(","),
          );
          if (!bin) continue;
          for (const other of bin) {
            if (other.id === f.id) continue;
            const d = Math.hypot(
              ...(f.position.map((v, k) => v - other.position[k]) as Vec3),
            );
            if (d < radius * 2 + 0.16 && d > 0.001)
              for (let k = 0; k < 3; k++)
                acc[k] += ((f.position[k] - other.position[k]) / d) * 0.5;
            if (other.species === f.species && d < 1.7) {
              neighbours++;
              for (let k = 0; k < 3; k++) {
                cohesion[k] += other.position[k];
                alignment[k] += other.velocity[k];
              }
              if (spec.territory && d < 0.8)
                for (let k = 0; k < 3; k++)
                  acc[k] +=
                    (f.position[k] - other.position[k]) * spec.territory * 0.6;
            }
          }
        }
    if (neighbours && spec.schooling && !target && f.alert === 0 && !night) {
      f.state = "群游";
      for (let k = 0; k < 3; k++)
        acc[k] +=
          ((cohesion[k] / neighbours - f.position[k]) * 0.08 +
            (alignment[k] / neighbours - f.velocity[k]) * 0.5) *
          spec.schooling;
    }
    for (let oi = 0; oi < obstacles.length; oi++) {
      const box = obstacles[oi],
        sample = meshSurface(solidItems[oi], f.position, radius + 0.35);
      if (sample === null) continue;
      const p = sample?.point ?? nearestPoint(f.position, box),
        dx = sample
          ? sample.normal
          : (f.position.map((v, k) => v - p[k]) as Vec3),
        distance = sample?.distance ?? Math.hypot(...dx);
      if (distance < radius + 0.35) {
        if (!sample && distance < 0.001) {
          dx[0] = f.position[0] >= box.center[0] ? 1 : -1;
          dx[1] = 0.4;
        }
        for (let k = 0; k < 3; k++)
          acc[k] += sample
            ? dx[k] * (radius + 0.35 - distance) * 2
            : (dx[k] / Math.max(distance, 0.2)) *
              (radius + 0.35 - distance) *
              2;
      }
    }
    const min: Vec3 = [
        -tank.width / 2 + radius + 0.08,
        0.2 + radius,
        -tank.depth / 2 + radius + 0.08,
      ],
      max: Vec3 = [
        tank.width / 2 - radius - 0.08,
        tank.height - 0.18 - radius,
        tank.depth / 2 - radius - 0.08,
      ];
    for (let k = 0; k < 3; k++) {
      if (f.position[k] > max[k] - 0.4)
        acc[k] -= (f.position[k] - (max[k] - 0.4)) * 1.4;
      if (f.position[k] < min[k] + 0.4)
        acc[k] += (min[k] + 0.4 - f.position[k]) * 1.4;
      f.velocity[k] += clamp(acc[k], -1.5, 1.5) * dt;
    }
    const norm = Math.hypot(...f.velocity);
    if (norm > speed) for (let k = 0; k < 3; k++) f.velocity[k] *= speed / norm;
    for (let k = 0; k < 3; k++) {
      f.position[k] += f.velocity[k] * dt;
      if (f.position[k] < min[k] || f.position[k] > max[k]) {
        f.position[k] = clamp(f.position[k], min[k], max[k]);
        f.velocity[k] *= -0.2;
      }
    }
    // Ordinary steering avoids contact; resolve only residual penetration.
    for (let oi = 0; oi < obstacles.length; oi++) {
      const surface = meshSurface(solidItems[oi], f.position, radius + 0.1);
      if (surface === null) continue;
      const corrected = surface
        ? surface.inside || surface.distance < radius
          ? (surface.point.map(
              (v, k) => v + surface.normal[k] * (radius + 0.0001),
            ) as Vec3)
          : null
        : resolveSphere(f.position, radius, obstacles[oi], { min, max });
      if (corrected) {
        f.position = corrected;
        f.alert = Math.max(f.alert ?? 0, 0.5);
        for (let k = 0; k < 3; k++) f.velocity[k] *= 0.8;
      }
    }
    for (let k = 0; k < 3; k++)
      f.position[k] = clamp(f.position[k], min[k], max[k]);
    f.hunger = clamp(f.hunger + dt * 0.0006 * (night ? 0.5 : 1), 0, 1);
    const temp = eco.waterTemperature ?? env.temperature,
      stress =
        Math.max(0, spec.temperature[0] - temp, temp - spec.temperature[1]) *
          0.00012 +
        Math.max(0, 5 - eco.oxygen) * 0.00015 +
        eco.ammonia * 0.0002 +
        Math.max(0, f.hunger - 0.85) * 0.0003;
    f.health = clamp(f.health + (stress ? -stress : 0.000015) * dt, 0, 1);
    f.swimTime =
      (f.swimTime ?? 0) + dt * (0.5 + Math.hypot(...f.velocity) / spec.speed);
    f.age += dt / 86400;
    f.length = Math.min(spec.length[1], f.length + (dt / 86400) * 0.025);
  }
  for (let i = food.length - 1; i >= 0; i--) {
    const p = food[i];
    p.age += dt;
    if (p.mode !== "floating" || p.age > 50)
      p.position[1] = Math.max(0.17, p.position[1] - 0.045 * dt);
    p.position[0] = clamp(
      p.position[0] + Math.sin(time + p.id) * env.flow * 0.02 * dt,
      -tank.width / 2 + 0.2,
      tank.width / 2 - 0.2,
    );
    if (eaten.has(p.id) || p.age > 180) food.splice(i, 1);
  }
}
export function initialDocument(): Document {
  return {
    version: 1,
    tank: { width: 6, height: 3.4, depth: 2.6 },
    environment: { ...defaultEnvironment },
    ecology: { ...defaultEcology },
    fish: Array.from({ length: 12 }, (_, i) =>
      makeFish(
        i,
        i < 5 ? "neon" : i < 8 ? "zebra" : i < 11 ? "guppy" : "angel",
      ),
    ),
    decorations: preset(),
    substrate: "natural",
    background: "forest",
    trend: [],
    food: [],
  };
}
export function validateDocument(raw: unknown): Document {
  if (!raw || typeof raw !== "object")
    throw Error("不是有效的 AQUA REALM 场景文件");
  const d = structuredClone(raw) as Document;
  if (
    d.version !== 1 ||
    !d.tank ||
    !d.environment ||
    !d.ecology ||
    !Array.isArray(d.fish) ||
    !Array.isArray(d.decorations) ||
    d.fish.length > 80 ||
    d.decorations.length > 150
  )
    throw Error("不是有效的 AQUA REALM 场景文件");
  const legacy = !Object.hasOwn(d, "substrate");
  if (legacy) {
    for (const kind of ["light", "heater"] as const) {
      if (!d.decorations.some((o) => o?.kind === kind))
        d.decorations.push({
          id: crypto.randomUUID(),
          kind,
          name: itemNames[kind],
          position:
            kind === "light"
              ? [0, d.tank.height + 0.3, 0]
              : [-d.tank.width / 2 + 0.2, 0.3, -d.tank.depth / 2 + 0.2],
          rotation: 0,
          scale: kind === "light" ? 1 : 0.8,
          variant: 0,
          enabled: true,
          power: 1,
        });
    }
  }
  const finite = (n: unknown) => typeof n === "number" && Number.isFinite(n),
    vector = (p: unknown): p is Vec3 =>
      Array.isArray(p) && p.length === 3 && p.every(finite);
  if (
    ![d.tank.width, d.tank.height, d.tank.depth].every(finite) ||
    d.tank.width < 4 ||
    d.tank.width > 10 ||
    d.tank.height < 2.5 ||
    d.tank.height > 6 ||
    d.tank.depth < 2 ||
    d.tank.depth > 5
  )
    throw Error("鱼缸尺寸超出范围");
  const ranges: Partial<Record<keyof Environment, [number, number]>> = {
    temperature: [16, 34],
    brightness: [0, 1.5],
    kelvin: [3000, 10000],
    flow: [0, 1],
    bubbles: [0, 1],
    clarity: [0.1, 1],
    sway: [0, 1],
    filter: [0, 1],
    hour: [0, 24],
    sunrise: [0, 12],
    sunset: [12, 24],
  };
  for (const [key, value] of Object.entries(defaultEnvironment)) {
    const v = d.environment[key as keyof Environment];
    if (typeof v !== typeof value || (typeof v === "number" && !finite(v)))
      throw Error("环境参数无效");
  }
  for (const [k, [min, max]] of Object.entries(ranges)) {
    const n = d.environment[k as keyof Environment] as number;
    if (n < min || n > max) throw Error("环境参数超出范围");
  }
  d.ecology.waterTemperature ??= d.environment.temperature;
  for (const key of Object.keys(defaultEcology)) {
    if (!finite(d.ecology[key as keyof Ecology])) throw Error("生态数据无效");
  }
  if (
    d.ecology.elapsed < 0 ||
    d.ecology.waterTemperature < 0 ||
    d.ecology.waterTemperature > 50
  )
    throw Error("生态数据超出范围");
  const ids = new Set<string>();
  for (const f of d.fish) {
    f.species ??= "barramundi";
    f.swimTime ??= 0;
    if (
      typeof f.id !== "string" ||
      ids.has(f.id) ||
      !Object.hasOwn(SPECIES, f.species) ||
      typeof f.name !== "string" ||
      f.name.length > 80 ||
      !vector(f.position) ||
      !vector(f.velocity) ||
      ![f.hunger, f.health, f.age, f.length, f.phase].every(finite) ||
      !["巡游", "觅食", "休息", "受扰", "群游"].includes(f.state) ||
      f.hunger < 0 ||
      f.hunger > 1 ||
      f.health < 0 ||
      f.health > 1 ||
      f.age < 0 ||
      f.length <= 0 ||
      f.length > 60 ||
      !finite(f.swimTime) ||
      f.swimTime < 0 ||
      f.swimTime > 1e12 ||
      (f.alert !== undefined &&
        (!finite(f.alert) || f.alert < 0 || f.alert > 60))
    )
      throw Error("鱼类数据无效");
    ids.add(f.id);
    const radius = speciesOf(f.species).radius;
    f.position = [
      clamp(
        f.position[0],
        -d.tank.width / 2 + radius + 0.08,
        d.tank.width / 2 - radius - 0.08,
      ),
      clamp(f.position[1], 0.2 + radius, d.tank.height - 0.18 - radius),
      clamp(
        f.position[2],
        -d.tank.depth / 2 + radius + 0.08,
        d.tank.depth / 2 - radius - 0.08,
      ),
    ];
  }
  for (const o of d.decorations) {
    if (
      typeof o.id !== "string" ||
      ids.has(o.id) ||
      typeof o.name !== "string" ||
      !["rock", "wood", "plant", "filter", "light", "heater"].includes(
        o.kind,
      ) ||
      !vector(o.position) ||
      !finite(o.rotation) ||
      !finite(o.scale) ||
      !finite(o.variant) ||
      o.scale < 0.2 ||
      o.scale > 2.5 ||
      (o.enabled !== undefined && typeof o.enabled !== "boolean") ||
      (o.power !== undefined &&
        (!finite(o.power) || o.power < 0 || o.power > 1))
    )
      throw Error("物品数据无效");
    ids.add(o.id);
  }
  d.decorations = d.decorations.map((o) => constrain(o, d.tank));
  d.substrate ??= "natural";
  d.background ??= "forest";
  if (
    !["natural", "black", "white"].includes(d.substrate) ||
    !["forest", "slate", "black"].includes(d.background)
  )
    throw Error("造景材质无效");
  d.trend ??= [];
  if (
    !Array.isArray(d.trend) ||
    d.trend.length > 360 ||
    d.trend.some(
      (v, i) =>
        !v ||
        ![v.time, v.oxygen, v.ammonia, v.nitrate, v.temperature].every(
          finite,
        ) ||
        v.time < 0 ||
        (i > 0 && v.time < d.trend[i - 1].time),
    )
  )
    throw Error("趋势数据无效");
  d.food ??= [];
  if (
    !Array.isArray(d.food) ||
    d.food.length > 110 ||
    d.food.some(
      (p) =>
        !p ||
        !finite(p.id) ||
        !vector(p.position) ||
        !finite(p.age) ||
        p.age < 0 ||
        (p.mode !== undefined && !["floating", "sinking"].includes(p.mode)),
    )
  )
    throw Error("食物数据无效");
  const foodIds = new Set<number>();
  for (const p of d.food) {
    if (foodIds.has(p.id)) throw Error("食物编号重复");
    foodIds.add(p.id);
    p.position = [
      clamp(p.position[0], -d.tank.width / 2 + 0.1, d.tank.width / 2 - 0.1),
      clamp(p.position[1], 0.17, d.tank.height - 0.14),
      clamp(p.position[2], -d.tank.depth / 2 + 0.1, d.tank.depth / 2 - 0.1),
    ];
  }
  if (d.view) {
    const v = d.view;
    if (
      !["overview", "free", "underwater", "follow"].includes(v.camera) ||
      !["low", "medium", "high"].includes(v.quality) ||
      ![0.5, 1, 2, 5].includes(v.speed) ||
      typeof v.playing !== "boolean" ||
      typeof v.editing !== "boolean" ||
      !finite(v.sensitivity) ||
      v.sensitivity < 0.3 ||
      v.sensitivity > 2 ||
      !finite(v.cameraSpeed) ||
      v.cameraSpeed < 0.3 ||
      v.cameraSpeed > 3 ||
      (v.selected !== null && typeof v.selected !== "string")
    )
      throw Error("视图状态无效");
    if (v.selected && !ids.has(v.selected)) v.selected = null;
  }
  return d;
}
