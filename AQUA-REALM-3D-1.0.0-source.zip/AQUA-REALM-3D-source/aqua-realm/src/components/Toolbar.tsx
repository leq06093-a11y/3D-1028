import { version } from "../../package.json";
import {
  Fish,
  PanelsTopLeft,
  Waves,
  Scan,
  Save,
  FolderOpen,
  Settings2,
  Undo2,
  Redo2,
} from "lucide-react";
import { useAquarium, type CameraMode } from "../stores/aquarium";
export function Toolbar({ onSettings }: { onSettings: () => void }) {
  const s = useAquarium();
  return (
    <header className="toolbar">
      <div className="brand">
        <div className="brandmark">
          <Fish size={25} />
        </div>
        <div>
          <strong>
            AQUA REALM<span>3D</span>
          </strong>
          <small>水境 · 让自然，在桌面生长</small>
        </div>
        <span className="build-badge">STUDIO {version}</span>
      </div>
      <nav>
        {(
          [
            ["overview", PanelsTopLeft, "全景观赏"],
            ["free", Scan, "自由造景"],
            ["underwater", Waves, "水下漫游"],
            ["follow", Fish, "鱼类跟随"],
          ] as const
        ).map(([id, Icon, label]) => (
          <button
            key={id}
            className={s.mode === id ? "active" : ""}
            onClick={() =>
              s.set({ mode: id as CameraMode, editing: id === "free" })
            }
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </nav>
      <div className="toolbar-actions">
        <button
          title="撤销"
          aria-label="撤销"
          disabled={!s.history.length}
          onClick={s.undo}
        >
          <Undo2 size={16} />
        </button>
        <button
          title="重做"
          aria-label="重做"
          disabled={!s.future.length}
          onClick={s.redo}
        >
          <Redo2 size={16} />
        </button>
        <span className="v-divider" />
        <button title="保存场景" aria-label="保存场景" onClick={s.save}>
          <Save size={16} />
        </button>
        <button title="加载场景" aria-label="加载场景" onClick={s.load}>
          <FolderOpen size={17} />
        </button>
        <button title="设置" aria-label="设置" onClick={onSettings}>
          <Settings2 size={17} />
        </button>
      </div>
    </header>
  );
}
