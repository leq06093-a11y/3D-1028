import { Power, Move, RotateCw, Scaling } from "lucide-react";
import { useAquarium } from "../stores/aquarium";
import { equipment } from "../simulation/devices";
export function DevicePanel() {
  const s = useAquarium(),
    item = s.doc.decorations.find((o) => o.id === s.selected);
  if (!item || !["light", "filter", "heater"].includes(item.kind)) return null;
  const active = item.enabled !== false;
  return (
    <section className="device-panel">
      <button
        className={"device-power " + (active ? "on" : "")}
        aria-label="设备电源"
        aria-pressed={active}
        onClick={() => {
          s.checkpoint();
          s.updateItem(item.id, { enabled: !active });
        }}
      >
        <Power size={13} />
        {active ? "设备已开启" : "设备已关闭"}
      </button>
      <label className="parameter">
        <span>
          设备功率<b>{Math.round((item.power ?? 1) * 100)}%</b>
        </span>
        <input
          aria-label="设备功率"
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={item.power ?? 1}
          onPointerDown={s.checkpoint}
          onChange={(e) => s.updateItem(item.id, { power: +e.target.value })}
        />
      </label>
      <p className="species-note">
        关闭或移除设备将实际停止其过滤、照明或加热贡献。
      </p>
    </section>
  );
}
export function EquipmentSummary() {
  const doc = useAquarium((s) => s.doc),
    power = equipment(doc.decorations, doc.environment);
  return (
    <div className="equipment-summary">
      <span>
        实际过滤 <b>{Math.round(power.filter * 100)}%</b>
      </span>
      <span>
        实际照明 <b>{Math.round(power.brightness * 100)}%</b>
      </span>
      <span>
        恒温设备 <b>{power.heater > 0 ? "运行" : "关闭"}</b>
      </span>
    </div>
  );
}
export function EditorTools() {
  const s = useAquarium();
  if (!s.editing) return null;
  return (
    <div className="editor-tools" role="toolbar" aria-label="造景工具">
      {(
        [
          ["translate", "移动", Move],
          ["rotate", "旋转手柄", RotateCw],
          ["scale", "缩放手柄", Scaling],
        ] as const
      ).map(([id, label, Icon]) => (
        <button
          key={id}
          aria-label={label}
          aria-pressed={s.editTool === id}
          className={s.editTool === id ? "active" : ""}
          onClick={() => s.set({ editTool: id })}
        >
          <Icon size={13} />
          {label}
        </button>
      ))}
      <button
        aria-pressed={s.verticalEditing}
        onClick={() => s.set({ verticalEditing: !s.verticalEditing })}
      >
        {s.verticalEditing ? "XYZ 自由" : "XZ 平面"}
      </button>
    </div>
  );
}
