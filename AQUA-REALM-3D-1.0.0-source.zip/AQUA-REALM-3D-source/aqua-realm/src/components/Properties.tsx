import { useState } from "react";
import { speciesOf } from "../assets/catalog";
import { Trends } from "./Trends";
import { DevicePanel, EquipmentSummary } from "./DevicePanel";
import {
  Activity,
  SlidersHorizontal,
  Fish,
  Heart,
  Sun,
  Wind,
  Droplets,
  Copy,
  Trash2,
  RotateCw,
  ChevronDown,
} from "lucide-react";
import { useAquarium } from "../stores/aquarium";
import type { Environment } from "../simulation/model";
function Slider({
  label,
  field,
  min,
  max,
  step = 1,
  unit = "",
  factor = 1,
}: {
  label: string;
  field: keyof Environment;
  min: number;
  max: number;
  step?: number;
  unit?: string;
  factor?: number;
}) {
  const s = useAquarium(),
    value = s.doc.environment[field] as number;
  return (
    <label className="parameter">
      <span>
        {label}
        <b>
          {(value * factor).toFixed(step < 1 && factor === 1 ? 1 : 0)}
          <small>{unit}</small>
        </b>
      </span>
      <input
        aria-label={label}
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => s.setEnvironment(field, +e.target.value)}
      />
    </label>
  );
}
export function Properties() {
  const s = useAquarium(),
    [tab, setTab] = useState<"environment" | "ecology">("environment"),
    fish = s.doc.fish.find((f) => f.id === s.selected),
    item = s.doc.decorations.find((o) => o.id === s.selected),
    e = s.doc.environment,
    eco = s.doc.ecology;
  const spec = speciesOf(fish?.species);
  return (
    <aside className="properties side-panel">
      <div className="panel-title">
        <span>水境控制台</span>
        <small>
          <span className="dot" /> LIVE
        </small>
      </div>
      {fish ? (
        <section className="selection">
          <div className="section-caption">
            <Fish size={13} />
            观测中的生命 <span>SELECTED</span>
          </div>
          <input
            aria-label="鱼类名称"
            className="fish-name"
            maxLength={80}
            value={fish.name}
            onChange={(ev) => {
              s.checkpoint();
              s.set({
                doc: {
                  ...s.doc,
                  fish: s.doc.fish.map((f) =>
                    f.id === fish.id ? { ...f, name: ev.target.value } : f,
                  ),
                },
              });
            }}
          />
          <small className="latin-name">
            {spec.latin} · {spec.name}
          </small>
          <div className="fish-vitals">
            <span>
              <small>体长</small>
              <b>
                {fish.length.toFixed(1)} <em>cm</em>
              </b>
            </span>
            <span>
              <small>模拟年龄</small>
              <b>
                {Math.floor(fish.age)} <em>天</em>
              </b>
            </span>
            <span>
              <small>当前状态</small>
              <b className="mint">{fish.state}</b>
            </span>
            <span>
              <small>活动水层</small>
              <b>
                {fish.position[1] > s.doc.tank.height * 0.65
                  ? "上层"
                  : fish.position[1] < s.doc.tank.height * 0.3
                    ? "下层"
                    : "中层"}
              </b>
            </span>
          </div>
          <div className="vital-bar">
            <span>
              <Heart size={11} />
              健康 {Math.round(fish.health * 100)}%
            </span>
            <i style={{ width: `${fish.health * 100}%` }} />
          </div>
          <div className="vital-bar hunger">
            <span>饥饿 {Math.round(fish.hunger * 100)}%</span>
            <i style={{ width: `${fish.hunger * 100}%` }} />
          </div>
          <p className="species-note">
            偏好水温 {spec.temperature[0]}–{spec.temperature[1]}°C ·
            当前生长阶段：
            {fish.age < 180 ? "幼鱼" : fish.age < 365 ? "亚成鱼" : "成鱼"}
            。模型与生态为近似。
          </p>
          <button
            className="text-action"
            onClick={() => s.set({ mode: "follow", editing: false })}
          >
            跟随这条鱼 ↗
          </button>
          <button className="danger-text" onClick={s.remove}>
            <Trash2 size={11} />
            移出鱼缸
          </button>
        </section>
      ) : item ? (
        <section className="selection">
          <div className="section-caption">
            <SlidersHorizontal size={13} />
            对象属性 <span>SELECTED</span>
          </div>
          <h3>{item.name}</h3>
          <div className="position-inputs">
            {(["X", "Y", "Z"] as const).map((axis, i) => (
              <label key={axis}>
                {axis}
                <input
                  aria-label={`位置 ${axis}`}
                  type="number"
                  step="0.1"
                  value={item.position[i].toFixed(2)}
                  onFocus={s.checkpoint}
                  onChange={(ev) => {
                    if (!Number.isFinite(ev.target.valueAsNumber)) return;
                    const p = [...item.position] as [number, number, number];
                    p[i] = ev.target.valueAsNumber;
                    s.updateItem(item.id, { position: p });
                  }}
                />
              </label>
            ))}
          </div>
          <label className="parameter">
            <span>
              缩放<b>{item.scale.toFixed(2)}×</b>
            </span>
            <input
              aria-label="对象缩放"
              type="range"
              min=".2"
              max="2"
              step=".05"
              value={item.scale}
              onPointerDown={s.checkpoint}
              onChange={(ev) =>
                s.updateItem(item.id, { scale: +ev.target.value })
              }
            />
          </label>
          <div className="object-actions">
            <button
              onClick={() => {
                s.checkpoint();
                s.updateItem(item.id, {
                  rotation: item.rotation + Math.PI / 4,
                });
              }}
            >
              <RotateCw size={13} />
              旋转
            </button>
            <button onClick={s.duplicate}>
              <Copy size={13} />
              复制
            </button>
            <button onClick={s.remove}>
              <Trash2 size={13} />
              删除
            </button>
          </div>
          <p className="species-note">
            自由造景时拖动坐标手柄移动物品。石头与沉木启用近似碰撞约束。
          </p>
        </section>
      ) : (
        <section className="tank-summary">
          <div className="summary-icon">
            <Droplets size={20} />
          </div>
          <div>
            <strong>自然水草缸</strong>
            <small>
              {s.doc.tank.width * 20} × {s.doc.tank.depth * 20} ×{" "}
              {s.doc.tank.height * 20} cm
            </small>
          </div>
          <span className="healthy">运行中</span>
        </section>
      )}
      <DevicePanel />
      <EquipmentSummary />
      <div className="property-tabs">
        <button
          className={tab === "environment" ? "active" : ""}
          onClick={() => setTab("environment")}
        >
          <SlidersHorizontal size={12} />
          环境参数
        </button>
        <button
          className={tab === "ecology" ? "active" : ""}
          onClick={() => setTab("ecology")}
        >
          <Activity size={12} />
          生态水质
        </button>
      </div>
      {tab === "environment" ? (
        <>
          <div className="section-caption">
            <Sun size={13} />
            光照与昼夜 <ChevronDown size={12} />
          </div>
          <Slider
            label="灯光亮度"
            field="brightness"
            min={0}
            max={1.5}
            step={0.01}
            factor={100}
            unit="%"
          />
          <Slider
            label="灯光色温"
            field="kelvin"
            min={3000}
            max={10000}
            step={100}
            unit="K"
          />
          <div className="toggle-row">
            <span>自然昼夜循环</span>
            <button
              aria-label="自然昼夜循环"
              aria-pressed={e.dayCycle}
              className={"switch " + (e.dayCycle ? "on" : "")}
              onClick={() => s.setEnvironment("dayCycle", !e.dayCycle)}
            >
              <i />
            </button>
          </div>
          <div className="sun-times">
            <label>
              日出
              <input
                aria-label="日出时间"
                type="number"
                min={0}
                max={11}
                value={e.sunrise}
                onChange={(ev) =>
                  s.setEnvironment(
                    "sunrise",
                    Math.max(0, Math.min(11, +ev.target.value)),
                  )
                }
              />
            </label>
            <label>
              日落
              <input
                aria-label="日落时间"
                type="number"
                min={12}
                max={24}
                value={e.sunset}
                onChange={(ev) =>
                  s.setEnvironment(
                    "sunset",
                    Math.max(12, Math.min(24, +ev.target.value)),
                  )
                }
              />
            </label>
          </div>
          <div className="section-caption">
            <Wind size={13} />
            水体与设备 <ChevronDown size={12} />
          </div>
          <Slider
            label="水温"
            field="temperature"
            min={16}
            max={34}
            step={0.1}
            unit="°C"
          />
          <Slider
            label="水流强度"
            field="flow"
            min={0}
            max={1}
            step={0.01}
            factor={100}
            unit="%"
          />
          <Slider
            label="气泡强度"
            field="bubbles"
            min={0}
            max={1}
            step={0.01}
            factor={100}
            unit="%"
          />
          <Slider
            label="水体清澈度"
            field="clarity"
            min={0.1}
            max={1}
            step={0.01}
            factor={100}
            unit="%"
          />
          <Slider
            label="水草摆动"
            field="sway"
            min={0}
            max={1}
            step={0.01}
            factor={100}
            unit="%"
          />
          <Slider
            label="过滤效率"
            field="filter"
            min={0}
            max={1}
            step={0.01}
            factor={100}
            unit="%"
          />
        </>
      ) : (
        <>
          <div className="water-quality">
            <span>
              <i className="dot" />
              水质综合状态
            </span>
            <strong>
              {eco.ammonia > 0.5 || eco.oxygen < 5 ? "需要养护" : "稳定"}
            </strong>
            <small>简化教学模型 · 非真实养殖预测</small>
          </div>
          <div className="ecology-grid">
            {[
              ["实际水温", eco.waterTemperature.toFixed(1), "°C"],
              ["溶解氧", eco.oxygen.toFixed(2), "mg/L"],
              ["pH", eco.ph.toFixed(2), ""],
              ["氨氮", eco.ammonia.toFixed(3), "mg/L"],
              ["亚硝酸盐", eco.nitrite.toFixed(3), "mg/L"],
              ["硝酸盐", eco.nitrate.toFixed(2), "mg/L"],
              ["食物残留", eco.waste.toFixed(2), "模拟值"],
            ].map(([name, value, unit]) => (
              <div key={name}>
                <span>{name}</span>
                <strong>
                  {value}
                  <small>{unit}</small>
                </strong>
              </div>
            ))}
          </div>
          <Trends />
          <div className="care-actions">
            <button onClick={() => s.care("water")}>
              <Droplets size={13} />
              换水 30%
            </button>
            <button onClick={() => s.care("clean")}>清洁鱼缸</button>
          </div>
          <p className="species-note">
            鱼类数量、残饵、温度、气泡和过滤影响水质。换水降低含氮物，清洁去除残留。
          </p>
        </>
      )}
      <div className="observing-card">
        <span className="dot" />
        <div>
          <strong>慢下来，看看水里的世界</strong>
          <p>点击一条鱼，了解它此刻的状态。</p>
        </div>
      </div>
    </aside>
  );
}
