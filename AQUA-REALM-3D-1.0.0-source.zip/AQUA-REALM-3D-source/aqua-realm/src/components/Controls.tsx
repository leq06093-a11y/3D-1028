import {
  Play,
  Pause,
  Fish,
  Sun,
  Volume2,
  VolumeX,
  ChevronDown,
} from "lucide-react";
import { useAquarium } from "../stores/aquarium";
export function Controls() {
  const s = useAquarium(),
    e = s.doc.environment;
  return (
    <>
      <footer className="controls">
        <div className="playback">
          <button
            className="play-button"
            aria-label={s.playing ? "暂停" : "播放"}
            onClick={() => s.set({ playing: !s.playing })}
          >
            {s.playing ? <Pause size={17} /> : <Play size={17} />}
          </button>
          <span className="play-label">
            {s.editing ? "造景暂停" : s.playing ? "生态运行中" : "模拟已暂停"}
            <small>SIMULATION</small>
          </span>
          <div className="speed-buttons">
            {[0.5, 1, 2, 5].map((v) => (
              <button
                key={v}
                className={s.speed === v ? "active" : ""}
                onClick={() => s.set({ speed: v })}
              >
                {v}×
              </button>
            ))}
          </div>
        </div>
        <div className="day-control">
          <Sun size={15} />
          <div>
            <div className="day-label">
              <span>水境时间</span>
              <b>
                {String(Math.floor(e.hour)).padStart(2, "0")}:
                {String(Math.floor((e.hour % 1) * 60)).padStart(2, "0")}
              </b>
            </div>
            <input
              aria-label="水境时间"
              type="range"
              min={0}
              max={23.99}
              step={0.01}
              value={e.hour}
              onChange={(ev) => s.setEnvironment("hour", +ev.target.value)}
            />
            <div className="day-marks">
              <span>00:00</span>
              <span>06:00</span>
              <span>12:00</span>
              <span>18:00</span>
              <span>24:00</span>
            </div>
          </div>
        </div>
        <button className="feed-button" onClick={() => s.feed()}>
          <Fish size={15} />
          投喂<span>FEED</span>
        </button>
        <select
          className="food-choice"
          aria-label="饲料类型"
          defaultValue="sinking"
          onChange={(e) => {
            const mode = e.target.value as "sinking" | "floating";
            s.feed(mode);
            e.target.selectedIndex = 0;
          }}
        >
          <option value="sinking">沉降饲料</option>
          <option value="floating">投喂浮水饲料</option>
        </select>
        <span className="v-divider" />
        <label className="quality-control">
          画质
          <select
            aria-label="画质"
            value={s.quality}
            onChange={(ev) =>
              s.set({ quality: ev.target.value as typeof s.quality })
            }
          >
            <option value="low">流畅</option>
            <option value="medium">均衡</option>
            <option value="high">精细</option>
          </select>
          <ChevronDown size={11} />
        </label>
        <button
          className="sound-button"
          aria-label="环境音效"
          aria-pressed={e.sound}
          onClick={() => s.setEnvironment("sound", !e.sound)}
        >
          {e.sound ? <Volume2 size={16} /> : <VolumeX size={16} />}
        </button>
      </footer>
      <div className="status-bar">
        <span>
          <i className="dot" />
          {s.notice}
        </span>
        <span>
          {s.doc.fish.length} FISH <i /> {s.doc.decorations.length} OBJECTS{" "}
          <i /> <b className={s.fps < 30 ? "fps-low" : ""}>{s.fps} FPS</b>
          <i /> WEBGL 2 <i />{" "}
          {s.sessionStatus === "saving"
            ? "正在保存"
            : s.sessionStatus === "saved"
              ? "已自动保存"
              : s.sessionStatus === "error"
                ? "自动保存失败"
                : "自动存档开启"}
        </span>
        <span>AQUA REALM 3D · AQUARIUM STUDIO</span>
      </div>
    </>
  );
}
