import { useState } from "react";
import {
  Search,
  Plus,
  Fish,
  Leaf,
  Mountain,
  TreePine,
  SlidersHorizontal,
  Lightbulb,
  LayoutGrid,
  ChevronRight,
  BookOpen,
  Thermometer,
  Sprout,
} from "lucide-react";
import { useAquarium } from "../stores/aquarium";
import type { ItemKind } from "../simulation/model";
import { speciesList, PLANTS, type SpeciesId } from "../assets/catalog";
const categories = [
  ["all", LayoutGrid, "全部资源"],
  ["fish", Fish, "鱼类"],
  ["plant", Leaf, "水草"],
  ["rock", Mountain, "石头"],
  ["wood", TreePine, "沉木"],
  ["substrate", Sprout, "底砂与背景"],
  ["filter", SlidersHorizontal, "过滤与加热"],
  ["light", Lightbulb, "灯光设备"],
  ["preset", LayoutGrid, "场景预设"],
] as const;
interface Asset {
  id: string;
  kind: ItemKind | "fish";
  name: string;
  latin: string;
  tag: string;
  icon: typeof Fish;
  species?: SpeciesId;
  variant?: number;
  image?: string;
}
const assets: Asset[] = [
  ...speciesList.map((spec) => ({
    id: spec.id,
    kind: "fish" as const,
    name: spec.name,
    latin: spec.latin,
    tag: spec.source + " · 动态 GLB",
    icon: Fish,
    species: spec.id,
    image:
      spec.id === "barramundi"
        ? "./assets/BarramundiFish-preview.jpg"
        : `./assets/fish/${spec.id}-preview.png`,
  })),
  ...PLANTS.map((p) => ({
    id: "plant-" + p.id,
    kind: "plant" as const,
    name: p.name,
    latin: p.description,
    tag: "原创叶片 · 动态",
    icon: Leaf,
    variant: p.id,
  })),
  {
    id: "rock",
    kind: "rock",
    name: "青龙石",
    latin: "Layered stone",
    tag: "原创地质纹理",
    icon: Mountain,
  },
  {
    id: "wood",
    kind: "wood",
    name: "枝状沉木",
    latin: "Root driftwood",
    tag: "原创曲面枝干",
    icon: TreePine,
  },
  {
    id: "filter",
    kind: "filter",
    name: "循环过滤器",
    latin: "Internal filter",
    tag: "实际过滤与水流",
    icon: SlidersHorizontal,
  },
  {
    id: "heater",
    kind: "heater",
    name: "恒温加热棒",
    latin: "Thermostatic heater",
    tag: "实际恒温控制",
    icon: Thermometer,
  },
  {
    id: "light",
    kind: "light",
    name: "全光谱灯具",
    latin: "Aquarium lighting",
    tag: "实际照明控制",
    icon: Lightbulb,
  },
];
export function Library() {
  const [category, setCategory] = useState("all"),
    [query, setQuery] = useState(""),
    s = useAquarium(),
    filtered = assets.filter(
      (a) =>
        (category === "all" ||
          a.kind === category ||
          (category === "filter" && a.kind === "heater")) &&
        `${a.name}${a.latin}`.toLowerCase().includes(query.toLowerCase()),
    );
  return (
    <aside className="library side-panel">
      <div className="panel-title">
        <span>资源库</span>
        <small>ASSET LIBRARY</small>
      </div>
      <label className="search">
        <Search size={13} />
        <input
          aria-label="搜索资源"
          placeholder="搜索鱼类、植物、造景…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <kbd>⌕</kbd>
      </label>
      <div className="category-list">
        {categories.map(([id, Icon, name]) => (
          <button
            key={id}
            className={category === id ? "active" : ""}
            onClick={() => setCategory(id)}
          >
            <Icon size={14} />
            <span>{name}</span>
            {id === "all" ? (
              <small>{assets.length}</small>
            ) : (
              <ChevronRight size={11} />
            )}
          </button>
        ))}
      </div>
      <div className="library-heading">
        <span>
          {category === "preset"
            ? "造景方案"
            : category === "substrate"
              ? "材质方案"
              : "精选资源"}
        </span>
        <span>
          {category === "all" ? assets.length + " ITEMS" : "COLLECTION"}
        </span>
      </div>
      {category === "preset" ? (
        <div className="preset-list">
          {[
            ["nature", "自然草缸", "NATURE GARDEN"],
            ["wood", "沉木秘境", "DRIFTWOOD"],
            ["minimal", "极简观赏", "MINIMAL"],
          ].map(([id, name, sub]) => (
            <button key={id} onClick={() => s.applyPreset(id)}>
              <div className={"preset-preview " + id}>
                <Leaf size={30} />
                <TreePine size={36} />
                <Mountain size={25} />
              </div>
              <strong>{name}</strong>
              <small>{sub} · 点击应用</small>
            </button>
          ))}
        </div>
      ) : category === "substrate" ? (
        <section className="surface-library">
          <h3>底砂材质</h3>
          {[
            ["natural", "天然河砂"],
            ["black", "黑曜石砂"],
            ["white", "浅色石英砂"],
          ].map(([id, name]) => (
            <button
              key={id}
              className={
                "substrate-card " +
                id +
                (s.doc.substrate === id ? " active" : "")
              }
              onClick={() => s.setSurface("substrate", id)}
            >
              <i />
              {name}
              <small>{s.doc.substrate === id ? "已应用" : "点击应用"}</small>
            </button>
          ))}
          <h3>鱼缸背景</h3>
          {[
            ["forest", "深绿植物背景"],
            ["slate", "冷灰岩壁背景"],
            ["black", "纯黑观赏背景"],
          ].map(([id, name]) => (
            <button
              key={id}
              className={
                "background-card " + (s.doc.background === id ? "active" : "")
              }
              onClick={() => s.setSurface("background", id)}
            >
              {name}
            </button>
          ))}
        </section>
      ) : (
        <div className="asset-grid">
          {filtered.map((a) => (
            <button
              key={a.id}
              className="asset-card"
              onClick={() => s.add(a.kind, a.species, a.variant)}
            >
              <div className={"asset-image " + a.kind}>
                {a.image ? (
                  <img src={a.image} alt={a.name + "模型缩略图"} />
                ) : (
                  <a.icon size={40} strokeWidth={1} />
                )}
                <span className="add-asset">
                  <Plus size={12} />
                </span>
              </div>
              <strong>{a.name}</strong>
              <small>{a.latin}</small>
              <em>{a.tag}</em>
            </button>
          ))}
          {!filtered.length && <p className="empty-search">没有匹配的资源</p>}
        </div>
      )}
      <div className="library-note">
        <BookOpen size={16} />
        <div>
          <strong>一个会呼吸的微型世界</strong>
          <p>5 种独立鱼体，5 类水草。不同物种拥有各自的游动与水层偏好。</p>
          <span>原创素材与 CC0 来源均有记录</span>
        </div>
      </div>
      <div className="library-footer">
        <span className="dot" />
        所有资源均保存在本地
      </div>
    </aside>
  );
}
