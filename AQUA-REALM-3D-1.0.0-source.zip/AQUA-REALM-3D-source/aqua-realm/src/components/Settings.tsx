import { useState } from "react";
import { X, Settings2 } from "lucide-react";
import { useAquarium } from "../stores/aquarium";
import { constrain } from "../simulation/model";
import { rendererDiagnostics } from "../utils/useAppSession";
export function Settings({ onClose }: { onClose: () => void }) {
  const s = useAquarium(),
    [size, setSize] = useState({ ...s.doc.tank });
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <section
        className="settings-modal"
        role="dialog"
        aria-modal="true"
        aria-label="水境设置"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="modal-heading">
          <Settings2 size={19} />
          <h2>水境设置</h2>
          <button aria-label="关闭设置" onClick={onClose}>
            <X size={18} />
          </button>
        </div>
        <p>调整鱼缸尺寸与观察体验。场景单位约等于 20 cm。</p>
        <h3>鱼缸尺寸</h3>
        <div className="size-inputs">
          {(
            [
              ["width", "长度", 4, 10],
              ["height", "高度", 2.5, 6],
              ["depth", "深度", 2, 5],
            ] as const
          ).map(([key, label, min, max]) => (
            <label key={key}>
              {label}
              <input
                aria-label={`鱼缸${label}`}
                type="number"
                min={min}
                max={max}
                step={0.1}
                value={size[key]}
                onChange={(e) =>
                  setSize({
                    ...size,
                    [key]: Math.max(min, Math.min(max, +e.target.value)),
                  })
                }
              />
            </label>
          ))}
        </div>
        <button
          className="primary-button"
          onClick={() => {
            s.resize(size);
            onClose();
          }}
        >
          应用尺寸
        </button>
        <label className="parameter">
          <span>
            镜头操作灵敏度<b>{s.sensitivity.toFixed(1)}×</b>
          </span>
          <input
            aria-label="镜头操作灵敏度"
            type="range"
            min={0.3}
            max={2}
            step={0.1}
            value={s.sensitivity}
            onChange={(e) => s.set({ sensitivity: +e.target.value })}
          />
        </label>
        <label className="parameter">
          <span>
            镜头移动速度<b>{s.cameraSpeed.toFixed(1)}×</b>
          </span>
          <input
            aria-label="镜头移动速度"
            type="range"
            min={0.3}
            max={3}
            step={0.1}
            value={s.cameraSpeed}
            onChange={(e) => s.set({ cameraSpeed: +e.target.value })}
          />
        </label>
        <section className="render-diagnostics">
          <h3>实时渲染诊断</h3>
          <dl>
            <div>
              <dt>帧率</dt>
              <dd>{s.fps} FPS</dd>
            </div>
            <div>
              <dt>绘制调用</dt>
              <dd>{s.diagnostics.calls}</dd>
            </div>
            <div>
              <dt>三角形</dt>
              <dd>{s.diagnostics.triangles.toLocaleString()}</dd>
            </div>
            <div>
              <dt>几何体 / 纹理</dt>
              <dd>
                {s.diagnostics.geometries} / {s.diagnostics.textures}
              </dd>
            </div>
            <div>
              <dt>纹理数据估算</dt>
              <dd>{(s.diagnostics.textureBytes / 1048576).toFixed(1)} MB</dd>
            </div>
          </dl>
          <p className="species-note">
            纹理尺寸推算，非驱动实测显存；GPU 分配与压缩会影响实际占用。
          </p>
        </section>
        <section className="support-actions">
          <h3>保存与故障诊断</h3>
          <p className="species-note">
            每 15
            秒自动存档，退出前再次保存，并保留上一份备份。离线期间不推进生态。
          </p>
          <button
            onClick={async () => {
              if (window.aquaDesktop) {
                try {
                  if (
                    await window.aquaDesktop.exportDiagnostics(
                      rendererDiagnostics(),
                    )
                  )
                    s.set({ notice: "诊断报告已导出" });
                } catch {
                  s.set({ notice: "诊断报告导出失败，请检查文件权限" });
                }
              } else {
                const a = document.createElement("a");
                a.href = URL.createObjectURL(
                  new Blob([rendererDiagnostics()], {
                    type: "application/json",
                  }),
                );
                a.download = "AQUA-REALM-diagnostics.json";
                a.click();
                setTimeout(() => URL.revokeObjectURL(a.href), 1000);
              }
            }}
          >
            导出运行诊断
          </button>
          {window.aquaDesktop && (
            <button
              onClick={async () => {
                try {
                  const error = await window.aquaDesktop?.openDataFolder();
                  if (error)
                    s.set({
                      notice: "未能打开存档目录，请先使用保存按钮导出场景",
                    });
                } catch {
                  s.set({ notice: "未能打开存档目录" });
                }
              }}
            >
              打开自动存档目录
            </button>
          )}
        </section>
        <div className="settings-info">
          <h3>关于当前版本</h3>
          <p>
            含 5 种不同鱼类模型（1 种 CC0、4
            种原创解剖网格与动画）。生态为教学娱乐近似模型，尚未在 Windows RTX
            设备上验收，不宣称照片级效果或 60 FPS。
          </p>
        </div>
        <button
          className="secondary-button"
          onClick={() => {
            s.resetScene();
            onClose();
          }}
        >
          恢复默认鱼缸（可以撤销）
        </button>
      </section>
    </div>
  );
}
