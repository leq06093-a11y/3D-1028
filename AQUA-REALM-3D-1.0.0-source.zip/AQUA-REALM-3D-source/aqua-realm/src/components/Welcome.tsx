import { Fish, MousePointer2, Utensils, Save, ArrowRight } from "lucide-react";
export function Welcome({ onStart }: { onStart: () => void }) {
  return (
    <div className="welcome-backdrop">
      <section
        className="welcome-card"
        role="dialog"
        aria-modal="true"
        aria-label="首次使用"
      >
        <div className="welcome-logo">
          <Fish size={32} />
        </div>
        <span className="eyebrow">WELCOME TO YOUR UNDERWATER WORLD</span>
        <h1>欢迎来到，水境。</h1>
        <p>鱼缸已准备好了。不用连接账号，也不需要输入命令。</p>
        <div className="welcome-steps">
          <div>
            <MousePointer2 size={21} />
            <strong>自由观察</strong>
            <span>
              按住左键拖动，滚轮缩放。
              <br />
              点击小鱼，了解它的状态。
            </span>
          </div>
          <div>
            <Utensils size={21} />
            <strong>照料生命</strong>
            <span>
              底部点击投喂。
              <br />
              右侧可以调灯光、换水和清洁。
            </span>
          </div>
          <div>
            <Save size={21} />
            <strong>随时回来</strong>
            <span>
              自动保存，退出前再保存一次。
              <br />
              下次打开会恢复这片水境。
            </span>
          </div>
        </div>
        <button className="welcome-start" onClick={onStart}>
          开始养鱼
          <ArrowRight size={17} />
        </button>
        <small>生态为教学娱乐近似；所有素材均在本地，离线也能使用。</small>
      </section>
    </div>
  );
}
