import { useState } from "react";
import { useAquarium } from "../stores/aquarium";
import type { TrendSample } from "../simulation/trends";
const series = {
  oxygen: { name: "溶解氧", unit: "mg/L", color: "#91d9b7" },
  ammonia: { name: "氨氮", unit: "mg/L", color: "#d5b47e" },
  nitrate: { name: "硝酸盐", unit: "mg/L", color: "#8ab7d9" },
  temperature: { name: "实际水温", unit: "°C", color: "#ba9bdc" },
};
export function Trends() {
  const samples = useAquarium((s) => s.doc.trend),
    [metric, setMetric] = useState<keyof typeof series>("oxygen"),
    config = series[metric];
  const values = samples.map((v) => v[metric]),
    lo = Math.min(...values),
    hi = Math.max(...values),
    spread = Math.max(0.1, (hi - lo) * 1.3),
    bottom = Number.isFinite(lo) ? lo - spread * 0.15 : 0;
  const start = samples[0]?.time ?? 0,
    end = samples.at(-1)?.time ?? start;
  return (
    <section className="ecology-trends">
      <div className="trend-heading">
        <h3>生态趋势 · 实测模拟记录</h3>
        <select
          aria-label="趋势指标"
          value={metric}
          onChange={(e) => setMetric(e.target.value as keyof typeof series)}
        >
          {Object.entries(series).map(([id, c]) => (
            <option key={id} value={id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>
      {samples.length < 2 ? (
        <div className="trend-waiting">
          每 5 模拟秒采样一次，等待第二个数据点…
        </div>
      ) : (
        <>
          <div className="trend-readout">
            <strong>
              {samples.at(-1)![metric].toFixed(metric === "ammonia" ? 3 : 2)}
            </strong>
            <span>
              {config.unit} · 最近 {Math.round((end - start) / 60)} 分钟
            </span>
          </div>
          <svg
            viewBox="0 0 240 100"
            role="img"
            aria-label={config.name + "真实趋势图"}
          >
            <path
              d="M4 20H236M4 50H236M4 80H236"
              stroke="#2b4140"
              strokeDasharray="3 4"
            />
            <polyline
              points={samples
                .map(
                  (v, i) =>
                    `${4 + ((v.time - start) / Math.max(1, end - start)) * 232},${85 - ((v[metric] - bottom) / spread) * 70}`,
                )
                .join(" ")}
              fill="none"
              stroke={config.color}
              strokeWidth="2"
            />
          </svg>
          <div className="trend-axis">
            <span>{Math.round(start)}s</span>
            <span>{samples.length} 个真实采样点</span>
            <span>{Math.round(end)}s</span>
          </div>
        </>
      )}
      <p className="species-note">
        仅来自运行中的近似模型；随存档保留，最多保存 360 个采样点。
      </p>
    </section>
  );
}
