import { Component, type ReactNode } from "react";
import { recoverGraphics } from "../utils/recover";
export class AppBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error) {
    console.error("AQUA REALM UI error:", error.message);
  }
  render() {
    return this.state.failed ? (
      <div className="startup-screen">
        <h1>水境需要重新打开</h1>
        <p>最近的自动存档会保留。重新打开后会尝试恢复。</p>
        <button onClick={() => void recoverGraphics()}>重新打开水境</button>
      </div>
    ) : (
      this.props.children
    );
  }
}
