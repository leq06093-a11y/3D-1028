import {clamp} from '../simulation/model';
/** Preserve the dragged scale axis in both directions, then enforce uniform scale. */
export function uniformScale(values:readonly number[],previous:number){const changed=values.reduce((best,n)=>Math.abs(n-previous)>Math.abs(best-previous)?n:best,previous);return clamp(changed,.2,2);}
