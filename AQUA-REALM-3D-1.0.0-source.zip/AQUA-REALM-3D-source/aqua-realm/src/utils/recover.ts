import { useAquarium } from "../stores/aquarium";
export async function recoverGraphics() {
  try {
    const text = useAquarium.getState().serialize();
    if (window.aquaDesktop?.saveSession)
      await window.aquaDesktop.saveSession(text);
    else localStorage.setItem("aqua-realm-last-session-v1", text);
  } catch {}
  const url = new URL(location.href);
  url.searchParams.set("safe", "1");
  location.replace(url.href);
}
