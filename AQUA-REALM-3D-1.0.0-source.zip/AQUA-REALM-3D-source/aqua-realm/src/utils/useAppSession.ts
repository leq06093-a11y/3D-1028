import { validateDocument } from "../simulation/model";
import { useEffect, useRef, useState } from "react";
import { useAquarium } from "../stores/aquarium";
import type { SessionResult } from "./desktop";
const KEY = "aqua-realm-last-session-v1",
  BACKUP = KEY + "-backup";
function readWeb(): SessionResult {
  const current = localStorage.getItem(KEY);
  if (!current) return { text: null, source: "empty", savedAt: null };
  try {
    validateDocument(JSON.parse(current));
    return { text: current, source: "primary", savedAt: null };
  } catch {
    const backup = localStorage.getItem(BACKUP);
    if (backup) {
      try {
        validateDocument(JSON.parse(backup));
        return { text: backup, source: "backup", savedAt: null };
      } catch {}
    }
    return { text: null, source: "damaged", savedAt: null };
  }
}
async function persist(force = false) {
  const state = useAquarium.getState();
  if (!force && !state.dirty) return true;
  try {
    state.set({ sessionStatus: "saving" });
    const text = state.serialize();
    let savedAt;
    if (window.aquaDesktop?.saveSession) {
      savedAt = (await window.aquaDesktop.saveSession(text)).savedAt;
    } else {
      const previous = localStorage.getItem(KEY);
      if (previous) {
        try {
          JSON.parse(previous);
          localStorage.setItem(BACKUP, previous);
        } catch {}
      }
      localStorage.setItem(KEY, text);
      savedAt = new Date().toISOString();
    }
    useAquarium
      .getState()
      .set({ sessionStatus: "saved", sessionSavedAt: savedAt });
    return true;
  } catch {
    useAquarium.getState().set({
      sessionStatus: "error",
      notice: "自动保存失败，请使用顶部保存按钮导出场景，并检查存储空间",
    });
    return false;
  }
}
export function useAppSession() {
  const [booting, setBooting] = useState(true),
    [welcome, setWelcome] = useState(false),
    readyTask = useRef<Promise<void>>(Promise.resolve());
  useEffect(() => {
    let active = true;
    const boot = async () => {
      try {
        let result = window.aquaDesktop?.loadSession
          ? await window.aquaDesktop.loadSession()
          : readWeb();
        const state = useAquarium.getState();
        let restored = result.text
          ? state.importText(result.text, false)
          : false;
        if (
          result.text &&
          !restored &&
          result.source === "primary" &&
          window.aquaDesktop?.loadSession
        ) {
          result = await window.aquaDesktop.loadSession(true);
          restored = result.text ? state.importText(result.text, false) : false;
        }
        if (restored) {
          state.set({
            notice:
              result.source === "backup"
                ? "自动存档有损坏，已从备份恢复上次鱼缸"
                : "已恢复上次鱼缸 · 离线期间不推进模拟",
            sessionSavedAt: result.savedAt,
            sessionStatus: "saved",
          });
        } else {
          if (result.source === "damaged" || result.text)
            state.set({
              notice:
                "上次存档未能读取，已开启新鱼缸；原文件保留，可从数据目录找回",
            });
          if (active) setWelcome(true);
        }
        if (new URLSearchParams(location.search).get("safe") === "1")
          state.set({
            quality: "low",
            notice: "已以流畅画质恢复，请保存或导出诊断报告",
          });
      } catch {
        useAquarium.getState().set({
          notice: "未能读取自动存档，当前仍可使用顶部保存按钮手动保存",
        });
        if (active) setWelcome(true);
      } finally {
        if (active) setBooting(false);
      }
    };
    readyTask.current = boot();
    const interval = setInterval(() => {
      void readyTask.current.then(() => persist());
    }, 15000);
    const unsubscribe = window.aquaDesktop?.onBeforeClose(() => {
      void readyTask.current
        .then(() => persist(true))
        .then((ok) => window.aquaDesktop?.closeReady(ok));
    });
    const beforeUnload = () => {
      if (!window.aquaDesktop) {
        try {
          const text = useAquarium.getState().serialize();
          const old = localStorage.getItem(KEY);
          if (old) localStorage.setItem(BACKUP, old);
          localStorage.setItem(KEY, text);
        } catch {}
      }
    };
    window.addEventListener("beforeunload", beforeUnload);
    return () => {
      active = false;
      clearInterval(interval);
      unsubscribe?.();
      window.removeEventListener("beforeunload", beforeUnload);
    };
  }, []);
  return {
    booting,
    welcome,
    begin: () => {
      setWelcome(false);
      void persist(true);
    },
    saveNow: () => persist(true),
  };
}
export function rendererDiagnostics() {
  const s = useAquarium.getState();
  return JSON.stringify({
    timestamp: new Date().toISOString(),
    quality: s.quality,
    fps: s.fps,
    fish: s.doc.fish.length,
    objects: s.doc.decorations.length,
    render: s.diagnostics,
    windowSize: {
      width: innerWidth,
      height: innerHeight,
      pixelRatio: devicePixelRatio,
    },
    sessionStatus: s.sessionStatus,
    approximateTextureBytes: s.diagnostics.textureBytes,
    note: "Texture memory is an estimate, not measured driver VRAM. Simulation is for teaching and entertainment.",
  });
}
