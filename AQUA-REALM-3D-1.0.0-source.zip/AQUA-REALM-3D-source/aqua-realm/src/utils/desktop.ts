export interface SessionResult {
  text: string | null;
  source: "primary" | "backup" | "empty" | "damaged";
  savedAt: string | null;
}
export interface DesktopBridge {
  save: (text: string) => Promise<boolean>;
  load: () => Promise<string | null>;
  loadSession: (backup?: boolean) => Promise<SessionResult>;
  saveSession: (text: string) => Promise<{ savedAt: string }>;
  onBeforeClose: (callback: () => void) => () => void;
  closeReady: (ok: boolean) => void;
  exportDiagnostics: (text: string) => Promise<boolean>;
  openDataFolder: () => Promise<string>;
}
declare global {
  interface Window {
    aquaDesktop?: DesktopBridge;
  }
}
