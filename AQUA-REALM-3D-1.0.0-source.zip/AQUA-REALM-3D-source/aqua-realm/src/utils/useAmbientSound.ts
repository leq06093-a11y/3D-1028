import { useEffect } from "react";
import { useAquarium } from "../stores/aquarium";
export function useAmbientSound() {
  const enabled = useAquarium((s) => s.doc.environment.sound);
  useEffect(() => {
    if (!enabled) return;
    const ctx = new AudioContext(),
      buffer = ctx.createBuffer(1, ctx.sampleRate * 3, ctx.sampleRate),
      data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++)
      data[i] = (Math.random() * 2 - 1) * 0.15;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 600;
    const gain = ctx.createGain();
    gain.gain.value = 0.12;
    source.connect(filter).connect(gain).connect(ctx.destination);
    void ctx
      .resume()
      .catch(() =>
        useAquarium
          .getState()
          .set({ notice: "音频未能启动，请重新切换环境音效" }),
      );
    source.start();
    return () => {
      source.stop();
      void ctx.close();
    };
  }, [enabled]);
}
