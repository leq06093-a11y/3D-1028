import type {} from "../utils/desktop";
import { create } from "zustand";
import {
  initialDocument,
  validateDocument,
  preset,
  makeFish,
  constrain,
  canPlace,
  type Document,
  type Decoration,
  type Environment,
  type Food,
  type ItemKind,
  itemNames,
} from "../simulation/model";
import { speciesOf, type SpeciesId } from "../assets/catalog";
import { resizePositions } from "../simulation/devices";
export type CameraMode = "overview" | "free" | "underwater" | "follow";
interface State {
  doc: Document;
  food: Food[];
  selected: string | null;
  mode: CameraMode;
  editing: boolean;
  editTool: "translate" | "rotate" | "scale";
  verticalEditing: boolean;
  diagnostics: {
    calls: number;
    triangles: number;
    geometries: number;
    textures: number;
    textureBytes: number;
  };
  playing: boolean;
  speed: number;
  quality: "low" | "medium" | "high";
  sessionStatus: "idle" | "saving" | "saved" | "error";
  sessionSavedAt: string | null;
  sensitivity: number;
  cameraSpeed: number;
  ripple: { x: number; z: number; at: number };
  fps: number;
  notice: string;
  history: Document[];
  future: Document[];
  dirty: boolean;
  tick: number;
  setEnvironment: (key: keyof Environment, value: number | boolean) => void;
  set: (patch: Partial<State>) => void;
  checkpoint: () => void;
  undo: () => void;
  redo: () => void;
  add: (kind: ItemKind | "fish", species?: SpeciesId, variant?: number) => void;
  resize: (tank: Document["tank"]) => void;
  setSurface: (key: "substrate" | "background", value: string) => void;
  updateItem: (id: string, patch: Partial<Decoration>) => void;
  remove: () => void;
  duplicate: () => void;
  feed: (mode?: "floating" | "sinking", at?: [number, number]) => void;
  resetScene: () => void;
  care: (action: "water" | "clean") => void;
  applyPreset: (name: string) => void;
  serialize: () => string;
  save: () => Promise<void>;
  load: () => Promise<void>;
  importText: (text: string, recordHistory?: boolean) => boolean;
}
const initial = initialDocument();
export const useAquarium = create<State>((set, get) => ({
  doc: initial,
  food: initial.food,
  selected: null,
  mode: "overview",
  editing: false,
  editTool: "translate",
  verticalEditing: false,
  diagnostics: {
    calls: 0,
    triangles: 0,
    geometries: 0,
    textures: 0,
    textureBytes: 0,
  },
  playing: true,
  speed: 1,
  quality: "medium",
  sessionStatus: "idle",
  sessionSavedAt: null,
  sensitivity: 1,
  cameraSpeed: 1,
  ripple: { x: 0, z: 0, at: -100 },
  fps: 0,
  notice: "欢迎来到水境 · 拖动旋转，滚轮缩放",
  history: [],
  future: [],
  dirty: false,
  tick: 0,
  set: (patch) => set(patch),
  checkpoint: () =>
    set((s) => ({
      history: [
        ...s.history.slice(-29),
        structuredClone({ ...s.doc, food: s.food }),
      ],
      future: [],
      dirty: true,
    })),
  setEnvironment: (key, value) => {
    get().checkpoint();
    if (
      (key === "brightness" || key === "flow") &&
      typeof value === "number" &&
      Math.abs(value - (get().doc.environment[key] as number)) > 0.25
    )
      for (const f of get().doc.fish) f.alert = 3;
    set((s) => ({
      doc: { ...s.doc, environment: { ...s.doc.environment, [key]: value } },
    }));
  },
  undo: () => {
    const s = get(),
      last = s.history.at(-1);
    if (!last) return;
    set({
      doc: structuredClone(last),
      history: s.history.slice(0, -1),
      future: [structuredClone(s.doc), ...s.future],
      selected: null,
      food: structuredClone(last.food),
      notice: "已撤销",
      dirty: true,
    });
  },
  redo: () => {
    const s = get(),
      next = s.future[0];
    if (!next) return;
    set({
      doc: structuredClone(next),
      history: [...s.history, structuredClone({ ...s.doc, food: s.food })],
      future: s.future.slice(1),
      selected: null,
      food: structuredClone(next.food),
      notice: "已重做",
      dirty: true,
    });
  },
  add: (kind, species = "barramundi", variant) => {
    const s = get();
    if (kind === "fish" && s.doc.fish.length >= 80) {
      set({ notice: "最多支持 80 条鱼；大量鱼类建议降低画质" });
      return;
    }
    if (kind !== "fish" && s.doc.decorations.length >= 100) {
      set({ notice: "造景物品数量已达上限" });
      return;
    }
    s.checkpoint();
    if (kind === "fish") {
      const fish = makeFish(s.doc.fish.length, species);
      set({
        doc: { ...s.doc, fish: [...s.doc.fish, fish] },
        selected: fish.id,
        notice:
          species === "barramundi"
            ? "已添加亚洲海鲈：大型捕食鱼，不建议与小型鱼混养"
            : "已添加" + speciesOf(species).name,
      });
    } else {
      const id = crypto.randomUUID(),
        candidate: Decoration = {
          id,
          kind,
          name: itemNames[kind],
          position: [0, 0.15, 0],
          rotation: 0,
          scale: 0.7,
          variant: variant ?? s.doc.decorations.length,
          enabled: true,
          power: 1,
        };
      let found = false;
      for (let i = 0; i < 100; i++) {
        candidate.position = [
          (Math.random() - 0.5) * (s.doc.tank.width - 1),
          kind === "light" ? s.doc.tank.height + 0.3 : 0.15,
          (Math.random() - 0.5) * (s.doc.tank.depth - 1),
        ];
        Object.assign(candidate, constrain(candidate, s.doc.tank));
        if (canPlace(candidate, s.doc.decorations)) {
          found = true;
          break;
        }
      }
      if (!found) {
        set({ notice: "没有合适的空间，请先移动已有造景" });
        return;
      }
      set({
        doc: { ...s.doc, decorations: [...s.doc.decorations, candidate] },
        selected: id,
        editing: true,
        mode: "free",
        notice: "已添加造景 · 使用移动手柄调整位置",
      });
    }
  },
  updateItem: (id, patch) => {
    const s = get(),
      old = s.doc.decorations.find((i) => i.id === id);
    if (!old) return;
    const next = constrain({ ...old, ...patch }, s.doc.tank);
    if (!canPlace(next, s.doc.decorations)) {
      set({ notice: "物体发生碰撞，请选择其他位置" });
      return;
    }
    set({
      doc: {
        ...s.doc,
        decorations: s.doc.decorations.map((i) => (i.id === id ? next : i)),
      },
      dirty: true,
    });
  },
  remove: () => {
    const s = get();
    if (!s.selected) return;
    s.checkpoint();
    set({
      doc: {
        ...s.doc,
        fish: s.doc.fish.filter((f) => f.id !== s.selected),
        decorations: s.doc.decorations.filter((o) => o.id !== s.selected),
      },
      selected: null,
      notice: "已删除选中对象",
    });
  },
  duplicate: () => {
    const s = get(),
      o = s.doc.decorations.find((x) => x.id === s.selected);
    if (!o) return;
    const copy = constrain(
      {
        ...structuredClone(o),
        id: crypto.randomUUID(),
        position: [o.position[0] + 0.65, o.position[1], o.position[2] + 0.3],
      },
      s.doc.tank,
    );
    if (!canPlace(copy, s.doc.decorations)) {
      set({ notice: "附近没有空间可供复制" });
      return;
    }
    s.checkpoint();
    set({
      doc: { ...s.doc, decorations: [...s.doc.decorations, copy] },
      selected: copy.id,
      notice: "已复制对象",
    });
  },
  resize: (tank) => {
    const s = get();
    s.checkpoint();
    const doc = validateDocument({
      ...s.doc,
      tank,
      fish: resizePositions(s.doc.fish, s.doc.tank, tank),
      decorations: resizePositions(s.doc.decorations, s.doc.tank, tank),
      food: s.food.map((f) => ({
        ...f,
        position: [
          (f.position[0] * tank.width) / s.doc.tank.width,
          (f.position[1] * tank.height) / s.doc.tank.height,
          (f.position[2] * tank.depth) / s.doc.tank.depth,
        ],
      })),
    });
    set({ doc, food: doc.food, notice: "鱼缸尺寸已更新，保留对象相对位置" });
  },
  setSurface: (key, value) => {
    const s = get();
    try {
      const doc = validateDocument({ ...s.doc, [key]: value });
      s.checkpoint();
      set({ doc, notice: "造景材质已更新" });
    } catch {
      set({ notice: "材质参数无效" });
    }
  },
  resetScene: () => {
    get().checkpoint();
    const doc = initialDocument();
    set({
      doc,
      food: doc.food,
      selected: null,
      notice: "已恢复默认鱼缸（可撤销）",
    });
  },
  feed: (mode = "sinking", at = [0, 0]) => {
    const s = get();
    if (s.food.length > 80) {
      set({ notice: "食物较多，请等待鱼类摄食" });
      return;
    }
    const foodBase = Math.max(Date.now(), ...s.food.map((f) => f.id)) + 1;
    set({
      ripple: { x: at[0], z: at[1], at: performance.now() / 1000 },
      food: [
        ...s.food,
        ...Array.from({ length: 16 }, (_, i) => ({
          id: foodBase + i,
          position: [
            Math.max(
              -s.doc.tank.width / 2 + 0.2,
              Math.min(
                s.doc.tank.width / 2 - 0.2,
                at[0] + (Math.random() - 0.5) * 0.7,
              ),
            ),
            s.doc.tank.height - 0.25,
            Math.max(
              -s.doc.tank.depth / 2 + 0.2,
              Math.min(
                s.doc.tank.depth / 2 - 0.2,
                at[1] + (Math.random() - 0.5) * 0.5,
              ),
            ),
          ] as [number, number, number],
          age: 0,
          mode,
        })),
      ],
      dirty: true,
      notice: "已投喂 16 粒 · 注意避免过量喂食",
    });
  },
  care: (action) => {
    const s = get();
    s.checkpoint();
    set({
      doc: {
        ...s.doc,
        ecology: {
          ...s.doc.ecology,
          ammonia: s.doc.ecology.ammonia * (action === "water" ? 0.7 : 1),
          nitrite: s.doc.ecology.nitrite * (action === "water" ? 0.7 : 1),
          nitrate: s.doc.ecology.nitrate * (action === "water" ? 0.7 : 1),
          waste: s.doc.ecology.waste * 0.3,
        },
        environment: {
          ...s.doc.environment,
          clarity: Math.min(1, s.doc.environment.clarity + 0.08),
        },
      },
      notice: action === "water" ? "已完成 30% 换水" : "已清理底部残留",
    });
  },
  applyPreset: (name) => {
    get().checkpoint();
    set((s) => ({
      doc: {
        ...s.doc,
        decorations: preset(name).map((o) => constrain(o, s.doc.tank)),
      },
      selected: null,
      notice: "已应用造景预设",
    }));
  },
  serialize: () => {
    const current = get();
    const snapshot = {
      ...current.doc,
      food: current.food,
      view: {
        camera: current.mode,
        quality: current.quality,
        speed: current.speed,
        playing: current.playing,
        sensitivity: current.sensitivity,
        cameraSpeed: current.cameraSpeed,
        editing: current.editing,
        selected: current.selected,
      },
    };
    return JSON.stringify(validateDocument(snapshot), null, 2);
  },
  save: async () => {
    try {
      const json = get().serialize();
      if (window.aquaDesktop) {
        const ok = await window.aquaDesktop.save(json);
        if (!ok) return;
      } else {
        localStorage.setItem("aqua-realm-scene", json);
        const a = document.createElement("a");
        a.href = URL.createObjectURL(
          new Blob([json], { type: "application/json" }),
        );
        a.download = "AQUA-REALM-scene.json";
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      }
      set({ notice: "场景已保存为 JSON 文件", dirty: false });
    } catch {
      set({ notice: "保存失败：请检查存储空间或文件权限" });
    }
  },
  importText: (text, recordHistory = true) => {
    try {
      const doc = validateDocument(JSON.parse(text));
      if (recordHistory) get().checkpoint();
      set({
        ...(recordHistory ? {} : { history: [], future: [] }),
        doc,
        ...(doc.view
          ? {
              mode: doc.view.camera,
              quality: doc.view.quality,
              speed: doc.view.speed,
              playing: doc.view.playing,
              sensitivity: doc.view.sensitivity,
              cameraSpeed: doc.view.cameraSpeed,
              editing: doc.view.editing,
              selected: doc.view.selected,
            }
          : { selected: null }),
        food: doc.food,
        dirty: false,
        notice: "场景已加载",
      });
      return true;
    } catch (e) {
      set({
        notice: `加载失败：${e instanceof Error ? e.message : "文件无效"}`,
      });
      return false;
    }
  },
  load: async () => {
    if (window.aquaDesktop) {
      try {
        const json = await window.aquaDesktop.load();
        if (json) get().importText(json);
      } catch {
        set({ notice: "读取场景失败" });
      }
      return;
    }
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = async () => {
      const f = input.files?.[0];
      if (f) {
        if (f.size > 2e6) {
          set({ notice: "场景文件过大（上限 2MB）" });
          return;
        }
        get().importText(await f.text());
      }
    };
    input.click();
  },
}));
