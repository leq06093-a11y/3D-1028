import { useEffect, useState, useRef } from "react";
import { createRoot } from "react-dom/client";
import {
  Maximize2,
  PanelLeftClose,
  PanelLeftOpen,
  Info,
  Leaf,
  ChevronDown,
} from "lucide-react";
import Aquarium from "./scene/Aquarium";
import { useAppSession } from "./utils/useAppSession";
import { Welcome } from "./components/Welcome";
import { AppBoundary } from "./components/AppBoundary";
import { EditorTools } from "./components/DevicePanel";
import { Toolbar } from "./components/Toolbar";
import { Library } from "./components/Library";
import { Properties } from "./components/Properties";
import { Controls } from "./components/Controls";
import { Settings } from "./components/Settings";
import { useAquarium } from "./stores/aquarium";
import { useAmbientSound } from "./utils/useAmbientSound";
import "./style.css";
function App() {
  const [settings, setSettings] = useState(false),
    [immersive, setImmersive] = useState(false),
    [help, setHelp] = useState(false),
    [lowFps, setLowFps] = useState(false),
    s = useAquarium();
  useAmbientSound();
  const session = useAppSession();
  const fpsHintDismissed = useRef(false);
  useEffect(() => {
    let low = 0;
    const interval = setInterval(() => {
      const state = useAquarium.getState();
      if (
        state.fps > 0 &&
        state.fps < 25 &&
        state.quality !== "low" &&
        !fpsHintDismissed.current
      ) {
        if (++low >= 8) setLowFps(true);
      } else {
        low = 0;
        if (state.quality === "low") setLowFps(false);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  useEffect(() => {
    const handler = (ev: KeyboardEvent) => {
      if ((ev.target as HTMLElement).matches("input,textarea,select")) return;
      if (ev.key === "Escape") {
        setSettings(false);
        setHelp(false);
        setImmersive(false);
      }
      if ((ev.ctrlKey || ev.metaKey) && ev.key === "z") {
        ev.preventDefault();
        if (ev.shiftKey) useAquarium.getState().redo();
        else useAquarium.getState().undo();
      }
      if ((ev.ctrlKey || ev.metaKey) && ev.key === "s") {
        ev.preventDefault();
        void useAquarium.getState().save();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);
  if (session.booting)
    return (
      <div className="startup-screen">
        <FishLoader />
        <h1>正在打开你的水境</h1>
        <p>检查本地存档与资源…</p>
      </div>
    );
  return (
    <div className={"aqua-app " + (immersive ? "immersive" : "")}>
      {session.welcome && <Welcome onStart={session.begin} />}
      <Toolbar onSettings={() => setSettings(true)} />
      <div className="main-layout">
        {!immersive && <Library />}
        <main className="viewport">
          <div className="viewport-heading">
            <div>
              <span className="eyebrow">YOUR LIVING UNDERWATER WORLD</span>
              <h1>
                静谧之间，生机流转<span>A moment beneath the surface.</span>
              </h1>
            </div>
            <div className="scene-badge">
              <i className="dot" />
              自然生态 · 实时模拟
            </div>
          </div>
          <Aquarium />
          <EditorTools />
          <div className="viewport-tools">
            <button
              aria-label="隐藏侧栏"
              title="切换沉浸模式"
              onClick={() => setImmersive(!immersive)}
            >
              {immersive ? (
                <PanelLeftOpen size={16} />
              ) : (
                <PanelLeftClose size={16} />
              )}
            </button>
            <button
              aria-label="全屏"
              title="全屏"
              onClick={() => {
                if (document.fullscreenElement) void document.exitFullscreen();
                else
                  void document.documentElement
                    .requestFullscreen()
                    .catch(() =>
                      s.set({ notice: "当前窗口不支持全屏，可使用隐藏侧栏" }),
                    );
              }}
            >
              <Maximize2 size={15} />
            </button>
            <button
              aria-label="操作帮助"
              title="操作帮助"
              onClick={() => setHelp(!help)}
            >
              <Info size={15} />
            </button>
          </div>
          <div className="tank-label">
            <span>THE NATURE GARDEN</span>
            <div>
              <Leaf size={12} />
              自然草缸 <i />{" "}
              {Math.round(
                s.doc.tank.width * s.doc.tank.height * s.doc.tank.depth * 8,
              )}{" "}
              L
            </div>
          </div>
          <div className="viewport-bottom">
            <div className="mini-metrics">
              <span>
                <i className="dot" />
                水温
                <strong>
                  {s.doc.ecology.waterTemperature.toFixed(1)}
                  <small>°C</small>
                </strong>
              </span>
              <span>
                溶解氧
                <strong>
                  {s.doc.ecology.oxygen.toFixed(1)}
                  <small>mg/L</small>
                </strong>
              </span>
              <span>
                鱼类数量
                <strong>
                  {s.doc.fish.length}
                  <small>尾</small>
                </strong>
              </span>
            </div>
            <div className="mouse-hints">
              <span>↔ 拖动旋转</span>
              <span>⊙ 滚轮缩放</span>
              <span>⌖ 点击选中</span>
            </div>
          </div>
          {s.editing && (
            <div className="edit-banner">
              自由造景 · 鱼类已暂停 · 点击物品后拖动坐标手柄
            </div>
          )}
          {help && (
            <div className="help-popover">
              <h3>观察你的水下世界</h3>
              <p>左键拖动旋转，滚轮缩放。自由造景模式可用右键平移。</p>
              <p>
                点击鱼类查看状态并跟随；选择造景后可在右侧旋转、缩放、复制和删除。
              </p>
              <p>
                Ctrl+Z 撤销，Ctrl+Shift+Z 重做，Ctrl+S 保存。Esc
                退出面板或沉浸模式。
              </p>
              <button onClick={() => setHelp(false)}>知道了</button>
            </div>
          )}
          {lowFps && (
            <div className="performance-hint">
              检测到持续较低帧率。
              <button
                onClick={() => {
                  s.set({ quality: "low" });
                  setLowFps(false);
                }}
              >
                切换流畅画质
              </button>
              <button
                onClick={() => {
                  fpsHintDismissed.current = true;
                  setLowFps(false);
                }}
              >
                关闭提示
              </button>
            </div>
          )}
        </main>
        {!immersive && <Properties />}
      </div>
      <Controls />
      {settings && <Settings onClose={() => setSettings(false)} />}
    </div>
  );
}
function FishLoader() {
  return <div className="startup-ripple">◉</div>;
}
createRoot(document.getElementById("root")!).render(
  <AppBoundary>
    <App />
  </AppBoundary>,
);
