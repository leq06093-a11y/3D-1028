# 素材来源、许可与制作流程 · 1.0

## 外部资产：亚洲海鲈

- 作者 Microsoft，来源 KhronosGroup/glTF-Sample-Assets/Models/BarramundiFish。
- 原文件：https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/BarramundiFish/glTF-Binary/BarramundiFish.glb
- 许可：Creative Commons Zero v1.0 Universal（CC0）；原来源快照 `public/assets/BarramundiFish-source.md`，©2017 Public / Microsoft for Everything。
- 授权文本：https://creativecommons.org/publicdomain/zero/1.0/legalcode
- 原 GLB 12,488,144 字节，1 mesh、3 张嵌入 PBR 图像；无骨骼动画。原文件保持不变，运行时添加加权尾部形变。
- 低分辨率版本 `BarramundiFish-low.glb` 为本项目 CC0 衍生处理：几何、索引、材质结构保留，将图像限制至 1024px 并重新打包。由 `tools/optimize_barramundi.py` 可复现。不是替换原始高分辨率资源。
- 亚洲海鲈缩略图取自同一官方模型目录 screenshot。

## 原创鱼类：4 套独立解剖网格

| 物种 | 文件 | 不同于其他鱼种的结构 |
| --- | --- | --- |
| 红绿灯 | fish/neon.glb | 小型纺锤体、分叉尾、侧身蓝带和后腹红带 |
| 斑马鱼 | fish/zebra.glb | 细长躯干、较窄背腹轮廓、纵向条纹 |
| 孔雀鱼 | fish/guppy.glb | 独立的大尾扇膜、较宽背鳍和斑点躯干 |
| 神仙鱼 | fish/angel.glb | 侧扁高体、显著背鳍/臀鳍、长腹鳍丝 |

这些是本项目原创的参数化解剖建模资产，不是扫描件、不是同一模型换色，也不冒充外部高精扫描素材。脚本逐截面生成闭合鱼体网格，独立制作鳍膜、鳍条、鳃盖和眼睛；附带鱼鳞颜色/法线贴图、金属度/粗糙度材质、原生 glTF 鱼体 morph 与鳍变换动画。鳍条与鳍膜同步变换。

- 制作环境：Blender 4.3.2。
- 作者/来源：本项目代码生成，`tools/build_fish_assets.py`。
- Blender 工程和原纹理：`source-assets/fish/`，图片已打包进 .blend；GLB 自包含纹理。
- 许可状态：项目原创，无第三方授权依赖；未为整个项目授予公开再分发许可（private / UNLICENSED）。项目所有者可以继续编辑和使用。未购买素材。
- LOD：每种原创鱼均有 `*-low.glb`，降低躯干网格密度并保留动画；按距离、选中状态与画质动态选择。
- 缩略图由 `tools/render_asset_previews.py` 从真实 Blender 模型以 Cycles 渲染，不是与模型无关的图片。
- 模型是可继续精修的原创资产。当前视觉不宣称照片级；皮肤、眼睛、膜材质与转弯形变仍可进一步艺术优化。

## 原创造景

- 5 种植物几何：长叶苦草、阔叶水榕、茎类绿菊、簇生莫丝、地毯草。分别有独立叶片布局，UV 叶脉着色与分相位摆动。
- 岩石为连续顶点噪声变形，不对相邻重复顶点分别随机位移，避免裂缝；沉木为变半径弯曲枝干与根网络。
- 河砂、黑砂、浅砂、石与木纹采用本项目生成的 DataTexture；不是外部照片纹理。
- 过滤、灯具、加热棒为原创设备外形，设备状态参与模拟。
- 植物/造景目前仍为程序化原创资产，不能等同于扫描级自然素材库。

## 光照、音效与依赖

反射环境由 Lightformer 在离屏环境贴图生成，具备高动态范围光照计算，未使用外部实拍 HDRI。水面、波纹、投喂局部涟漪及焦散为 GLSL 实时近似，高清路径增加有界水体八采样单次散射近似，未进行完整流体或光谱路径追踪求解。

环境声为低音量滤波噪声，非自然水声录音。React/Three/R3F/Drei/Zustand/Tailwind/Vite/Electron 采用其上游开源许可，Playwright 为 Apache-2.0。Windows 包包含 Electron/Chromium LICENSE 与 LICENSES.chromium.html，不能删除。

所有可运行素材都在本地，不要求运行时联网。哈希清单位于 `ASSET-CHECKSUMS.txt`；原创鱼的详细 manifest 位于 `public/assets/fish/manifest.json`。

图标 public/icon.png 和 build/icon.ico 由本项目原有 favicon.svg 做格式转换，未引入外部图标授权依赖。
