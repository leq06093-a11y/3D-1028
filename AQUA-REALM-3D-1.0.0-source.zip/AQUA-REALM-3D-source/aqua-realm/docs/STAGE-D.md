# 阶段 D 构建与工程验收

已生成 Studio 0.4.0 Windows x64 免安装 ZIP，包含 EXE。校验 PE 为 AMD64、ZIP CRC 完整、app.asar 内版本为 0.4.0、10 个高/低细节模型与源文件哈希一致、桌面安全参数保留。

最终自动化单测 48 项通过。图形测试涵盖多物种、素材加载失败、鱼体拾取、真实拖拽、设备开关、历史曲线、材质与存档、低画质和本地 Electron 启动/IPC 文件读写。CPU 模拟基准和实际截图已留存。

恢复点 `aqua-v0.4.0-desktop`。完整源码 ZIP 包括 Blender 工程、原纹理与所有本地素材。Windows ZIP 不需要用户安装 Node.js 或 Blender。

阶段 D 的工程构建已完成；Windows RTX 实机、真实原生对话框手动操作、长期性能、专业艺术质量与完整体积光仍未验收/实现，见 ACCEPTANCE.md。当前碰撞是旋转包围盒代理。未以软件 WebGL FPS 声称 RTX 60 FPS，也未声称照片级。

产物只保存在 release；没有公开推送或发布云环境。校验在 WINDOWS-BUILD.json 和 release/BUILD-MANIFEST.json；后者补充源码档案的最终提交和哈希。
