# AQUA REALM 3D · 1.0 本地使用版

Windows 单文件便携 EXE：双击、首次点击“开始养鱼”即可使用；无需 Node.js、Blender 或账号。自动存档、正常退出前保存、恢复上次鱼缸、备份回退和诊断导出已实现。

5 种不同鱼类模型与物种行为、五类植物、造景手柄与 BVH 网格碰撞、设备联动、生态趋势、完整 JSON 场景、四种镜头、画质/LOD、高清近似体积散射均在本地运行。原 ORBIT 项目保持独立。

- [Windows 快速开始](docs/QUICK-START.md)
- [完整操作](docs/USER-GUIDE.md)
- [验收和已知限制](docs/ACCEPTANCE.md)
- [测试报告](docs/TEST-REPORT.md)
- [素材许可](docs/ASSETS.md)

## 开发与构建

```sh
npm ci
npm test
npm run build
npm run desktop
npm run pack:win
```

Node.js 22.12+。Windows 包在 release。源码包含 Blender 工程及全部本地素材；正常运行不需要 Blender。`npm run test:session` 验证退出/重启/备份，`npm run test:packaged` 验证实际 app.asar 离线启动和高清着色器。

Windows CI 配置位于仓库根 `.github/workflows/aqua-windows.yml`，仅手动触发；未执行的 CI 不算实测通过。项目没有自动公开发布。

生态为教学娱乐近似；没有宣称摄影级成果或未经实测的 RTX 60 FPS。来源/许可详见文档。
