function windowSize(area) {
  const width = Math.max(320, Math.floor(Number(area.width) || 1024)),
    height = Math.max(320, Math.floor(Number(area.height) || 768));
  return {
    width: Math.min(1540, width),
    height: Math.min(1000, height),
    minWidth: Math.min(1024, width),
    minHeight: Math.min(640, height),
  };
}
module.exports = { windowSize };
