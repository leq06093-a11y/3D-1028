const fs = require("node:fs/promises");
const path = require("node:path");
const LIMIT = 2_000_000;
function parseScene(text) {
  if (typeof text !== "string" || Buffer.byteLength(text) > LIMIT)
    throw Error("Scene size exceeded");
  const d = JSON.parse(text);
  if (
    !d ||
    d.version !== 1 ||
    !Array.isArray(d.fish) ||
    !Array.isArray(d.decorations) ||
    d.fish.length > 80 ||
    d.decorations.length > 150 ||
    !d.environment ||
    !d.tank
  )
    throw Error("Invalid scene");
  return d;
}
async function atomicWrite(file, text) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temp = file + "." + require("node:crypto").randomUUID() + ".tmp";
  await fs.writeFile(temp, text, { encoding: "utf8", mode: 0o600, flag: "wx" });
  try {
    await fs.rename(temp, file);
  } catch (error) {
    await fs.rm(temp, { force: true });
    throw error;
  }
}
class SessionRepository {
  constructor(dir) {
    this.dir = dir;
    this.primary = path.join(dir, "last-session.json");
    this.backup = path.join(dir, "last-session.backup.json");
    this.queue = Promise.resolve();
    this.skipInvalidPrimary = false;
  }
  async readFile(file) {
    const stat = await fs.stat(file);
    if (stat.size > LIMIT) throw Error("Scene too large");
    const text = await fs.readFile(file, "utf8");
    parseScene(text);
    return { text, savedAt: stat.mtime.toISOString() };
  }
  save(text) {
    parseScene(text);
    const operation = this.queue
      .catch(() => {})
      .then(async () => {
        let previous;
        try {
          if (!this.skipInvalidPrimary)
            previous = await this.readFile(this.primary);
        } catch {}
        if (previous) await atomicWrite(this.backup, previous.text);
        await atomicWrite(this.primary, text);
        this.skipInvalidPrimary = false;
        return { savedAt: new Date().toISOString() };
      });
    this.queue = operation;
    return operation;
  }
  async load(forceBackup = false) {
    if (forceBackup) this.skipInvalidPrimary = true;
    await this.queue.catch(() => {});
    let primaryMissing = false;
    try {
      if (forceBackup) throw Error("Backup requested");
      return { ...(await this.readFile(this.primary)), source: "primary" };
    } catch (e) {
      primaryMissing = e.code === "ENOENT";
    }
    try {
      return { ...(await this.readFile(this.backup)), source: "backup" };
    } catch {
      return {
        text: null,
        source: primaryMissing ? "empty" : "damaged",
        savedAt: null,
      };
    }
  }
}
module.exports = { SessionRepository, atomicWrite, parseScene, LIMIT };
