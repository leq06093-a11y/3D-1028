const {
  app,
  BrowserWindow,
  protocol,
  ipcMain,
  dialog,
  shell,
  screen,
} = require("electron");
const path = require("node:path");
const fs = require("node:fs/promises");
const os = require("node:os");
const { windowSize } = require("./window-size.cjs");
const {
  SessionRepository,
  atomicWrite,
  parseScene,
  LIMIT,
} = require("./storage.cjs");
protocol.registerSchemesAsPrivileged([
  {
    scheme: "aqua",
    privileges: {
      standard: true,
      secure: true,
      supportFetchAPI: true,
      corsEnabled: true,
    },
  },
]);
if (
  (!app.isPackaged || process.argv.includes("--aqua-acceptance-test")) &&
  process.env.AQUA_TEST_PROFILE
)
  app.setPath("userData", path.resolve(process.env.AQUA_TEST_PROFILE));
let win,
  repository,
  closePending = false,
  closeAllowed = false,
  closeTimer,
  rendererFailures = 0;
const diagnostics = [];
function log(message) {
  diagnostics.push({
    time: new Date().toISOString(),
    message: String(message).slice(0, 3000),
  });
  if (diagnostics.length > 30) diagnostics.shift();
}
const mime = {
  ".html": "text/html",
  ".js": "text/javascript",
  ".css": "text/css",
  ".svg": "image/svg+xml",
  ".glb": "model/gltf-binary",
  ".jpg": "image/jpeg",
  ".png": "image/png",
};
function trusted(event) {
  return (
    event.sender === win?.webContents &&
    event.senderFrame?.url.startsWith("aqua://app/")
  );
}
function guard(event) {
  if (!trusted(event)) throw Error("Invalid sender");
}
async function finishClose() {
  clearTimeout(closeTimer);
  closeAllowed = true;
  if (win && !win.isDestroyed()) win.destroy();
  app.quit();
}
async function failedClose(message) {
  clearTimeout(closeTimer);
  if (!win || win.isDestroyed()) return;
  const r = await dialog.showMessageBox(win, {
    type: "warning",
    title: "退出前保存水境",
    message,
    detail: "最近的自动存档和备份会保留。",
    buttons: ["继续等待", "取消退出", "仍然退出"],
    defaultId: 0,
    cancelId: 1,
  });
  if (r.response === 2) return finishClose();
  closePending = false;
  if (r.response === 0) win.close();
}
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (win && !win.isDestroyed()) {
      if (win.isMinimized()) win.restore();
      win.show();
      win.focus();
    }
  });
  app
    .whenReady()
    .then(async () => {
      if (process.platform === "win32")
        app.setAppUserModelId("studio.aquarealm.desktop");
      repository = new SessionRepository(
        path.join(app.getPath("userData"), "scenes"),
      );
      const root = path.resolve(__dirname, "../dist");
      protocol.handle("aqua", async (request) => {
        try {
          const url = new URL(request.url);
          if (url.host !== "app")
            return new Response("Forbidden", { status: 403 });
          const decoded = decodeURIComponent(url.pathname);
          const file = path.resolve(
            root,
            "." + (decoded === "/" ? "/index.html" : decoded),
          );
          if (
            !file.startsWith(root + path.sep) ||
            decoded.includes("\\") ||
            decoded.includes("\0")
          )
            return new Response("Forbidden", { status: 403 });
          return new Response(await fs.readFile(file), {
            headers: {
              "content-type":
                mime[path.extname(file)] || "application/octet-stream",
              "Content-Security-Policy":
                "default-src 'self' blob:; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' blob:; worker-src 'self' blob:; object-src 'none'",
            },
          });
        } catch {
          return new Response("Not found", { status: 404 });
        }
      });
      win = new BrowserWindow({
        ...windowSize(screen.getPrimaryDisplay().workAreaSize),
        backgroundColor: "#0c161a",
        title: "AQUA REALM 3D",
        icon: path.resolve(__dirname, "../dist/icon.png"),
        autoHideMenuBar: true,
        show: false,
        webPreferences: {
          preload: path.join(__dirname, "preload.cjs"),
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: true,
        },
      });
      win.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
      win.webContents.on("will-navigate", (event, url) => {
        if (!url.startsWith("aqua://app/")) event.preventDefault();
      });
      win.once("ready-to-show", () => win.show());
      win.webContents.on("render-process-gone", async (_, details) => {
        log("Renderer stopped: " + details.reason);
        if (closeAllowed) return;
        const retry = await dialog.showMessageBox(win, {
          type: "error",
          title: "水境画面需要恢复",
          message: "图形窗口意外停止。最近的自动存档已保留。",
          buttons: ["以流畅画质重新打开", "退出"],
          defaultId: 0,
        });
        if (retry.response === 0 && rendererFailures++ < 2) {
          closePending = false;
          await win.loadURL("aqua://app/index.html?safe=1");
          win.show();
        } else finishClose();
      });
      win.on("close", (event) => {
        if (closeAllowed) return;
        event.preventDefault();
        if (closePending) return;
        closePending = true;
        win.webContents.send("session:flush-request");
        closeTimer = setTimeout(
          () => void failedClose("窗口暂未完成最后一次保存。"),
          5000,
        );
      });
      await win.loadURL("aqua://app/index.html");
      if (process.argv.includes("--dev"))
        win.webContents.openDevTools({ mode: "detach" });
    })
    .catch((error) => {
      log(error.stack || error.message);
      dialog.showErrorBox(
        "AQUA REALM 无法启动",
        "请保留整个应用文件夹，不要只移动 EXE。\n" + error.message,
      );
      closeAllowed = true;
      app.quit();
    });
}
ipcMain.handle("session:load", async (event, backup) => {
  guard(event);
  return repository.load(backup === true);
});
ipcMain.handle("session:save", async (event, text) => {
  guard(event);
  return repository.save(text);
});
ipcMain.on("app:close-ready", (event, ok) => {
  if (!trusted(event)) return;
  if (!closePending) return;
  if (ok === true) void finishClose();
  else void failedClose("最后一次自动保存失败，可能是磁盘空间或文件权限问题。");
});
ipcMain.handle("scene:save", async (event, text) => {
  guard(event);
  parseScene(text);
  const result = await dialog.showSaveDialog(win, {
    title: "保存水境",
    defaultPath: "AQUA-REALM-scene.json",
    filters: [{ name: "AQUA REALM 场景", extensions: ["json"] }],
  });
  if (result.canceled || !result.filePath) return false;
  await atomicWrite(result.filePath, text);
  return true;
});
ipcMain.handle("scene:load", async (event) => {
  guard(event);
  const r = await dialog.showOpenDialog(win, {
    title: "打开水境",
    filters: [{ name: "AQUA REALM 场景", extensions: ["json"] }],
    properties: ["openFile"],
  });
  if (r.canceled) return null;
  if ((await fs.stat(r.filePaths[0])).size > LIMIT)
    throw Error("Scene too large");
  return fs.readFile(r.filePaths[0], "utf8");
});
ipcMain.handle("diagnostics:export", async (event, renderer) => {
  guard(event);
  if (typeof renderer !== "string" || Buffer.byteLength(renderer) > 100000)
    throw Error("Invalid diagnostics");
  const result = await dialog.showSaveDialog(win, {
    title: "保存运行诊断",
    defaultPath: "AQUA-REALM-diagnostics.json",
    filters: [{ name: "JSON 报告", extensions: ["json"] }],
  });
  if (result.canceled) return false;
  let gpu;
  try {
    gpu = await app.getGPUInfo("basic");
  } catch {
    gpu = { unavailable: true };
  }
  const report = {
    version: app.getVersion(),
    createdAt: new Date().toISOString(),
    platform: process.platform,
    architecture: process.arch,
    osRelease: os.release(),
    electron: process.versions.electron,
    chromium: process.versions.chrome,
    gpuFeatures: app.getGPUFeatureStatus(),
    gpu,
    renderer: JSON.parse(renderer),
    recentErrors: diagnostics,
  };
  await atomicWrite(result.filePath, JSON.stringify(report, null, 2));
  return true;
});
ipcMain.handle("support:open-data", (event) => {
  guard(event);
  return shell.openPath(app.getPath("userData"));
});
app.on("window-all-closed", () => app.quit());
