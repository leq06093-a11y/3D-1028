const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld(
  "aquaDesktop",
  Object.freeze({
    save: (text) => ipcRenderer.invoke("scene:save", text),
    load: () => ipcRenderer.invoke("scene:load"),
    loadSession: (backup) => ipcRenderer.invoke("session:load", backup),
    saveSession: (text) => ipcRenderer.invoke("session:save", text),
    onBeforeClose: (callback) => {
      const listener = () => callback();
      ipcRenderer.on("session:flush-request", listener);
      return () =>
        ipcRenderer.removeListener("session:flush-request", listener);
    },
    closeReady: (ok) => ipcRenderer.send("app:close-ready", ok),
    exportDiagnostics: (text) => ipcRenderer.invoke("diagnostics:export", text),
    openDataFolder: () => ipcRenderer.invoke("support:open-data"),
  }),
);
